# 来源与第三方许可

自有新增应用/设计按根MIT许可；第三方头、版权和各自许可均保留，不以根许可覆盖。

| 路径/组成 | 来源/版本依据 | 许可 |
|---|---|---|
| 两端Drivers/STM32F*xx_HAL_Driver | ST F4 HAL1.8.5 / F1 HAL1.1.10；Cube F4 1.28.3/F1 1.8.7 | 随组件LICENSE的BSD-3-Clause回退，完整条款见licenses/BSD-3-Clause-ST.txt |
| Drivers/CMSIS/Include | Arm CMSIS Core，保留各头文件版本与归属 | Apache-2.0，见licenses/Apache-2.0.txt |
| Drivers/CMSIS/Device/ST、Src/system_stm32*、startup_stm32*.s | ST Device/启动/系统代码 | 本地组件LICENSE的Apache-2.0回退及文件自身声明 |
| Src/Inc中ST生成模板 | STM32CubeMX生成并集成本项目，保留原头 | 对应ST组件声明；自有USER CODE新增部分按根MIT |
| Middlewares/FreeRTOS | Kernel11.3.1，Copyright Amazon.com, Inc. or affiliates | MIT，保留源文件头与licenses/MIT-FreeRTOS.txt |
| RC字模 | 本次公开版使用Noto开源字体生成；完整来源、固定版本/校验和及再生见licenses/fonts和字体工具说明 | SIL Open Font License1.1，字体例外不由根MIT替代 |

LCD控制器驱动和机体参数来自本项目集成与调试；旧厂商ASCII数组与Windows SimHei字模不进入本次公开版。厂商芯片PDF、Keil工具链、他人的EDA参考项目均不随公开包再分发。EasyEDA元件库和封装的上游属性保留，项目不声称自行设计了芯片/模块或所有库图元。

算法调研参考 [Crazyflie](https://github.com/bitcraze/crazyflie-firmware)、[PX4](https://github.com/PX4/PX4-Autopilot)；这是思路借鉴和本项目实现，不宣称本工程是它们的官方目标或继承其飞行验证。若发现具体片段归属遗漏，请带路径和上游出处提交Issue。
