#include "bsp_led.h"
#define LED_PORT  GPIOC
#define LED_PIN   GPIO_PIN_13


void bsp_led_on(void)
{
	HAL_GPIO_WritePin(LED_PORT,LED_PIN,GPIO_PIN_RESET);
}

void bsp_led_off(void)
{
	HAL_GPIO_WritePin(LED_PORT,LED_PIN,GPIO_PIN_SET);
}

void bsp_led_toggle(void)
{
   HAL_GPIO_TogglePin(LED_PORT, LED_PIN);
}

