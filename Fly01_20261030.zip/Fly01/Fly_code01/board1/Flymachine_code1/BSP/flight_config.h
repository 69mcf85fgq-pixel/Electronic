#ifndef FLIGHT_CONFIG_H
#define FLIGHT_CONFIG_H
/* Normal RCT6 firmware includes barometer telemetry and height hold. */
#ifndef FC_BARO_ENABLED
#define FC_BARO_ENABLED 1U
#endif
/* RCT6 PCB, top view with antenna at rear: M1 front-left, M2 front-right,
   M3 rear-left, M4 rear-right. PA6/PA7/PB0/PB1, TIM3 CH1/2/3/4. */
#define FC_GEOMETRY_CONFIRMED 1U
/* Installed rotation viewed from above: M1/M4 CCW, M2/M3 CW.
   Reaction yaw torque signs for the body +Z-down axis. */
#define FC_YAW_SIGNS {1.0f, -1.0f, -1.0f, 1.0f}
/* MPU top-side, pin 1 towards M3. Datasheet p21/p40: sensor +X forward,
   +Y left, +Z up. Controller uses forward/right/down, a right-handed frame. */
#define FC_BODY_X(sensor) ((sensor)[0])
#define FC_BODY_Y(sensor) (-(sensor)[1])
#define FC_BODY_Z(sensor) (-(sensor)[2])
/* User-measured readings with the airframe level. Subtract once AFTER estimation;
   do not feed trimmed Euler angles back into the MPU filter. Units: degrees. */
#define FC_LEVEL_ROLL_ZERO_DEG (-2.0f)
#define FC_LEVEL_PITCH_ZERO_DEG 2.0f
/* Fixed front-motor feedforward disabled; attitude feedback sets the differential. */
#define FC_FRONT_TRIM_RATIO 0.0f
/* M3 rear-left: extra fraction of collective, adjustable in 0.01 steps. */
#ifndef FC_M3_TRIM_RATIO
#define FC_M3_TRIM_RATIO 0.01f
#endif
#define FC_LINK_TIMEOUT_MS 200U
#define FC_CONTROL_PERIOD_MS 4U
/* Gear limits are actuator duty, not measured thrust. */
#define FC_GEAR1_DUTY 0.75f
#define FC_GEAR2_DUTY 0.85f
#define FC_MAX_DUTY 0.95f
#define FC_THROTTLE_FILTER_S 0.08f
/* Faster height corrections after HOLD engages; manual spool-up keeps its filter. */
#define FC_HOLD_THROTTLE_FILTER_S 0.04f
#define FC_ANGLE_FILTER_S 0.08f
/* Keep P/D feedback while withholding I during low-duty motor spool-up. */
#define FC_I_ENABLE_DUTY 0.12f
#endif
