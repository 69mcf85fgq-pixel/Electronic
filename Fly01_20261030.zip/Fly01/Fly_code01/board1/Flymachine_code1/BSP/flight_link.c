#include "flight_link.h"

static void put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static uint16_t get16(const uint8_t *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }

uint16_t fl_param_default(uint8_t id)
{
    const uint16_t values[FL_PARAM_COUNT] = {140, 80, 40, 400, 100, 180, 45, 80};
    return id < FL_PARAM_COUNT ? values[id] : 0;
}

uint8_t fl_param_valid(uint8_t id, uint16_t raw)
{
    const uint16_t maxima[FL_PARAM_COUNT] = {1000, 1000, 500, 1000, 1000, 500, 200, 500};
    return id < FL_PARAM_COUNT && raw <= maxima[id] && (id != FL_ANGLE_P || raw >= 50);
}

float fl_param_float(uint8_t id, uint16_t raw)
{
    const float scales[FL_PARAM_COUNT] = {0.00001f, 0.00001f, 0.000001f, 0.01f,
                                        0.00001f, 0.001f, 0.001f, 0.001f};
    return id < FL_PARAM_COUNT ? raw * scales[id] : 0.0f;
}

void fl_encode_control(uint8_t out[FL_CONTROL_LEN], const fl_control_t *in)
{
    out[0] = 0xC3; out[1] = FL_VERSION; out[2] = in->seq;
    out[3] = in->flags; out[4] = in->gear; out[5] = in->hover_seq;
    for (uint8_t i = 0; i < 4; i++) put16(&out[6 + 2 * i], (uint16_t)in->axes[i]);
    out[14] = in->param_rev; out[15] = in->param_id;
    put16(&out[16], in->param_value);
}

uint8_t fl_decode_control(fl_control_t *out, const uint8_t *in, uint8_t len)
{
    fl_control_t v;
    if (!out || !in || len != FL_CONTROL_LEN || in[0] != 0xC3 || in[1] != FL_VERSION ||
        in[4] >= 3 || (in[3] & (uint8_t)~(FL_ARM | FL_KILL))) return 0;
    v.seq = in[2]; v.flags = in[3]; v.gear = in[4]; v.hover_seq = in[5];
    for (uint8_t i = 0; i < 4; i++) {
        v.axes[i] = (int16_t)get16(&in[6 + 2 * i]);
        if (v.axes[i] < -1000 || v.axes[i] > 1000) return 0;
    }
    v.param_rev = in[14]; v.param_id = in[15]; v.param_value = get16(&in[16]);
    if (!fl_param_valid(v.param_id, v.param_value)) return 0;
    *out = v;
    return 1;
}

void fl_encode_telemetry(uint8_t out[FL_TELEMETRY_LEN], const fl_telemetry_t *in)
{
    out[0] = 0xA5; out[1] = FL_VERSION; out[2] = in->flags; out[3] = in->state;
    put16(&out[4], (uint16_t)in->roll_ddeg); put16(&out[6], (uint16_t)in->pitch_ddeg);
    put16(&out[8], (uint16_t)in->height_cm); put16(&out[10], (uint16_t)in->speed_cms);
    put16(&out[12], in->pressure_dhpa); put16(&out[14], (uint16_t)in->temperature_dC);
    for (uint8_t i = 0; i < 4; i++) put16(&out[16 + 2 * i], in->motors[i]);
    out[24] = in->imu_id; out[25] = in->baro_id; out[26] = in->fault;
    out[27] = in->control_seq; out[28] = in->param_rev; out[29] = in->param_id;
    put16(&out[30], in->param_value);
}

uint8_t fl_decode_telemetry(fl_telemetry_t *out, const uint8_t *in, uint8_t len)
{
    fl_telemetry_t v;
    if (!out || !in || len != FL_TELEMETRY_LEN || in[0] != 0xA5 || in[1] != FL_VERSION ||
        in[3] > FL_FAULT || in[26] > FL_BARO_FAULT || !fl_param_valid(in[29], get16(&in[30]))) return 0;
    v.flags = in[2]; v.state = in[3];
    v.roll_ddeg = (int16_t)get16(&in[4]); v.pitch_ddeg = (int16_t)get16(&in[6]);
    v.height_cm = (int16_t)get16(&in[8]); v.speed_cms = (int16_t)get16(&in[10]);
    v.pressure_dhpa = get16(&in[12]); v.temperature_dC = (int16_t)get16(&in[14]);
    for (uint8_t i = 0; i < 4; i++) {
        v.motors[i] = get16(&in[16 + 2 * i]);
        if (v.motors[i] > 1000) return 0;
    }
    v.imu_id = in[24]; v.baro_id = in[25]; v.fault = in[26]; v.control_seq = in[27];
    v.param_rev = in[28]; v.param_id = in[29]; v.param_value = get16(&in[30]);
    *out = v;
    return 1;
}
