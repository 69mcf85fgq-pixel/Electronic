#ifndef BSP_I2C_STARTUP_H
#define BSP_I2C_STARTUP_H

#include <stdint.h>

typedef struct
{
    uint32_t start_ms, end_ms;
    uint8_t scl_before, sda_before, scl_after, sda_after;
    uint8_t pulses, ready_mask; /* bit 0: MPU, bit 1: SPA06 */
} i2c_startup_diag_t;

/* Boot only, before RTOS tasks start and while all motors are stopped. */
void bsp_i2c_startup(i2c_startup_diag_t *diagnostic);

#endif
