#ifndef BSP_MPU6050_H
#define BSP_MPU6050_H

#include <stdint.h>

#define MPU_DIAG_WRITES 18U
#define MPU_DIAG_SEGMENTS 5U
#define MPU_DIAG_SEGMENT_SAMPLES 100U

enum {
    MPU_SETTLE_ACCEL = 0x01,
    MPU_SETTLE_VARIANCE = 0x02,
    MPU_SETTLE_DRIFT = 0x04,
    MPU_SETTLE_PREVIOUS = 0x08,
    MPU_SETTLE_IO = 0x10
};

typedef struct
{
    uint32_t ms, error;
    uint8_t reg, value, status;
} mpu_write_diag_t;

typedef struct
{
    uint16_t samples;
    int32_t sum[3];
    int16_t minimum[3], maximum[3];
} mpu_gyro_segment_diag_t;

typedef struct
{
    float roll_deg;
    float pitch_deg;
    float rate_dps[3];
    float accel_g[3];
} mpu_attitude_t;

typedef struct
{
    uint32_t start_ms, end_ms, io_ms;
    uint32_t i2c_error, sr1, sr2;
    uint16_t samples;
    int16_t first_accel[3], last_accel[3];
    uint8_t hal_status, reg, write, scl, sda;
    uint32_t config_ms, config_error[3];
    uint8_t config[3], config_status[3];
    uint8_t write_count, range_value[2], range_status[2];
    uint8_t attempts, verify_reg, verify_value, verify_expected, verify_status, stable;
    uint16_t settle_samples;
    uint32_t settle_ms;
    uint16_t settle_windows, settle_bad_accel, settle_bad_variance, settle_bad_drift;
    uint8_t settle_reject;
    int16_t settle_accel[3], settle_gyro[3];
    float settle_accel_min_sq, settle_accel_max_sq;
    /* Gyro measurements and rejection bits describe the last complete window. */
    float settle_mean[3], settle_variance[3], settle_delta[3];
    mpu_write_diag_t writes[MPU_DIAG_WRITES];
    uint16_t gyro_samples;
    float gyro_sum[3], gyro_sum_sq[3];
    mpu_gyro_segment_diag_t gyro_segments[MPU_DIAG_SEGMENTS];
} mpu_init_diag_t;

uint8_t bsp_mpu6050_init(void);
uint8_t bsp_mpu6050_update(float dt_s, mpu_attitude_t *attitude);
uint8_t bsp_mpu6050_init_step(void);
uint8_t bsp_mpu6050_whoami(void);
/* Saved startup measurements only; no I2C transactions. */
const mpu_init_diag_t *bsp_mpu6050_init_diag(void);
/* Read back PWR/GYRO/ACCEL only after all normal startup initialization. */
void bsp_mpu6050_read_init_diag(mpu_init_diag_t *diagnostic);

#endif
