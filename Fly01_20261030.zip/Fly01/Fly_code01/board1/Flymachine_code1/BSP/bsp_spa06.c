#include "bsp_spa06.h"
#include "i2c.h"

#define SPA_ADDR        (0x76U << 1)
#define SPA_REG_ID      0x0DU
#define SPA_REG_MEAS    0x08U

static uint8_t sensor_id = 0xFF;
static int32_t c0, c1, c00, c10, c20, c30, c40, c01, c11, c21, c31;

static int32_t signed_bits(uint32_t value, uint8_t bits)
{
    return (value & (1UL << (bits - 1))) ?
           (int32_t)value - (1L << bits) : (int32_t)value;
}

static int32_t signed16(uint8_t hi, uint8_t lo)
{
    return signed_bits(((uint32_t)hi << 8) | lo, 16);
}

static int32_t signed24(const uint8_t *p)
{
    return signed_bits(((uint32_t)p[0] << 16) | ((uint32_t)p[1] << 8) | p[2], 24);
}

static uint8_t read_reg(uint8_t reg, uint8_t *data, uint8_t len)
{
    return HAL_I2C_Mem_Read(&hi2c1, SPA_ADDR, reg, I2C_MEMADD_SIZE_8BIT,
                            data, len, 5) == HAL_OK;
}

static uint8_t write_reg(uint8_t reg, uint8_t value)
{
    return HAL_I2C_Mem_Write(&hi2c1, SPA_ADDR, reg, I2C_MEMADD_SIZE_8BIT,
                             &value, 1, 10) == HAL_OK;
}

uint8_t bsp_spa06_id(void) { return sensor_id; }

uint8_t bsp_spa06_init(void)
{
    uint8_t b[21];
    uint8_t status = 0;
    sensor_id = 0xFF;

    if (!read_reg(SPA_REG_ID, &sensor_id, 1) || (sensor_id & 0x0F) != 0x01)
        return 0;

    for (uint8_t i = 0; i < 10; i++)
    {
        if (read_reg(SPA_REG_MEAS, &status, 1) && (status & 0xC0) == 0xC0)
            break;
        HAL_Delay(10);
    }
    if ((status & 0xC0) != 0xC0 || !read_reg(0x10, b, sizeof(b))) return 0;

    c0  = signed_bits(((uint32_t)b[0] << 4) | (b[1] >> 4), 12);
    c1  = signed_bits(((uint32_t)(b[1] & 0x0F) << 8) | b[2], 12);
    c00 = signed_bits(((uint32_t)b[3] << 12) | ((uint32_t)b[4] << 4) | (b[5] >> 4), 20);
    c10 = signed_bits(((uint32_t)(b[5] & 0x0F) << 16) | ((uint32_t)b[6] << 8) | b[7], 20);
    c01 = signed16(b[8], b[9]);
    c11 = signed16(b[10], b[11]);
    c20 = signed16(b[12], b[13]);
    c21 = signed16(b[14], b[15]);
    c30 = signed16(b[16], b[17]);
    c31 = signed_bits(((uint32_t)b[18] << 4) | (b[19] >> 4), 12);
    c40 = signed_bits(((uint32_t)(b[19] & 0x0F) << 8) | b[20], 12);

    /* 32 Hz pressure at 8x and temperature at 1x, no result bit shift.
       32 * (14.8 + 3.6) ms < 1 second (SPA06 datasheet table 8). */
    return write_reg(0x06, 0x53) && write_reg(0x07, 0x50) &&
           write_reg(0x09, 0x00) && write_reg(SPA_REG_MEAS, 0x07);
}

uint8_t bsp_spa06_read(spa06_data_t *out)
{
    uint8_t status, b[6];
    float p, t, pressure_pa, temperature_c;

    if (!out || !read_reg(SPA_REG_MEAS, &status, 1) ||
        (status & 0x30) != 0x30 || !read_reg(0x00, b, sizeof(b))) return 0;

    p = (float)signed24(b) / 7864320.0f;
    t = (float)signed24(&b[3]) / 524288.0f;
    pressure_pa = (float)c00 + p * ((float)c10 + p * ((float)c20 +
                  p * ((float)c30 + p * (float)c40))) +
                  t * ((float)c01 + p * ((float)c11 + p * ((float)c21 + p * (float)c31)));
    temperature_c = 0.5f * (float)c0 + (float)c1 * t;

    if (pressure_pa < 30000.0f || pressure_pa > 110000.0f ||
        temperature_c < -50.0f || temperature_c > 90.0f) return 0;
    out->pressure_dhpa = (uint16_t)(pressure_pa / 10.0f + 0.5f);
    out->temperature_dC = (int16_t)(temperature_c * 10.0f);
    out->pressure_pa = pressure_pa;
    out->temperature_c = temperature_c;
    return 1;
}
