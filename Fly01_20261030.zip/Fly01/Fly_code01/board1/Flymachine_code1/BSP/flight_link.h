#ifndef FLIGHT_LINK_H
#define FLIGHT_LINK_H
#include <stdint.h>

#define FL_CONTROL_LEN 18U
#define FL_TELEMETRY_LEN 32U
#define FL_VERSION 3U
#define FL_ARM 0x01U
#define FL_KILL 0x02U
#define FL_IMU_OK 0x01U
#define FL_BARO_OK 0x02U
#define FL_BARO_READY 0x04U
#define FL_ARMED 0x08U
#define FL_GEOMETRY_OK 0x10U
#define FL_HEIGHT_READY 0x20U
#define FL_PARAM_COUNT 8U

enum { FL_STOPPED, FL_MANUAL, FL_HOLD, FL_HOLD_EXIT, FL_FAULT };
enum { FL_NO_FAULT, FL_MAP_FAULT, FL_IMU_FAULT, FL_RADIO_FAULT,
       FL_TILT_FAULT, FL_TIMING_FAULT, FL_BARO_FAULT };
enum { FL_RATE_P, FL_RATE_I, FL_RATE_D, FL_ANGLE_P, FL_YAW_P,
       FL_HEIGHT_P, FL_HEIGHT_I, FL_HEIGHT_D };

typedef struct {
    uint8_t seq, flags, gear, hover_seq;
    int16_t axes[4]; /* left X/Y, right X/Y; +Y means stick forward */
    uint8_t param_rev, param_id;
    uint16_t param_value;
} fl_control_t;

typedef struct {
    uint8_t flags, state;
    int16_t roll_ddeg, pitch_ddeg, height_cm, speed_cms;
    uint16_t pressure_dhpa;
    int16_t temperature_dC;
    uint16_t motors[4]; /* M1/M2/M3/M4 duty in parts per thousand */
    uint8_t imu_id, baro_id, fault, control_seq;
    uint8_t param_rev, param_id;
    uint16_t param_value;
} fl_telemetry_t;

void fl_encode_control(uint8_t out[FL_CONTROL_LEN], const fl_control_t *in);
uint8_t fl_decode_control(fl_control_t *out, const uint8_t *in, uint8_t len);
void fl_encode_telemetry(uint8_t out[FL_TELEMETRY_LEN], const fl_telemetry_t *in);
uint8_t fl_decode_telemetry(fl_telemetry_t *out, const uint8_t *in, uint8_t len);
uint16_t fl_param_default(uint8_t id);
uint8_t fl_param_valid(uint8_t id, uint16_t raw);
float fl_param_float(uint8_t id, uint16_t raw);
#endif
