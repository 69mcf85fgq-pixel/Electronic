#ifndef BSP_SPA06_H
#define BSP_SPA06_H

#include <stdint.h>

typedef struct
{
    uint16_t pressure_dhpa;
    int16_t temperature_dC;
    float pressure_pa;
    float temperature_c;
} spa06_data_t;

uint8_t bsp_spa06_init(void);
uint8_t bsp_spa06_read(spa06_data_t *out);
uint8_t bsp_spa06_id(void);

#endif
