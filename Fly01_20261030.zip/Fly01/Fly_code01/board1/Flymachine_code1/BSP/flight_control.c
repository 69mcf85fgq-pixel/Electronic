#include "flight_control.h"
#include "flight_config.h"
#include <math.h>
#include <string.h>

static float limit(float v, float lo, float hi) { return v < lo ? lo : v > hi ? hi : v; }

static void reset_pid(fc_state_t *s)
{
    memset(s->integral, 0, sizeof(s->integral));
    memset(s->derivative, 0, sizeof(s->derivative));
    memset(s->angle_target, 0, sizeof(s->angle_target));
    memset(s->rate_error, 0, sizeof(s->rate_error));
    memset(s->requested, 0, sizeof(s->requested));
    memset(s->applied, 0, sizeof(s->applied));
    s->sat_positive = s->sat_negative = s->integrator_blocked = 0;
    s->height_integral = s->yaw_integral = 0;
}

static void stop(fc_state_t *s, uint8_t fault)
{
    memset(s->motors, 0, sizeof(s->motors));
    s->collective = s->handover_bias = 0;
    s->armed = 0;
    s->state = fault ? FL_FAULT : FL_STOPPED;
    s->fault = fault;
    reset_pid(s);
}

void fc_init(fc_state_t *s)
{
    memset(s, 0, sizeof(*s));
    s->geometry_ok = FC_GEOMETRY_CONFIRMED;
    for (uint8_t i = 0; i < FL_PARAM_COUNT; i++) s->parameters[i] = fl_param_default(i);
}

void fc_pressure(fc_state_t *s, float pressure_pa, float temperature_c, uint32_t now_ms)
{
    float height, dt, alpha;
    if (!isfinite(pressure_pa) || pressure_pa < 30000 || pressure_pa > 110000 ||
        !isfinite(temperature_c) || temperature_c < -50 || temperature_c > 90) return;
    if (!s->reference_pressure) s->reference_pressure = pressure_pa;
    if (!s->armed) {
        s->reference_pressure += 0.08f * (pressure_pa - s->reference_pressure);
        s->height = s->vertical_speed = 0;
        if (s->height_samples < 32) s->height_samples++;
        s->baro_tick = now_ms;
        return;
    }
    height = (287.05f * (temperature_c + 273.15f) / 9.80665f) *
             logf(s->reference_pressure / pressure_pa);
    dt = (float)(now_ms - s->baro_tick) * 0.001f;
    if (dt <= 0) return;
    s->baro_tick = now_ms;
    if (dt > 0.5f) { s->height = height; s->vertical_speed = 0; return; }
    alpha = dt / (0.18f + dt);
    height = s->height + alpha * (height - s->height);
    s->vertical_speed += dt / (0.35f + dt) * ((height - s->height) / dt - s->vertical_speed);
    s->height = height;
}

static float mix_outputs(float collective, float roll, float pitch, float yaw,
                         float cap, uint16_t motors[4], float m3_trim)
{
    const float yaw_sign[4] = FC_YAW_SIGNS;
    float correction[4] = {roll + pitch, -roll + pitch, roll - pitch, -roll - pitch};
    float lo, hi, scale = 1;
    for (uint8_t i = 0; i < 4; i++) correction[i] += yaw_sign[i] * yaw;
    correction[2] += m3_trim;
    lo = hi = correction[0];
    for (uint8_t i = 1; i < 4; i++) {
        if (correction[i] < lo) lo = correction[i];
        if (correction[i] > hi) hi = correction[i];
    }
    if (hi - lo > cap) scale = cap / (hi - lo);
    collective = limit(collective, -lo * scale, cap - hi * scale);
    for (uint8_t i = 0; i < 4; i++)
        motors[i] = (uint16_t)(limit(collective + correction[i] * scale, 0, cap) * 1000 + 0.5f);
    return scale;
}

void fc_mix(float collective, float roll, float pitch, float yaw, float cap, uint16_t motors[4])
{
    (void)mix_outputs(collective, roll, pitch, yaw, cap, motors, 0);
}

/* Return the P+D part. Commit or reject the trial I after actual allocation. */
static float rate_feedback(fc_state_t *s, uint8_t axis, float target, float measured,
                           float dt, uint8_t integrate)
{
    float error = target - measured;
    float p = fl_param_float(FL_RATE_P, s->parameters[FL_RATE_P]);
    float i = fl_param_float(FL_RATE_I, s->parameters[FL_RATE_I]);
    float d = fl_param_float(FL_RATE_D, s->parameters[FL_RATE_D]);
    s->rate_error[axis] = error;
    s->integral[axis] = integrate ? limit(s->integral[axis] + i * error * dt, -0.10f, 0.10f) : 0;
    /* Derivative on gyro measurement avoids a kick when moving the stick. */
    s->derivative[axis] += dt / (0.02f + dt) *
                           ((measured - s->previous_rate[axis]) / dt - s->derivative[axis]);
    s->previous_rate[axis] = measured;
    return p * error - d * s->derivative[axis];
}

static void allocate(fc_state_t *s, const float feedback[3], float cap)
{
    float roll, pitch, yaw, authority, scale;
    /* Half in collective and half in pitch adds only to M1/M2 before limiting.
       Cap trim growth so full stick cannot cut the rear pair. */
    float trim_base = limit(s->collective, 0, cap / (1.0f + FC_FRONT_TRIM_RATIO));
    float front_bias = 0.5f * FC_FRONT_TRIM_RATIO * trim_base;
    float m3_trim = FC_M3_TRIM_RATIO * s->collective;
    s->requested[0] = feedback[0] + s->integral[0];
    s->requested[1] = feedback[1] + s->integral[1];
    s->requested[2] = feedback[2] + s->yaw_integral;
    roll = limit(s->requested[0], -0.20f, 0.20f);
    pitch = limit(s->requested[1], -0.20f, 0.20f);
    yaw = limit(s->requested[2], -0.10f, 0.10f);
    authority = fabsf(roll) + fabsf(pitch) + fabsf(yaw);
    if (authority > 0.8f * s->collective) {
        scale = 0.8f * s->collective / authority;
        roll *= scale; pitch *= scale; yaw *= scale;
    }
    scale = mix_outputs(s->collective + front_bias, roll, pitch + front_bias, yaw, cap, s->motors, m3_trim);
    /* Mixer scaling also scales the M3 bias. Account for its lost moments. */
    s->applied[0] = roll * scale + 0.25f * m3_trim * (scale - 1.0f);
    /* Remove the intended feedforward, not the scaled feedforward: any lost
       pitch authority, including trim, belongs in the allocation residual. */
    s->applied[1] = (pitch + front_bias) * scale - front_bias - 0.25f * m3_trim * (scale - 1.0f);
    s->applied[2] = yaw * scale - 0.25f * m3_trim * (scale - 1.0f);
    s->sat_positive = s->sat_negative = 0;
    for (uint8_t axis = 0; axis < 3; axis++) {
        float loss = s->requested[axis] - s->applied[axis];
        /* Ignore float noise; collective shifting and PWM rounding are not
           evidence that an axis has run out of differential authority. */
        if (loss > 0.000001f) s->sat_positive |= (uint8_t)(1U << axis);
        if (loss < -0.000001f) s->sat_negative |= (uint8_t)(1U << axis);
    }
}

void fc_step(fc_state_t *s, const fl_control_t *c, const mpu_attitude_t *a,
             uint8_t imu_valid, uint32_t last_rx_ms, uint32_t now_ms, float dt)
{
    const float caps[3] = {FC_GEAR1_DUTY, FC_GEAR2_DUTY, FC_MAX_DUTY};
    const float tilts[3] = {8.0f, 12.0f, 16.0f};
    float cap, manual, desired, roll_rate, pitch_rate, angle_p;
    float feedback[3], old_integral[3];
    float throttle_filter;
    uint8_t gear = c->gear < 3 ? c->gear : 0;
    uint8_t baro_fresh = FC_BARO_ENABLED && s->height_samples >= 32 && now_ms - s->baro_tick < 300U;

    if (!s->armed && s->state == FL_STOPPED && !(c->flags & FL_ARM) &&
        c->param_rev != s->param_rev && fl_param_valid(c->param_id, c->param_value)) {
        s->parameters[c->param_id] = c->param_value;
        s->param_rev = c->param_rev; s->param_id = c->param_id;
        reset_pid(s);
    }
    if (!(c->flags & FL_ARM) || (c->flags & FL_KILL)) {
        stop(s, 0);
        s->hover_seq = c->hover_seq;
        return;
    }
    if (s->state == FL_FAULT) return; /* deliberate disarm required after a fault */
    if (now_ms - last_rx_ms > FC_LINK_TIMEOUT_MS) { stop(s, FL_RADIO_FAULT); return; }
    if (!imu_valid || !isfinite(a->roll_deg) || !isfinite(a->pitch_deg) ||
        !isfinite(a->rate_dps[0]) || !isfinite(a->rate_dps[1]) || !isfinite(a->rate_dps[2])) {
        stop(s, FL_IMU_FAULT); return;
    }
    if (!isfinite(dt) || dt < 0.001f || dt > 0.012f) { stop(s, FL_TIMING_FAULT); return; }
    if (!s->armed) {
        if (c->axes[3] > 30 || c->axes[3] < -30) return;
        if (FC_BARO_ENABLED && s->height_samples && s->height_samples < 32) return;
        s->armed = 1; s->state = FL_MANUAL; s->hover_seq = c->hover_seq;
        for (uint8_t i = 0; i < 2; i++) s->previous_rate[i] = a->rate_dps[i];
    }
    cap = caps[gear];
    manual = limit((float)c->axes[3] / 1000.0f, 0, 1) * cap;
    if (c->hover_seq != s->hover_seq) {
        uint8_t toggle = (uint8_t)(c->hover_seq - s->hover_seq) & 1U;
        s->hover_seq = c->hover_seq;
        if (toggle && s->state == FL_MANUAL && baro_fresh && s->collective > 0.12f &&
            fabsf(a->roll_deg) < 20 && fabsf(a->pitch_deg) < 20) {
            s->state = FL_HOLD; s->hold_height = s->height;
            s->hold_throttle = s->collective; s->hold_cap = cap; s->height_integral = 0;
        } else if (toggle && s->state == FL_HOLD) {
            s->state = FL_HOLD_EXIT; s->takeover_stick = c->axes[3];
        } else if (toggle && s->state == FL_HOLD_EXIT) s->state = FL_HOLD;
    }
    if ((s->state == FL_HOLD || s->state == FL_HOLD_EXIT) && !baro_fresh) {
        if (s->state == FL_HOLD) s->takeover_stick = c->axes[3];
        s->state = FL_HOLD_EXIT; s->fault = FL_BARO_FAULT;
    }
    if (s->state == FL_HOLD_EXIT &&
        (c->axes[3] - s->takeover_stick > 150 || c->axes[3] - s->takeover_stick < -150)) {
        s->state = FL_MANUAL; s->handover_bias = s->collective - manual;
        s->fault = 0; s->height_integral = 0;
    }
    desired = manual;
    if (s->state == FL_HOLD || s->state == FL_HOLD_EXIT) {
        cap = s->hold_cap; /* reducing the speed gear must not cut hover thrust */
        desired = s->collective;
        if (baro_fresh) {
            float error = limit(s->hold_height - s->height, -2, 2);
            float correction, candidate;
            candidate = limit(s->height_integral +
                              fl_param_float(FL_HEIGHT_I, s->parameters[FL_HEIGHT_I]) * error * dt,
                              -0.10f, 0.10f);
            correction = fl_param_float(FL_HEIGHT_P, s->parameters[FL_HEIGHT_P]) * error + candidate -
                         fl_param_float(FL_HEIGHT_D, s->parameters[FL_HEIGHT_D]) * s->vertical_speed;
            desired = s->hold_throttle + limit(correction, -0.18f, 0.18f);
            if (desired > 0.05f && desired < cap) s->height_integral = candidate;
        }
    } else if (manual == 0) {
        memset(s->motors, 0, sizeof(s->motors));
        s->collective = s->handover_bias = 0; reset_pid(s);
        for (uint8_t i = 0; i < 2; i++) s->previous_rate[i] = a->rate_dps[i];
        return;
    } else if (s->handover_bias != 0) {
        if (cap < s->hold_cap) cap = s->hold_cap;
        desired += s->handover_bias;
        s->handover_bias *= 0.6f / (0.6f + dt);
        if (fabsf(s->handover_bias) < 0.003f) s->handover_bias = 0;
    }
    /* Height correction has a shorter filter; retain the existing slew bounds. */
    throttle_filter = (s->state == FL_HOLD || s->state == FL_HOLD_EXIT) ?
        FC_HOLD_THROTTLE_FILTER_S : FC_THROTTLE_FILTER_S;
    s->collective += limit((desired - s->collective) * dt / (throttle_filter + dt),
                           -1.5f * dt, 0.8f * dt);
    s->collective = limit(s->collective, 0, cap);
    s->angle_target[0] += dt / (FC_ANGLE_FILTER_S + dt) *
        ((float)c->axes[0] * tilts[gear] / 1000 - s->angle_target[0]);
    s->angle_target[1] += dt / (FC_ANGLE_FILTER_S + dt) *
        (-(float)c->axes[1] * tilts[gear] / 1000 - s->angle_target[1]);
    angle_p = fl_param_float(FL_ANGLE_P, s->parameters[FL_ANGLE_P]);
    roll_rate = limit(angle_p * (s->angle_target[0] - a->roll_deg), -120, 120);
    pitch_rate = limit(angle_p * (s->angle_target[1] - a->pitch_deg), -120, 120);
    {
        uint8_t integrate = s->collective >= FC_I_ENABLE_DUTY;
        old_integral[0] = s->integral[0]; old_integral[1] = s->integral[1];
        old_integral[2] = s->yaw_integral;
        feedback[0] = rate_feedback(s, 0, roll_rate, a->rate_dps[0], dt, integrate);
        feedback[1] = rate_feedback(s, 1, pitch_rate, a->rate_dps[1], dt, integrate);
        s->rate_error[2] = -a->rate_dps[2];
        s->yaw_integral = integrate ? limit(s->yaw_integral +
            fl_param_float(FL_RATE_I, s->parameters[FL_RATE_I]) * s->rate_error[2] * dt,
            -0.05f, 0.05f) : 0;
        feedback[2] = fl_param_float(FL_YAW_P, s->parameters[FL_YAW_P]) * s->rate_error[2];
        s->integrator_blocked = 0;
        allocate(s, feedback, cap);
        if (integrate) {
            /* Reject only increments that push an axis further into saturation.
               Allow reversal/unwinding. Reallocate in this same control cycle. */
            for (uint8_t axis = 0; axis < 3; axis++) {
                float *integral = axis < 2 ? &s->integral[axis] : &s->yaw_integral;
                float change = *integral - old_integral[axis];
                if (((s->sat_positive & (1U << axis)) && change > 0) ||
                    ((s->sat_negative & (1U << axis)) && change < 0)) {
                    *integral = old_integral[axis];
                    s->integrator_blocked |= (uint8_t)(1U << axis);
                }
            }
            if (s->integrator_blocked) allocate(s, feedback, cap);
        }
    }
}
