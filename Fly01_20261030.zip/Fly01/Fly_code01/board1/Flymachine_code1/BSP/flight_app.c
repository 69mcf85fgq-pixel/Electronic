#include "flight_app.h"
#include "flight_control.h"
#include "flight_config.h"
#include "bsp_i2c_startup.h"
#include "bsp_spa06.h"
#include "bsp_nrf.h"
#include "bsp_led.h"
#include "tim.h"
#include "usart.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

typedef struct { fl_control_t control; uint32_t rx_tick; } received_t;
typedef struct {
    uint32_t ms, write_error, read_error;
    uint8_t write_status, write_hal, value, read_hal;
} config_probe_t;
typedef struct {
    uint32_t tick, dt_ms, rx_age_ms, imu_age_ms;
    uint16_t motors[4];
    int16_t throttle, roll_ddeg, pitch_ddeg;
    uint8_t from, to, fault, cmd, seq;
} stop_event_t;
static QueueHandle_t commands, telemetry_queue, stop_queue;
static uint8_t imu_ready, baro_ready, radio_ready;
static const uint32_t channels[4] = {TIM_CHANNEL_1, TIM_CHANNEL_2, TIM_CHANNEL_3, TIM_CHANNEL_4};
typedef struct {
    uint32_t tick, loops, reads, accepted, bad, zero, old, ff, ack;
    uint8_t fifo, status, length, head[2];
} radio_rx_diag_t;
static radio_rx_diag_t radio_rx_diag;
typedef struct {
    uint32_t tick;
    uint16_t motors[4], collective;
    int16_t throttle, angle[2], target[2], rate_error[3], integral[3], requested[3], applied[3];
    uint32_t baro_age;
    int16_t height, hold_height, vertical_speed, hold_base, height_i, hold_cap;
    uint16_t height_pid[3];
    uint8_t fault, holding;
    uint8_t seq, state, imu, sat_positive, sat_negative, blocked, valid;
} control_diag_t;
/* Internal snapshot only: no changes to the on-air telemetry packet. */
static control_diag_t control_diag;
enum { RADIO_BOOT, RADIO_GAP, RADIO_LATE, RADIO_BACK, RADIO_SNAPSHOT_COUNT };
typedef struct {
    uint32_t number, rx_age, read, accepted;
    uint8_t seq;
    nrf_snapshot_t chip;
} radio_snapshot_t;
/* Retain each event type independently so recovery cannot erase the gap sample. */
static radio_snapshot_t radio_snapshots[RADIO_SNAPSHOT_COUNT];
static uint32_t radio_snapshot_number;

static void radio_snapshot(uint8_t reason, uint32_t age, uint8_t seq)
{
    radio_snapshot_t s;
    s.number = ++radio_snapshot_number; s.rx_age = age; s.seq = seq;
    s.read = radio_rx_diag.reads; s.accepted = radio_rx_diag.accepted;
    bsp_nrf_snapshot(&s.chip);
    taskENTER_CRITICAL();
    radio_snapshots[reason] = s;
    taskEXIT_CRITICAL();
}

void flight_emergency_stop(void)
{
    TIM3->CCR1 = TIM3->CCR2 = TIM3->CCR3 = TIM3->CCR4 = 0;
    TIM3->CCER = 0;
    TIM3->CR1 &= ~TIM_CR1_CEN;
}

static void fatal(void)
{
    flight_emergency_stop(); __disable_irq();
    for (;;) {}
}
void vApplicationMallocFailedHook(void) { fatal(); }
void vApplicationStackOverflowHook(TaskHandle_t task, char *name)
{
    (void)task; (void)name; fatal();
}

static int16_t fixed16(float v, float scale)
{
    if (!isfinite(v)) return 0;
    v *= scale;
    if (v > 32767) v = 32767;
    if (v < -32767) v = -32767;
    return (int16_t)v;
}

static void save_control_diag(const fc_state_t *s, const received_t *rx,
                              const mpu_attitude_t *a, uint8_t imu, uint32_t now)
{
    control_diag_t d;
    d.tick = now; d.seq = rx->control.seq; d.state = s->state; d.imu = imu;
    d.throttle = rx->control.axes[3]; d.collective = (uint16_t)fixed16(s->collective, 1000);
    for (uint8_t i = 0; i < 2; i++) {
        d.target[i] = fixed16(s->angle_target[i], 10);
        d.integral[i] = fixed16(s->integral[i], 1000);
    }
    d.angle[0] = fixed16(a->roll_deg, 10); d.angle[1] = fixed16(a->pitch_deg, 10);
    d.integral[2] = fixed16(s->yaw_integral, 1000);
    for (uint8_t i = 0; i < 3; i++) {
        d.rate_error[i] = fixed16(s->rate_error[i], 10);
        d.requested[i] = fixed16(s->requested[i], 1000);
        d.applied[i] = fixed16(s->applied[i], 1000);
    }
    memcpy(d.motors, s->motors, sizeof(d.motors));
    d.sat_positive = s->sat_positive; d.sat_negative = s->sat_negative;
    d.blocked = s->integrator_blocked; d.valid = 1;
    d.baro_age = now - s->baro_tick;
    d.height = fixed16(s->height, 100); d.hold_height = fixed16(s->hold_height, 100);
    d.vertical_speed = fixed16(s->vertical_speed, 100);
    d.hold_base = fixed16(s->hold_throttle, 1000);
    d.height_i = fixed16(s->height_integral, 1000); d.hold_cap = fixed16(s->hold_cap, 1000);
    d.fault = s->fault; d.holding = s->state == FL_HOLD || s->state == FL_HOLD_EXIT;
    d.height_pid[0] = s->parameters[FL_HEIGHT_P];
    d.height_pid[1] = s->parameters[FL_HEIGHT_I];
    d.height_pid[2] = s->parameters[FL_HEIGHT_D];
    /* Only the short copy is protected; float conversion and UART stay outside. */
    taskENTER_CRITICAL();
    control_diag = d;
    taskEXIT_CRITICAL();
}

static void control_task(void *unused)
{
    fc_state_t state;
    received_t rx = {0};
    mpu_attitude_t raw_attitude = {0};
    mpu_attitude_t attitude = {0};
    spa06_data_t baro = {0};
    fl_telemetry_t telemetry = {0};
    stop_event_t event = {0};
    TickType_t wake = xTaskGetTickCount();
    uint32_t previous_tick = HAL_GetTick(), baro_poll_tick = previous_tick;
    uint32_t last_imu_tick = previous_tick;
    uint8_t have_imu = 0;
    uint8_t imu_valid;
    (void)unused;
    fc_init(&state);
    rx.control.param_value = fl_param_default(FL_RATE_P);
    /* Only the control task feeds the approximately one-second watchdog. */
    IWDG->KR = 0xCCCC; IWDG->KR = 0x5555;
    IWDG->PR = 4; IWDG->RLR = 499;
    IWDG->KR = 0xAAAA;
    for (;;) {
        uint32_t now, step_ms;
        uint8_t was_armed;
        float dt;
        vTaskDelayUntil(&wake, pdMS_TO_TICKS(FC_CONTROL_PERIOD_MS));
        now = HAL_GetTick();
        {
            float imu_dt = (float)(now - last_imu_tick) * 0.001f;
            if (imu_dt > 0.012f) imu_dt = 0.004f;
            if (imu_ready && bsp_mpu6050_update(imu_dt, &raw_attitude)) {
                /* Keep estimator history raw; control and telemetry share one leveled copy. */
                attitude = raw_attitude;
                attitude.roll_deg -= FC_LEVEL_ROLL_ZERO_DEG;
                attitude.pitch_deg -= FC_LEVEL_PITCH_ZERO_DEG;
                last_imu_tick = HAL_GetTick(); have_imu = 1;
            }
        }
        if (FC_BARO_ENABLED && baro_ready && now - baro_poll_tick >= 32U) {
            baro_poll_tick = now;
            if (bsp_spa06_read(&baro))
                fc_pressure(&state, baro.pressure_pa, baro.temperature_c, HAL_GetTick());
        }
        /* Deadlines include time spent waiting for I2C, before writing PWM. */
        now = HAL_GetTick();
        step_ms = now - previous_tick;
        dt = (float)step_ms * 0.001f;
        previous_tick = now;
        imu_valid = have_imu && now - last_imu_tick <= 12U;
        xQueueReceive(commands, &rx, 0);
        was_armed = state.armed;
        event.from = state.state;
        memcpy(event.motors, state.motors, sizeof(event.motors));
        fc_step(&state, &rx.control, &attitude, imu_valid, rx.rx_tick, now, dt);
        for (uint8_t i = 0; i < 4; i++)
            __HAL_TIM_SET_COMPARE(&htim3, channels[i],
                                  (htim3.Init.Period + 1U) * state.motors[i] / 1000U);
        save_control_diag(&state, &rx, &attitude, imu_valid, now);
        /* Preserve the stop reason even if the next remote packet clears the fault. */
        if (was_armed && !state.armed) {
            event.tick = now; event.dt_ms = step_ms;
            event.rx_age_ms = now - rx.rx_tick; event.imu_age_ms = now - last_imu_tick;
            event.to = state.state; event.fault = state.fault;
            event.cmd = rx.control.flags; event.seq = rx.control.seq;
            event.throttle = rx.control.axes[3];
            event.roll_ddeg = fixed16(attitude.roll_deg, 10);
            event.pitch_ddeg = fixed16(attitude.pitch_deg, 10);
            xQueueOverwrite(stop_queue, &event);
        }
        telemetry.flags = (imu_valid ? FL_IMU_OK : 0) |
                          (FC_BARO_ENABLED && baro_ready ? FL_BARO_READY : 0) |
                          (FC_BARO_ENABLED && state.baro_tick && now - state.baro_tick < 300U ? FL_BARO_OK : 0) |
                          (state.armed ? FL_ARMED : 0) | (state.geometry_ok ? FL_GEOMETRY_OK : 0) |
                          (FC_BARO_ENABLED && state.height_samples >= 32 ? FL_HEIGHT_READY : 0);
        telemetry.state = state.state; telemetry.fault = state.fault;
        telemetry.roll_ddeg = fixed16(attitude.roll_deg, 10);
        telemetry.pitch_ddeg = fixed16(attitude.pitch_deg, 10);
        telemetry.height_cm = fixed16(state.height, 100);
        telemetry.speed_cms = fixed16(state.vertical_speed, 100);
        telemetry.pressure_dhpa = baro.pressure_dhpa;
        telemetry.temperature_dC = baro.temperature_dC;
        memcpy(telemetry.motors, state.motors, sizeof(state.motors));
        telemetry.imu_id = bsp_mpu6050_whoami();
        telemetry.baro_id = FC_BARO_ENABLED ? bsp_spa06_id() : 0;
        telemetry.control_seq = rx.control.seq;
        telemetry.param_rev = state.param_rev; telemetry.param_id = state.param_id;
        telemetry.param_value = state.parameters[state.param_id];
        xQueueOverwrite(telemetry_queue, &telemetry);
        IWDG->KR = 0xAAAA;
        /* Skip missed releases instead of producing zero-dt catch-up iterations. */
        if (xTaskGetTickCount() - wake >= pdMS_TO_TICKS(FC_CONTROL_PERIOD_MS))
            wake = xTaskGetTickCount();
    }
}

static void radio_task(void *unused)
{
    received_t rx = {0};
    fl_telemetry_t telemetry = {0};
    uint8_t data[FL_TELEMETRY_LEN], last_seq = 0, seen = 0;
    uint32_t last_accepted = 0, started = HAL_GetTick();
    uint8_t baseline = 0, gap_stage = 0;
    TickType_t wake = xTaskGetTickCount();
    (void)unused;
    for (;;) {
        uint32_t now = HAL_GetTick();
        radio_rx_diag.tick = now; radio_rx_diag.loops++;
        if (radio_ready) {
            for (uint8_t n = 0; n < 3; n++) {
                uint8_t length;
                uint8_t fifo = bsp_nrf_read_reg(NRF_REG_FIFO_STATUS);
                radio_rx_diag.fifo = fifo;
                if (fifo == 0xFF) radio_rx_diag.ff++;
                if (fifo & NRF_FIFO_RX_EMPTY) break;
                length = bsp_nrf_read_packet(data, sizeof(data));
                radio_rx_diag.reads++;
                radio_rx_diag.length = length;
                radio_rx_diag.head[0] = length ? data[0] : 0xFF;
                radio_rx_diag.head[1] = length > 1 ? data[1] : 0xFF;
                if (fl_decode_control(&rx.control, data, length)) {
                    uint8_t advance = (uint8_t)(rx.control.seq - last_seq);
                    if (!seen || now - last_accepted > FC_LINK_TIMEOUT_MS || (advance && advance < 128)) {
                        seen = 1; last_seq = rx.control.seq; last_accepted = now;
                        rx.rx_tick = now;
                        xQueueOverwrite(commands, &rx);
                        radio_rx_diag.accepted++;
                        if (gap_stage) {
                            radio_snapshot(RADIO_BACK, 0, last_seq);
                            gap_stage = 0;
                        }
                    } else radio_rx_diag.old++;
                } else if (length) radio_rx_diag.bad++;
                else radio_rx_diag.zero++;
            }
            radio_rx_diag.status = bsp_nrf_write_reg(NRF_REG_STATUS, NRF_FLAG_RX_DR | NRF_FLAG_TX_DS);
            if (radio_rx_diag.status == 0xFF) radio_rx_diag.ff++;
            if (xQueuePeek(telemetry_queue, &telemetry, 0) == pdPASS) {
                fl_encode_telemetry(data, &telemetry);
                if (bsp_nrf_write_ack_payload(data, FL_TELEMETRY_LEN)) radio_rx_diag.ack++;
            }
            {
                uint32_t age = HAL_GetTick() - (seen ? last_accepted : started);
                if (!baseline) {
                    radio_snapshot(RADIO_BOOT, age, last_seq); baseline = 1;
                }
                if (!gap_stage && age >= 60U) {
                    radio_snapshot(RADIO_GAP, age, last_seq); gap_stage = 1;
                }
                if (gap_stage == 1 && age >= 180U) {
                    radio_snapshot(RADIO_LATE, age, last_seq); gap_stage = 2;
                }
            }
        }
        vTaskDelayUntil(&wake, pdMS_TO_TICKS(10));
        if (xTaskGetTickCount() - wake >= pdMS_TO_TICKS(10)) wake = xTaskGetTickCount();
    }
}

static void log_task(void *unused)
{
    fl_telemetry_t t;
    stop_event_t event;
    char line[224];
    uint32_t last_rx_log = HAL_GetTick() - 1000U;
    uint32_t printed[RADIO_SNAPSHOT_COUNT] = {0};
    static const char *const tags[] = {"BOOT", "GAP", "LATE", "BACK"};
    (void)unused;
    for (;;) {
        bsp_led_toggle();
        if (xQueueReceive(stop_queue, &event, 0) == pdPASS) {
            int length = snprintf(line, sizeof(line),
                "FC STOP t=%lu from=%u to=%u fault=%u cmd=%02X seq=%u thr=%d dt=%lu rx_age=%lu imu_age=%lu R=%d P=%d prevM=%u,%u,%u,%u\r\n",
                (unsigned long)event.tick, event.from, event.to, event.fault, event.cmd, event.seq,
                event.throttle, (unsigned long)event.dt_ms, (unsigned long)event.rx_age_ms,
                (unsigned long)event.imu_age_ms, event.roll_ddeg, event.pitch_ddeg,
                event.motors[0], event.motors[1], event.motors[2], event.motors[3]);
            if (length > 0 && length < (int)sizeof(line))
                HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
        }
        if (xQueuePeek(telemetry_queue, &t, 0) == pdPASS) {
            int length = snprintf(line, sizeof(line),
                "FC state=%u fault=%u flags=%02X R=%d P=%d H=%d V=%d M=%u,%u,%u,%u seq=%u\r\n",
                t.state, t.fault, t.flags, t.roll_ddeg, t.pitch_ddeg, t.height_cm, t.speed_cms,
                t.motors[0], t.motors[1], t.motors[2], t.motors[3], t.control_seq);
            if (length > 0 && length < (int)sizeof(line))
                HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
        }
        {
            control_diag_t d;
            int length;
            taskENTER_CRITICAL();
            d = control_diag;
            taskEXIT_CRITICAL();
            if (d.valid) {
                length = snprintf(line, sizeof(line),
                    "FC CTRL v1 t=%lu seq=%u st=%u thr=%d C=%u imu=%u A=%d,%d T=%d,%d E=%d,%d,%d I=%d,%d,%d sat=%02X/%02X blk=%02X M=%u,%u,%u,%u\r\n",
                    (unsigned long)d.tick, d.seq, d.state, d.throttle, d.collective, d.imu,
                    d.angle[0], d.angle[1], d.target[0], d.target[1],
                    d.rate_error[0], d.rate_error[1], d.rate_error[2],
                    d.integral[0], d.integral[1], d.integral[2],
                    d.sat_positive, d.sat_negative, d.blocked,
                    d.motors[0], d.motors[1], d.motors[2], d.motors[3]);
                if (length > 0 && length < (int)sizeof(line))
                    HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
                length = snprintf(line, sizeof(line),
                    "FC ALLOC v1 t=%lu Q=%d,%d,%d U=%d,%d,%d\r\n",
                    (unsigned long)d.tick, d.requested[0], d.requested[1], d.requested[2],
                    d.applied[0], d.applied[1], d.applied[2]);
                if (length > 0 && length < (int)sizeof(line))
                    HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
                length = snprintf(line, sizeof(line),
                    "FC ALT v1 t=%lu st=%u fault=%u active=%u H=%d HT=%d V=%d base=%d C=%u cap=%d I=%d age=%lu PID=%u,%u,%u\r\n",
                    (unsigned long)d.tick, d.state, d.fault, d.holding,
                    d.height, d.hold_height, d.vertical_speed, d.hold_base,
                    d.collective, d.hold_cap, d.height_i, (unsigned long)d.baro_age,
                    d.height_pid[0], d.height_pid[1], d.height_pid[2]);
                if (length > 0 && length < (int)sizeof(line))
                    HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
            }
        }
        if (HAL_GetTick() - last_rx_log >= 1000U) {
            radio_rx_diag_t d;
            uint32_t now;
            int length;
            /* Snapshot saved counters only; the log task never owns SPI2. */
            taskENTER_CRITICAL();
            d = radio_rx_diag;
            taskEXIT_CRITICAL();
            now = HAL_GetTick(); last_rx_log = now;
            length = snprintf(line, sizeof(line),
                "FC RX v1 t=%lu loops=%lu on=%u age=%lu fifo=%02X S=%02X read=%lu ok=%lu bad=%lu zero=%lu old=%lu ff=%lu ack=%lu len=%u head=%02X,%02X\r\n",
                (unsigned long)now, (unsigned long)d.loops, radio_ready,
                (unsigned long)(now - d.tick), d.fifo, d.status,
                (unsigned long)d.reads, (unsigned long)d.accepted, (unsigned long)d.bad,
                (unsigned long)d.zero, (unsigned long)d.old, (unsigned long)d.ff,
                (unsigned long)d.ack, d.length, d.head[0], d.head[1]);
            if (length > 0 && length < (int)sizeof(line))
                HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
        }
        for (uint8_t i = 0; i < RADIO_SNAPSHOT_COUNT; i++) {
            radio_snapshot_t s;
            nrf_snapshot_t *c = &s.chip;
            int length;
            taskENTER_CRITICAL();
            s = radio_snapshots[i];
            taskEXIT_CRITICAL();
            if (!s.number || printed[i] == s.number) continue;
            printed[i] = s.number;
            length = snprintf(line, sizeof(line),
                "FC RF v1 tag=%s n=%lu t=%lu span=%lu rx_age=%lu seq=%u read=%lu ok=%lu CE=%u CSN=%u CR1=%04lX valid=%03X\r\n",
                tags[i], (unsigned long)s.number, (unsigned long)c->tick,
                (unsigned long)c->elapsed_ms, (unsigned long)s.rx_age, s.seq,
                (unsigned long)s.read, (unsigned long)s.accepted, c->ce, c->csn,
                (unsigned long)c->cr1, c->valid);
            if (length > 0 && length < (int)sizeof(line))
                HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
            length = snprintf(line, sizeof(line),
                "FC REG tag=%s n=%lu C=%02X AA=%02X EN=%02X AW=%02X CH=%02X RF=%02X S=%02X FIFO=%02X PW=%02X FEAT=%02X DYN=%02X A=%02X%02X%02X%02X%02X\r\n",
                tags[i], (unsigned long)s.number, c->regs[NRF_SNAP_CONFIG],
                c->regs[NRF_SNAP_AA], c->regs[NRF_SNAP_EN], c->regs[NRF_SNAP_AW],
                c->regs[NRF_SNAP_CH], c->regs[NRF_SNAP_RF], c->regs[NRF_SNAP_STATUS],
                c->regs[NRF_SNAP_FIFO], c->regs[NRF_SNAP_PW], c->regs[NRF_SNAP_FEATURE],
                c->regs[NRF_SNAP_DYNPD], c->address[0], c->address[1], c->address[2],
                c->address[3], c->address[4]);
            if (length > 0 && length < (int)sizeof(line))
                HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
            length = snprintf(line, sizeof(line),
                "FC SPI tag=%s n=%lu calls=%lu halerr=%lu badS=%lu max_ms=%lu fail_t=%lu op=%02X H=%u E=%08lX S=%02X\r\n",
                tags[i], (unsigned long)s.number, (unsigned long)c->io.calls,
                (unsigned long)c->io.hal_errors, (unsigned long)c->io.bad_status,
                (unsigned long)c->io.max_ms, (unsigned long)c->io.fail_tick,
                c->io.command, c->io.hal, (unsigned long)c->io.spi_error, c->io.status);
            if (length > 0 && length < (int)sizeof(line))
                HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 30);
        }
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void flight_app_start(void)
{
    i2c_startup_diag_t bus;
    nrf_error_t error;
    nrf_error_t first_error = {0};
    const mpu_init_diag_t *imu;
    config_probe_t probes[3];
    uint8_t probe_count = 0;
    uint8_t radio_attempts;
    char line[128];
    int length;
    for (uint8_t i = 0; i < 4; i++) {
        __HAL_TIM_SET_COMPARE(&htim3, channels[i], 0);
        if (HAL_TIM_PWM_Start(&htim3, channels[i]) != HAL_OK) fatal();
    }
    bsp_i2c_startup(&bus);
    imu_ready = bsp_mpu6050_init();
    baro_ready = FC_BARO_ENABLED ? bsp_spa06_init() : 0;
    /* Retry only before tasks/arming; every attempt must pass the full verification. */
    for (radio_attempts = 1; ; radio_attempts++) {
        radio_ready = bsp_nrf_init() == 0;
        if (radio_ready) break;
        if (radio_attempts == 1) bsp_nrf_get_error(&first_error);
        if (radio_attempts == 3) break;
        HAL_Delay(50);
    }
    bsp_nrf_get_error(&error);
    /* Diagnostic only: preserve the original failure and never enable RX after a probe. */
    if (!radio_ready && error.reg == NRF_REG_CONFIG) {
        for (; probe_count < 3U; probe_count++) {
            config_probe_t *p = &probes[probe_count];
            nrf_error_t io;
            p->ms = HAL_GetTick();
            p->write_status = bsp_nrf_write_reg(NRF_REG_CONFIG, 0x0C);
            bsp_nrf_get_error(&io);
            p->write_hal = io.hal; p->write_error = io.spi_error;
            p->value = bsp_nrf_read_reg(NRF_REG_CONFIG);
            bsp_nrf_get_error(&io);
            p->read_hal = io.hal; p->read_error = io.spi_error;
        }
    }
    HAL_GPIO_WritePin(CE_GPIO_Port, CE_Pin, radio_ready ? GPIO_PIN_SET : GPIO_PIN_RESET);
    length = snprintf(line, sizeof(line),
        "\r\nFC NORMAL v3 BARO_ENABLE=%u MCU=F411RCT6\r\nFC SPI DIAG v3\r\nRTOS v3 IMU=%u STEP=%u ID=%02X BARO=%u RADIO=%u MAP=%u\r\n",
        FC_BARO_ENABLED, imu_ready, bsp_mpu6050_init_step(), bsp_mpu6050_whoami(),
        baro_ready, radio_ready, FC_GEOMETRY_CONFIRMED);
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    length = snprintf(line, sizeof(line), "FC M3 TRIM ratio_pct=%d\r\n", fixed16(FC_M3_TRIM_RATIO, 100));
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    length = snprintf(line, sizeof(line),
        "FC TRIM v1 R_zero_ddeg=%d P_zero_ddeg=%d front_pct=%d left_stick=live\r\n",
        fixed16(FC_LEVEL_ROLL_ZERO_DEG, 10), fixed16(FC_LEVEL_PITCH_ZERO_DEG, 10),
        fixed16(FC_FRONT_TRIM_RATIO, 100));
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    length = snprintf(line, sizeof(line), "RADIO BOOT tries=%u ready=%u\r\n", radio_attempts, radio_ready);
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    length = snprintf(line, sizeof(line),
        "FC CONTROL v3 cap_pct=%d,%d,%d smooth_ms=%d,%d i_start_pct=%d aw=axis\r\n",
        fixed16(FC_GEAR1_DUTY, 100), fixed16(FC_GEAR2_DUTY, 100), fixed16(FC_MAX_DUTY, 100),
        fixed16(FC_THROTTLE_FILTER_S, 1000), fixed16(FC_ANGLE_FILTER_S, 1000),
        fixed16(FC_I_ENABLE_DUTY, 100));
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    if (radio_attempts > 1) {
        length = snprintf(line, sizeof(line),
            "RADIO FIRST FAIL reg=%02X want=%02X got=%02X HAL=%u SPI=%08lX\r\n",
            first_error.reg, first_error.expected, first_error.actual, first_error.hal,
            (unsigned long)first_error.spi_error);
        if (length > 0 && length < (int)sizeof(line))
            HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    }
    if (!radio_ready) {
        length = snprintf(line, sizeof(line),
            "RADIO INIT FAIL reg=%02X want=%02X got=%02X HAL=%u SPI=%08lX\r\n",
            error.reg, error.expected, error.actual, error.hal, (unsigned long)error.spi_error);
        if (length > 0 && length < (int)sizeof(line))
            HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    }
    for (uint8_t i = 0; i < error.boot_count; i++) {
        const nrf_spi_diag_t *d = &error.boot_io[i];
        length = snprintf(line, sizeof(line),
            "RADIO SPI n=%u t=%lu cmd=%02X tx=%02X bytes=%u raw=%02X,%02X HAL=%u E=%08lX valid=%u csn=%u->%u CE=%u\r\n",
            i + 1U, (unsigned long)d->ms, d->command, d->tx_data, d->bytes,
            d->status, d->rx_data, d->hal, (unsigned long)d->spi_error, d->valid,
            d->csn_active, d->csn_idle, d->ce);
        if (length > 0 && length < (int)sizeof(line))
            HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    }
    for (uint8_t i = 0; i < probe_count; i++) {
        const config_probe_t *p = &probes[i];
        length = snprintf(line, sizeof(line),
            "RADIO PROBE n=%u t=%lu W=%02X WH=%u WE=%08lX want=0C got=%02X RH=%u RE=%08lX\r\n",
            i + 1U, (unsigned long)p->ms, p->write_status, p->write_hal,
            (unsigned long)p->write_error, p->value, p->read_hal, (unsigned long)p->read_error);
        if (length > 0 && length < (int)sizeof(line))
            HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    }
    /* Print saved measurements after initialization, never inside the sample loop. */
    imu = bsp_mpu6050_init_diag();
    length = snprintf(line, sizeof(line),
        "MPU CHECK v1 stable=%u N=%u ms=%lu win=%u rej=%02X badA=%u badV=%u badD=%u\r\n",
        imu->stable, imu->settle_samples, (unsigned long)imu->settle_ms,
        imu->settle_windows, imu->settle_reject, imu->settle_bad_accel,
        imu->settle_bad_variance, imu->settle_bad_drift);
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    length = snprintf(line, sizeof(line),
        "MPU IO t=%lu reg=%02X HAL=%u E=%08lX SR1=%04lX SR2=%04lX pins=%u%u\r\n",
        (unsigned long)imu->io_ms, imu->reg, imu->hal_status,
        (unsigned long)imu->i2c_error, (unsigned long)imu->sr1,
        (unsigned long)imu->sr2, imu->scl, imu->sda);
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    length = snprintf(line, sizeof(line),
        "MPU RANGE GYR=%02X/%u ACC=%02X/%u\r\n",
        imu->range_value[0], imu->range_status[0], imu->range_value[1], imu->range_status[1]);
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    length = snprintf(line, sizeof(line),
        "MPU RAW A=%d,%d,%d G=%d,%d,%d norm_mg=%d..%d\r\n",
        imu->settle_accel[0], imu->settle_accel[1], imu->settle_accel[2],
        imu->settle_gyro[0], imu->settle_gyro[1], imu->settle_gyro[2],
        fixed16(sqrtf(imu->settle_accel_min_sq), 1000),
        fixed16(sqrtf(imu->settle_accel_max_sq), 1000));
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    length = snprintf(line, sizeof(line),
        "MPU QUIET mean_cds=%d,%d,%d std_cds=%d,%d,%d delta_cds=%d,%d,%d\r\n",
        fixed16(imu->settle_mean[0], 100), fixed16(imu->settle_mean[1], 100),
        fixed16(imu->settle_mean[2], 100),
        fixed16(sqrtf(fmaxf(imu->settle_variance[0], 0)), 100),
        fixed16(sqrtf(fmaxf(imu->settle_variance[1], 0)), 100),
        fixed16(sqrtf(fmaxf(imu->settle_variance[2], 0)), 100),
        fixed16(imu->settle_delta[0], 100), fixed16(imu->settle_delta[1], 100),
        fixed16(imu->settle_delta[2], 100));
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 100);
    commands = xQueueCreate(1, sizeof(received_t));
    telemetry_queue = xQueueCreate(1, sizeof(fl_telemetry_t));
    stop_queue = xQueueCreate(1, sizeof(stop_event_t));
    if (!commands || !telemetry_queue || !stop_queue ||
        xTaskCreate(control_task, "control", 640, 0, 4, 0) != pdPASS ||
        xTaskCreate(radio_task, "radio", 384, 0, 3, 0) != pdPASS ||
        xTaskCreate(log_task, "log", 384, 0, 1, 0) != pdPASS) fatal();
    vTaskStartScheduler();
    fatal();
}
