#ifndef FLIGHT_CONTROL_H
#define FLIGHT_CONTROL_H
#include "flight_link.h"
#include "bsp_mpu6050.h"

typedef struct {
    uint8_t state, fault, armed, geometry_ok, hover_seq, height_samples;
    uint8_t param_rev, param_id;
    uint16_t parameters[FL_PARAM_COUNT], motors[4];
    float integral[2], previous_rate[2], derivative[2], yaw_integral, height_integral;
    float angle_target[2];
    /* Controller request and allocated correction before PWM quantization.
       Axis bits: roll=1, pitch=2, yaw=4; positive/negative are torque directions. */
    float rate_error[3], requested[3], applied[3];
    uint8_t sat_positive, sat_negative, integrator_blocked;
    float reference_pressure, height, vertical_speed;
    float hold_height, hold_throttle, hold_cap, collective, handover_bias;
    int16_t takeover_stick;
    uint32_t baro_tick;
} fc_state_t;

void fc_init(fc_state_t *state);
void fc_pressure(fc_state_t *state, float pressure_pa, float temperature_c,
                 uint32_t now_ms);
void fc_mix(float collective, float roll, float pitch, float yaw,
            float cap, uint16_t motors[4]);
void fc_step(fc_state_t *state, const fl_control_t *command,
             const mpu_attitude_t *attitude, uint8_t imu_valid,
             uint32_t last_rx_ms, uint32_t now_ms, float dt);
#endif
