#include "bsp_mpu6050.h"
#include "flight_config.h"
#include "i2c.h"
#include <math.h>
#include <string.h>

#define MPU_ADDR (0x68U << 1)
#define RAD_TO_DEG 57.29578f
#define DEG_TO_RAD 0.017453293f
#define MPU_CONFIG_ATTEMPTS 3U
#define MPU_STABLE_WINDOW 100U
#define MPU_SETTLE_TIMEOUT_MS 3000U
static float gyro_bias[3];
static uint8_t started, init_step, whoami;
static mpu_init_diag_t init_diag;

uint8_t bsp_mpu6050_init_step(void) { return init_step; }
uint8_t bsp_mpu6050_whoami(void) { return whoami; }
const mpu_init_diag_t *bsp_mpu6050_init_diag(void) { return &init_diag; }
static int16_t be16(const uint8_t *p) { return (int16_t)(((uint16_t)p[0] << 8) | p[1]); }
static void record_io(HAL_StatusTypeDef status, uint8_t reg, uint8_t write)
{
    uint32_t pins;
    init_diag.io_ms = HAL_GetTick();
    init_diag.hal_status = (uint8_t)status;
    init_diag.reg = reg; init_diag.write = write;
    init_diag.i2c_error = hi2c1.ErrorCode;
    /* SR2 first avoids the SR1-then-SR2 sequence that clears ADDR. */
    init_diag.sr2 = hi2c1.Instance->SR2;
    init_diag.sr1 = hi2c1.Instance->SR1;
    pins = GPIOB->IDR;
    init_diag.scl = (uint8_t)((pins >> 6) & 1U);
    init_diag.sda = (uint8_t)((pins >> 7) & 1U);
}
static uint8_t init_result(uint8_t result)
{
    init_diag.end_ms = HAL_GetTick();
    return result;
}
static uint8_t write_reg(uint8_t reg, uint8_t value)
{
    HAL_StatusTypeDef status = HAL_I2C_Mem_Write(&hi2c1, MPU_ADDR, reg, I2C_MEMADD_SIZE_8BIT, &value, 1, 5);
    if (init_diag.write_count < MPU_DIAG_WRITES) {
        mpu_write_diag_t *w = &init_diag.writes[init_diag.write_count++];
        w->ms = HAL_GetTick(); w->reg = reg; w->value = value;
        w->status = (uint8_t)status; w->error = hi2c1.ErrorCode;
    }
    if (status != HAL_OK) record_io(status, reg, 1);
    return status == HAL_OK;
}
static uint8_t read_reg(uint8_t reg, uint8_t *value)
{
    HAL_StatusTypeDef status = HAL_I2C_Mem_Read(&hi2c1, MPU_ADDR, reg,
        I2C_MEMADD_SIZE_8BIT, value, 1, 5);
    if (status != HAL_OK) record_io(status, reg, 0);
    return status == HAL_OK;
}
static uint8_t wait_fresh_sample(void)
{
    uint8_t ready;
    uint32_t start;
    HAL_Delay(20);
    /* Clear the old event before waiting for data produced with the new ranges. */
    if (!read_reg(0x3A, &ready)) return 0;
    start = HAL_GetTick();
    for (;;) {
        if (!read_reg(0x3A, &ready)) return 0;
        if (ready & 1U) return 1;
        if (HAL_GetTick() - start >= 30U) {
            record_io(HAL_TIMEOUT, 0x3A, 0);
            return 0;
        }
        HAL_Delay(1);
    }
}
static HAL_StatusTypeDef read_sample(uint8_t b[14])
{
    return HAL_I2C_Mem_Read(&hi2c1, MPU_ADDR, 0x3B, I2C_MEMADD_SIZE_8BIT, b, 14, 3);
}

static uint8_t verify_reg(uint8_t reg, uint8_t expected)
{
    uint8_t value = 0xFF;
    uint8_t ok = read_reg(reg, &value);
    init_diag.verify_reg = reg; init_diag.verify_value = value;
    init_diag.verify_expected = expected;
    init_diag.verify_status = ok ? (uint8_t)HAL_OK : init_diag.hal_status;
    if (reg == 0x1B || reg == 0x1C) {
        init_diag.range_value[reg - 0x1B] = value;
        init_diag.range_status[reg - 0x1B] = init_diag.verify_status;
    }
    if (!ok) return 0;
    if (value != expected) { record_io(HAL_OK, reg, 0); return 0; }
    return 1;
}

static uint8_t configure_sensor(void)
{
    const uint8_t regs[6] = {0x6B, 0x1A, 0x19, 0x1B, 0x1C, 0x38};
    const uint8_t values[6] = {0x01, 0x03, 0x03, 0x08, 0x08, 0x01};
    HAL_StatusTypeDef status;
    init_step = 1; whoami = 0xFF;
    memset(init_diag.range_value, 0xFF, sizeof(init_diag.range_value));
    memset(init_diag.range_status, 0xFF, sizeof(init_diag.range_status));
    init_diag.verify_reg = init_diag.verify_value = init_diag.verify_expected = init_diag.verify_status = 0xFF;
    status = HAL_I2C_Mem_Read(&hi2c1, MPU_ADDR, 0x75, I2C_MEMADD_SIZE_8BIT, &whoami, 1, 10);
    record_io(status, 0x75, 0);
    if (status != HAL_OK) return 0;
    init_step = 2;
    if (whoami != 0x68) return 0;
    init_step = 3;
    if (!write_reg(0x6B, 0x01)) return 0;
    HAL_Delay(100);
    if (!verify_reg(0x6B, 0x01)) return 0;
    /* 250 Hz, DLPF 42 Hz, gyro +/-500 dps, accel +/-4 g. */
    init_step = 4;
    for (uint8_t i = 1; i < 6; i++) if (!write_reg(regs[i], values[i])) return 0;
    for (uint8_t i = 0; i < 6; i++) if (!verify_reg(regs[i], values[i])) return 0;
    return 1;
}

static uint8_t wait_stable_data(void)
{
    uint8_t b[14], valid = 1, previous_valid = 0;
    uint16_t n = 0;
    float sum[3] = {0}, sum_sq[3] = {0}, previous[3] = {0};
    uint32_t start = HAL_GetTick();
    while (HAL_GetTick() - start < MPU_SETTLE_TIMEOUT_MS) {
        float norm_sq = 0;
        HAL_StatusTypeDef status = read_sample(b);
        if (status != HAL_OK) {
            record_io(status, 0x3B, 0);
            init_diag.settle_reject = MPU_SETTLE_IO;
            init_diag.settle_ms = HAL_GetTick() - start;
            return 0;
        }
        init_diag.settle_samples++;
        for (uint8_t i = 0; i < 3; i++) {
            float accel, rate;
            init_diag.settle_accel[i] = be16(&b[2 * i]);
            init_diag.settle_gyro[i] = be16(&b[8 + 2 * i]);
            accel = init_diag.settle_accel[i] / 8192.0f;
            rate = init_diag.settle_gyro[i] / 65.5f;
            norm_sq += accel * accel;
            sum[i] += rate; sum_sq[i] += rate * rate;
        }
        if (init_diag.settle_samples == 1 || norm_sq < init_diag.settle_accel_min_sq)
            init_diag.settle_accel_min_sq = norm_sq;
        if (init_diag.settle_samples == 1 || norm_sq > init_diag.settle_accel_max_sq)
            init_diag.settle_accel_max_sq = norm_sq;
        if (norm_sq < 0.64f || norm_sq > 1.44f) {
            init_diag.settle_bad_accel++;
            valid = 0;
        }
        HAL_Delay(4);
        if (++n == MPU_STABLE_WINDOW) {
            uint8_t matched = previous_valid;
            uint8_t reject = valid ? 0 : MPU_SETTLE_ACCEL;
            init_diag.settle_windows++;
            if (!previous_valid) reject |= MPU_SETTLE_PREVIOUS;
            for (uint8_t i = 0; i < 3; i++) {
                float mean = sum[i] / MPU_STABLE_WINDOW;
                float variance = sum_sq[i] / MPU_STABLE_WINDOW - mean * mean;
                float delta = fabsf(mean - previous[i]);
                init_diag.settle_mean[i] = mean;
                init_diag.settle_variance[i] = variance;
                init_diag.settle_delta[i] = delta;
                if (variance > 4.0f) { valid = 0; reject |= MPU_SETTLE_VARIANCE; }
                if (delta > 0.5f) {
                    matched = 0;
                    if (previous_valid) reject |= MPU_SETTLE_DRIFT;
                }
                previous[i] = mean;
            }
            init_diag.settle_reject = reject;
            if (reject & MPU_SETTLE_VARIANCE) init_diag.settle_bad_variance++;
            if (reject & MPU_SETTLE_DRIFT) init_diag.settle_bad_drift++;
            /* Two quiet 400 ms windows must agree before a separate calibration. */
            if (valid && matched) {
                init_diag.stable = 1;
                init_diag.settle_ms = HAL_GetTick() - start;
                return 1;
            }
            previous_valid = valid;
            n = 0; valid = 1;
            memset(sum, 0, sizeof(sum)); memset(sum_sq, 0, sizeof(sum_sq));
        }
    }
    init_diag.settle_ms = HAL_GetTick() - start;
    record_io(HAL_OK, 0x3B, 0);
    return 0;
}

void bsp_mpu6050_read_init_diag(mpu_init_diag_t *diagnostic)
{
    const uint8_t regs[3] = {0x6B, 0x1B, 0x1C};
    if (!diagnostic) return;
    *diagnostic = init_diag;
    diagnostic->config_ms = HAL_GetTick();
    for (uint8_t i = 0; i < 3; i++) {
        diagnostic->config[i] = 0xFF;
        diagnostic->config_status[i] = (uint8_t)HAL_I2C_Mem_Read(&hi2c1, MPU_ADDR, regs[i],
            I2C_MEMADD_SIZE_8BIT, &diagnostic->config[i], 1, 5);
        diagnostic->config_error[i] = hi2c1.ErrorCode;
    }
}

uint8_t bsp_mpu6050_init(void)
{
    uint8_t b[14];
    HAL_StatusTypeDef status;
    float sum[3] = {0}, sum_sq[3] = {0};
    started = 0; init_step = 1; whoami = 0xFF;
    memset(&init_diag, 0, sizeof(init_diag));
    init_diag.start_ms = HAL_GetTick();
    for (uint8_t attempt = 0; attempt < MPU_CONFIG_ATTEMPTS; attempt++) {
        init_diag.attempts++;
        if (configure_sensor()) break;
        if (attempt + 1U == MPU_CONFIG_ATTEMPTS) return init_result(0);
        HAL_Delay(50);
    }
    init_step = 9;
    if (!wait_fresh_sample()) return init_result(0);
    init_step = 10;
    if (!wait_stable_data()) return init_result(0);
    init_step = 5;
    /* Calibration must finish with motors stopped; moving the craft is rejected. */
    for (uint16_t n = 0; n < 500; n++) {
        float ax, ay, az;
        mpu_gyro_segment_diag_t *segment = &init_diag.gyro_segments[n / MPU_DIAG_SEGMENT_SAMPLES];
        status = read_sample(b);
        if (status != HAL_OK) {
            record_io(status, 0x3B, 0);
            return init_result(0);
        }
        init_diag.samples = n + 1U;
        for (uint8_t i = 0; i < 3; i++) {
            init_diag.last_accel[i] = be16(&b[2 * i]);
            if (n == 0) init_diag.first_accel[i] = init_diag.last_accel[i];
        }
        ax = be16(&b[0]) / 8192.0f; ay = be16(&b[2]) / 8192.0f; az = be16(&b[4]) / 8192.0f;
        if (ax * ax + ay * ay + az * az < 0.64f || ax * ax + ay * ay + az * az > 1.44f) {
            init_step = 6;
            return init_result(0);
        }
        for (uint8_t i = 0; i < 3; i++) {
            int16_t raw = be16(&b[8 + i * 2]);
            float rate = raw / 65.5f;
            sum[i] += rate; sum_sq[i] += rate * rate;
            init_diag.gyro_sum[i] = sum[i]; init_diag.gyro_sum_sq[i] = sum_sq[i];
            segment->sum[i] += raw;
            if (!segment->samples || raw < segment->minimum[i]) segment->minimum[i] = raw;
            if (!segment->samples || raw > segment->maximum[i]) segment->maximum[i] = raw;
        }
        segment->samples++;
        init_diag.gyro_samples = n + 1U;
        HAL_Delay(4);
    }
    for (uint8_t i = 0; i < 3; i++) {
        gyro_bias[i] = sum[i] / 500;
        if (fabsf(gyro_bias[i]) > 25.0f) {
            init_step = 7;
            return init_result(0);
        }
        if (sum_sq[i] / 500 - gyro_bias[i] * gyro_bias[i] > 4.0f) {
            init_step = 8;
            return init_result(0);
        }
    }
    init_step = 0;
    return init_result(1);
}

uint8_t bsp_mpu6050_update(float dt, mpu_attitude_t *a)
{
    uint8_t b[14];
    float accel[3], gyro[3], body[3], norm, roll_acc, pitch_acc, alpha;
    if (!a || !isfinite(dt) || dt < 0.001f || dt > 0.012f || read_sample(b) != HAL_OK) return 0;
    for (uint8_t i = 0; i < 3; i++) {
        accel[i] = be16(&b[2 * i]) / 8192.0f;
        gyro[i] = be16(&b[8 + 2 * i]) / 65.5f - gyro_bias[i];
    }
    a->accel_g[0] = FC_BODY_X(accel); a->accel_g[1] = FC_BODY_Y(accel); a->accel_g[2] = FC_BODY_Z(accel);
    body[0] = FC_BODY_X(gyro); body[1] = FC_BODY_Y(gyro); body[2] = FC_BODY_Z(gyro);
    alpha = dt / (0.006f + dt);
    for (uint8_t i = 0; i < 3; i++) a->rate_dps[i] += alpha * (body[i] - a->rate_dps[i]);
    norm = sqrtf(a->accel_g[0] * a->accel_g[0] + a->accel_g[1] * a->accel_g[1] + a->accel_g[2] * a->accel_g[2]);
    /* Gravity is needed to align initially, not to propagate a valid gyro attitude. */
    if (!started && norm < 0.1f) return 0;
    roll_acc = atan2f(-a->accel_g[1], -a->accel_g[2]) * RAD_TO_DEG;
    pitch_acc = atan2f(a->accel_g[0], sqrtf(a->accel_g[1] * a->accel_g[1] +
                       a->accel_g[2] * a->accel_g[2])) * RAD_TO_DEG;
    if (!started) {
        a->roll_deg = roll_acc; a->pitch_deg = pitch_acc; started = 1;
    } else {
        float r = a->roll_deg * DEG_TO_RAD, p = a->pitch_deg * DEG_TO_RAD;
        if (fabsf(p) > 1.3f) return 0;
        a->roll_deg += dt * (a->rate_dps[0] + tanf(p) *
                       (a->rate_dps[1] * sinf(r) + a->rate_dps[2] * cosf(r)));
        a->pitch_deg += dt * (a->rate_dps[1] * cosf(r) - a->rate_dps[2] * sinf(r));
        /* Ignore acceleration corrections under strong thrust or free fall. */
        if (norm > 0.85f && norm < 1.15f) {
            float blend = dt / (0.5f + dt);
            float roll_error = roll_acc - a->roll_deg;
            if (roll_error > 180) roll_error -= 360;
            if (roll_error < -180) roll_error += 360;
            a->roll_deg += blend * roll_error;
            a->pitch_deg += blend * (pitch_acc - a->pitch_deg);
        }
    }
    return isfinite(a->roll_deg) && isfinite(a->pitch_deg);
}
