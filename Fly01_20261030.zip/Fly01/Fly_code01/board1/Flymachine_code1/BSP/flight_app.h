#ifndef FLIGHT_APP_H
#define FLIGHT_APP_H
void flight_app_start(void);
void flight_emergency_stop(void);
#endif
