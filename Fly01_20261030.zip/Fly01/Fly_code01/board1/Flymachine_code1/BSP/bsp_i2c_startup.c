#include "bsp_i2c_startup.h"
#include "flight_config.h"
#include "i2c.h"
#include <string.h>

static uint8_t scl_high(void)
{
    uint32_t start = HAL_GetTick();
    while (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6) == GPIO_PIN_RESET) {
        if (HAL_GetTick() - start >= 5U) return 0;
        HAL_Delay(1);
    }
    return 1;
}

static uint8_t device_ready(uint16_t address)
{
    uint32_t start = HAL_GetTick();
    while (HAL_GetTick() - start < 100U) {
        if (HAL_I2C_IsDeviceReady(&hi2c1, address, 1, 5) == HAL_OK) return 1;
        HAL_Delay(5);
    }
    return 0;
}

void bsp_i2c_startup(i2c_startup_diag_t *d)
{
    GPIO_InitTypeDef pins = {0};
    uint8_t clock_ok;
    HAL_StatusTypeDef status;
    if (!d) return;
    memset(d, 0, sizeof(*d));
    d->start_ms = HAL_GetTick();
    HAL_Delay(50);
    HAL_I2C_DeInit(&hi2c1);
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /* Open-drain SET releases the lines; never drive either line high. */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6 | GPIO_PIN_7, GPIO_PIN_SET);
    pins.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    pins.Mode = GPIO_MODE_OUTPUT_OD;
    pins.Pull = GPIO_NOPULL;
    pins.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &pins);
    clock_ok = scl_high();
    d->scl_before = (uint8_t)HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6);
    d->sda_before = (uint8_t)HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7);
    if (clock_ok && !d->sda_before) {
        for (uint8_t n = 0; n < 9; n++) {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
            HAL_Delay(1);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
            if (!scl_high()) { clock_ok = 0; break; }
            d->pulses++;
            HAL_Delay(1);
        }
        if (clock_ok) {
            /* STOP: SDA low, release SCL, then release SDA with SCL high. */
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
            HAL_Delay(1);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
            clock_ok = scl_high();
            HAL_Delay(1);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
            HAL_Delay(1);
        }
    }
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6 | GPIO_PIN_7, GPIO_PIN_SET);
    d->scl_after = (uint8_t)HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6);
    d->sda_after = (uint8_t)HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7);
    /* DeInit sets RESET, so Init restores the original AF4 pins and 400 kHz. */
    status = HAL_I2C_Init(&hi2c1);
    if (status == HAL_OK && clock_ok && d->scl_after && d->sda_after) {
        if (device_ready(0x68U << 1)) d->ready_mask |= 1U;
        if (FC_BARO_ENABLED && device_ready(0x76U << 1)) d->ready_mask |= 2U;
    }
    d->end_ms = HAL_GetTick();
}
