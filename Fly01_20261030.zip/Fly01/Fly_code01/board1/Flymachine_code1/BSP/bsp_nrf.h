#ifndef BSP_NRF_H
#define BSP_NRF_H
#include "main.h"

/* G01-S / Si24R1. Both endpoints use 2440 MHz, 1 Mbps, 2-byte CRC. */
#define NRF_RADIO_CHANNEL 40U
#define NRF_SPI_TIMEOUT_MS 3U

#define NRF_CMD_R_REGISTER    0x00U
#define NRF_CMD_W_REGISTER    0x20U
#define NRF_CMD_R_RX_PL_WID   0x60U
#define NRF_CMD_R_RX_PAYLOAD  0x61U
#define NRF_CMD_W_ACK_PAYLOAD 0xA8U
#define NRF_CMD_FLUSH_TX      0xE1U
#define NRF_CMD_FLUSH_RX      0xE2U

#define NRF_REG_CONFIG       0x00U
#define NRF_REG_EN_AA        0x01U
#define NRF_REG_EN_RXADDR    0x02U
#define NRF_REG_SETUP_AW     0x03U
#define NRF_REG_SETUP_RETR   0x04U
#define NRF_REG_RF_CH        0x05U
#define NRF_REG_RF_SETUP     0x06U
#define NRF_REG_STATUS       0x07U
#define NRF_REG_RX_ADDR_P0   0x0AU
#define NRF_REG_RX_PW_P0     0x11U
#define NRF_REG_FIFO_STATUS  0x17U
#define NRF_REG_DYNPD        0x1CU
#define NRF_REG_FEATURE      0x1DU

#define NRF_FIFO_RX_EMPTY    0x01U
#define NRF_FIFO_TX_EMPTY    0x10U
#define NRF_FLAG_RX_DR       0x40U
#define NRF_FLAG_TX_DS       0x20U
#define NRF_FLAG_CLR_ALL     0x70U

typedef struct {
    uint32_t ms, spi_error;
    uint8_t command, tx_data, status, rx_data, bytes, hal, valid;
    uint8_t csn_active, csn_idle, ce;
} nrf_spi_diag_t;

/* First two existing boot transactions are retained, without extra SPI commands. */
typedef struct {
    uint32_t spi_error;
    uint8_t reg, expected, actual, hal;
    uint8_t boot_count;
    nrf_spi_diag_t boot_io[2];
} nrf_error_t;

typedef struct {
    uint32_t calls, hal_errors, bad_status, max_ms;
    uint32_t fail_tick, spi_error;
    uint8_t command, hal, status;
} nrf_io_diag_t;

enum { NRF_SNAP_CONFIG, NRF_SNAP_AA, NRF_SNAP_EN, NRF_SNAP_AW,
       NRF_SNAP_CH, NRF_SNAP_RF, NRF_SNAP_STATUS, NRF_SNAP_FIFO,
       NRF_SNAP_PW, NRF_SNAP_FEATURE, NRF_SNAP_DYNPD, NRF_SNAP_REG_COUNT };
typedef struct {
    uint32_t tick, elapsed_ms, cr1;
    nrf_io_diag_t io;
    uint16_t valid;
    uint8_t regs[NRF_SNAP_REG_COUNT], address[5], ce, csn;
} nrf_snapshot_t;

/* Init runs before the scheduler. Afterwards only radio_task owns SPI2. */
uint8_t bsp_nrf_init(void); /* 0: verified PRX configuration; CE remains low. */
void bsp_nrf_get_error(nrf_error_t *out);
/* Read-only diagnostic, radio_task only; aborts on the first transport failure. */
void bsp_nrf_snapshot(nrf_snapshot_t *out);
uint8_t bsp_nrf_read_reg(uint8_t reg); /* 0xFF on failed/invalid SPI response. */
uint8_t bsp_nrf_write_reg(uint8_t reg, uint8_t value); /* STATUS, or 0xFF on failure. */
uint8_t bsp_nrf_read_packet(uint8_t *buf, uint8_t capacity);
uint8_t bsp_nrf_write_ack_payload(const uint8_t *buf, uint8_t len);
#endif
