#include "bsp_nrf.h"
#include "flight_link.h"
#include "spi.h"
#include <string.h>

/* Si24R1 datasheet sections 5/6: Mode 0, MSB first, one CSN window per command. */
static nrf_error_t last_error;
static nrf_io_diag_t io_diag;

void bsp_nrf_get_error(nrf_error_t *out)
{
    if (out) *out = last_error;
}

static uint8_t transfer(uint8_t command, const uint8_t *data, uint8_t *out, uint8_t len)
{
    uint8_t tx[33], rx[33] = {0};
    HAL_StatusTypeDef result;
    uint32_t started, elapsed;
    nrf_spi_diag_t *diag = NULL;
    if (len > 32U) return 0xFF;
    tx[0] = command;
    if (data) memcpy(tx + 1, data, len);
    else memset(tx + 1, 0xFF, len);

    if (last_error.boot_count < 2U) {
        diag = &last_error.boot_io[last_error.boot_count++];
        diag->ms = HAL_GetTick();
        diag->command = command;
        diag->tx_data = len ? tx[1] : 0;
        diag->bytes = len + 1U;
    }
    started = HAL_GetTick();
    HAL_GPIO_WritePin(CSN_GPIO_Port, CSN_Pin, GPIO_PIN_RESET);
    if (diag) diag->csn_active = !!(CSN_GPIO_Port->IDR & CSN_Pin);
    result = HAL_SPI_TransmitReceive(&hspi2, tx, rx, len + 1U, NRF_SPI_TIMEOUT_MS);
    HAL_GPIO_WritePin(CSN_GPIO_Port, CSN_Pin, GPIO_PIN_SET);
    last_error.hal = (uint8_t)result;
    last_error.spi_error = hspi2.ErrorCode;
    elapsed = HAL_GetTick() - started;
    io_diag.calls++;
    if (elapsed > io_diag.max_ms) io_diag.max_ms = elapsed;
    if (result != HAL_OK) io_diag.hal_errors++;
    else if (rx[0] & 0x80U) io_diag.bad_status++;
    if (result != HAL_OK || (rx[0] & 0x80U)) {
        io_diag.fail_tick = HAL_GetTick(); io_diag.command = command;
        io_diag.hal = (uint8_t)result; io_diag.spi_error = hspi2.ErrorCode;
        io_diag.status = rx[0];
    }
    if (diag) {
        diag->status = rx[0];
        diag->rx_data = len ? rx[1] : 0;
        diag->hal = (uint8_t)result;
        diag->spi_error = hspi2.ErrorCode;
        diag->valid = result == HAL_OK && !(rx[0] & 0x80U);
        diag->csn_idle = !!(CSN_GPIO_Port->IDR & CSN_Pin);
        diag->ce = !!(CE_GPIO_Port->IDR & CE_Pin);
    }
    /* STATUS bit 7 is reserved zero. Never expose a partially received buffer. */
    if (result != HAL_OK || (rx[0] & 0x80U)) return 0xFF;
    if (out) memcpy(out, rx + 1, len);
    return rx[0];
}

void bsp_nrf_snapshot(nrf_snapshot_t *out)
{
    static const uint8_t regs[] = {NRF_REG_CONFIG, NRF_REG_EN_AA, NRF_REG_EN_RXADDR,
        NRF_REG_SETUP_AW, NRF_REG_RF_CH, NRF_REG_RF_SETUP, NRF_REG_STATUS,
        NRF_REG_FIFO_STATUS, NRF_REG_RX_PW_P0, NRF_REG_FEATURE, NRF_REG_DYNPD};
    if (!out) return;
    memset(out, 0, sizeof(*out));
    memset(out->regs, 0xFF, sizeof(out->regs));
    memset(out->address, 0xFF, sizeof(out->address));
    out->tick = HAL_GetTick();
    out->ce = !!(CE_GPIO_Port->IDR & CE_Pin);
    out->csn = !!(CSN_GPIO_Port->IDR & CSN_Pin);
    out->cr1 = hspi2.Instance->CR1;
    for (uint8_t i = 0; i < sizeof(regs); i++) {
        if (transfer(NRF_CMD_R_REGISTER | regs[i], NULL, &out->regs[i], 1) == 0xFF)
            goto done;
        out->valid |= (uint16_t)(1U << i);
    }
    if (transfer(NRF_CMD_R_REGISTER | NRF_REG_RX_ADDR_P0, NULL, out->address, 5) != 0xFF)
        out->valid |= (uint16_t)(1U << NRF_SNAP_REG_COUNT);
done:
    out->elapsed_ms = HAL_GetTick() - out->tick;
    out->io = io_diag;
}

uint8_t bsp_nrf_read_reg(uint8_t reg)
{
    uint8_t value = 0xFF;
    if (reg > NRF_REG_FEATURE) return 0xFF;
    transfer(NRF_CMD_R_REGISTER | reg, NULL, &value, 1);
    return value;
}

uint8_t bsp_nrf_write_reg(uint8_t reg, uint8_t value)
{
    if (reg > NRF_REG_FEATURE) return 0xFF;
    return transfer(NRF_CMD_W_REGISTER | reg, &value, NULL, 1);
}

static uint8_t write_verified(uint8_t reg, uint8_t value)
{
    last_error.reg = reg;
    last_error.expected = value;
    last_error.actual = 0xFF;
    if (bsp_nrf_write_reg(reg, value) == 0xFF) return 0;
    last_error.actual = bsp_nrf_read_reg(reg);
    return last_error.actual == value;
}

uint8_t bsp_nrf_init(void)
{
    static const uint8_t address[5] = {0xA1, 0xB2, 0xC3, 0xD4, 0xE5};
    static const uint8_t settings[][2] = {
        {NRF_REG_CONFIG, 0x0C}, /* Power down while configuring, 2-byte CRC. */
        {NRF_REG_EN_AA, 0x01},
        {NRF_REG_EN_RXADDR, 0x01},
        {NRF_REG_SETUP_AW, 0x03},
        {NRF_REG_SETUP_RETR, 0x1A},
        {NRF_REG_RF_CH, NRF_RADIO_CHANNEL},
        {NRF_REG_RF_SETUP, 0x06}, /* Si24R1: 1 Mbps, +4 dBm. */
        {NRF_REG_RX_PW_P0, FL_CONTROL_LEN},
        {NRF_REG_FEATURE, 0x06}, /* ACK payload and dynamic payload length. */
        {NRF_REG_DYNPD, 0x01}
    };
    uint8_t actual[5] = {0};
    memset(&last_error, 0, sizeof(last_error));
    memset(&io_diag, 0, sizeof(io_diag));
    HAL_GPIO_WritePin(CE_GPIO_Port, CE_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(CSN_GPIO_Port, CSN_Pin, GPIO_PIN_SET);
    /* Establish the idle clock before selecting the radio, also after MCU reset. */
    __HAL_SPI_ENABLE(&hspi2);
    /* Datasheet figure 3-1: cold power-on takes 100 ms. Also lets an old ACK finish. */
    HAL_Delay(100);
    for (uint8_t i = 0; i < sizeof(settings) / sizeof(settings[0]); i++)
        if (!write_verified(settings[i][0], settings[i][1])) return 1;

    last_error.reg = NRF_REG_RX_ADDR_P0;
    last_error.expected = address[0]; last_error.actual = 0xFF;
    if (transfer(NRF_CMD_W_REGISTER | NRF_REG_RX_ADDR_P0, address, NULL, 5) == 0xFF ||
        transfer(NRF_CMD_R_REGISTER | NRF_REG_RX_ADDR_P0, NULL, actual, 5) == 0xFF) return 1;
    for (uint8_t i = 0; i < sizeof(address); i++) {
        if (actual[i] != address[i]) {
            last_error.expected = address[i]; last_error.actual = actual[i];
            return 1;
        }
    }

    /* Radio FIFOs survive MCU reset, including the queued ACK telemetry. */
    last_error.reg = NRF_REG_FIFO_STATUS;
    last_error.expected = NRF_FIFO_TX_EMPTY | NRF_FIFO_RX_EMPTY;
    last_error.actual = 0xFF;
    if (transfer(NRF_CMD_FLUSH_TX, NULL, NULL, 0) == 0xFF ||
        transfer(NRF_CMD_FLUSH_RX, NULL, NULL, 0) == 0xFF ||
        bsp_nrf_write_reg(NRF_REG_STATUS, NRF_FLAG_CLR_ALL) == 0xFF) return 1;
    last_error.actual = bsp_nrf_read_reg(NRF_REG_FIFO_STATUS);
    if (last_error.actual != last_error.expected) return 1;
    if (!write_verified(NRF_REG_CONFIG, 0x0F)) return 1;
    HAL_Delay(2);
    return 0;
}

uint8_t bsp_nrf_read_packet(uint8_t *buf, uint8_t capacity)
{
    uint8_t width = 0;
    if (!buf || !capacity) return 0;
    if (transfer(NRF_CMD_R_RX_PL_WID, NULL, &width, 1) == 0xFF) return 0;
    if (!width || width > 32 || width > capacity) {
        /* Do not flush RX while the radio could still be transmitting an ACK. */
        HAL_GPIO_WritePin(CE_GPIO_Port, CE_Pin, GPIO_PIN_RESET);
        HAL_Delay(1);
        transfer(NRF_CMD_FLUSH_RX, NULL, NULL, 0);
        HAL_GPIO_WritePin(CE_GPIO_Port, CE_Pin, GPIO_PIN_SET);
        return 0;
    }
    return transfer(NRF_CMD_R_RX_PAYLOAD, NULL, buf, width) == 0xFF ? 0 : width;
}

uint8_t bsp_nrf_write_ack_payload(const uint8_t *buf, uint8_t len)
{
    uint8_t fifo;
    if (!buf || !len || len > 32) return 0;
    fifo = bsp_nrf_read_reg(NRF_REG_FIFO_STATUS);
    /* Keep one queued payload; retransmissions reuse it until the next new packet. */
    if (fifo == 0xFF || !(fifo & NRF_FIFO_TX_EMPTY)) return 0;
    return transfer(NRF_CMD_W_ACK_PAYLOAD, buf, NULL, len) != 0xFF;
}
