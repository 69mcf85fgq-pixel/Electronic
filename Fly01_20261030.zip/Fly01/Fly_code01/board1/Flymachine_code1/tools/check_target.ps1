$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
[xml]$project = Get-Content -LiteralPath "$root\MDK-ARM\Flymachine_code1.uvprojx" -Raw
$target = $project.Project.Targets.Target
if ($target.TargetOption.TargetCommonOption.Device -ne 'STM32F411RCTx') {
    throw 'Keil target must be STM32F411RCTx'
}
$memory = $target.TargetOption.TargetArmAds.ArmAdsMisc.OnChipMemories
foreach ($name in @('IROM', 'OCR_RVCT4')) {
    if ([Convert]::ToUInt32($memory.$name.StartAddress, 16) -ne 0x08000000 -or
        [Convert]::ToUInt32($memory.$name.Size, 16) -ne 0x40000) {
        throw "$name must describe 256 KB Flash at 0x08000000"
    }
}
if ([Convert]::ToUInt32($memory.IRAM.Size, 16) -ne 0x20000) { throw 'SRAM must remain 128 KB' }
if ($target.TargetOption.TargetArmAds.Cads.VariousControls.Define -notmatch '\bSTM32F411xE\b') {
    throw 'The ST CMSIS device macro for STM32F411RC is STM32F411xE'
}
$startup = @($target.Groups.Group.Files.File | Where-Object FileName -eq 'startup_stm32f411xe.s')
if ($startup.Count -ne 1 -or -not (Test-Path -LiteralPath "$root\MDK-ARM\startup_stm32f411xe.s")) {
    throw 'The shared STM32F411 startup must be present exactly once'
}
$ioc = Get-Content -LiteralPath "$root\Flymachine_code1.ioc" -Raw
foreach ($line in @('Mcu.CPN=STM32F411RCT6', 'Mcu.Name=STM32F411R(C-E)Tx',
    'Mcu.Package=LQFP64', 'Mcu.UserName=STM32F411RCTx', 'ProjectManager.DeviceId=STM32F411RCTx',
    'PA6.Signal=S_TIM3_CH1', 'PA7.Signal=S_TIM3_CH2', 'PB0.Signal=S_TIM3_CH3',
    'PB1.Signal=S_TIM3_CH4', 'PB13.Signal=SPI2_SCK', 'PB14.Signal=SPI2_MISO',
    'PB15.Signal=SPI2_MOSI', 'PB6.Signal=I2C1_SCL', 'PB7.Signal=I2C1_SDA',
    'RCC.HSE_VALUE=25000000')) {
    if ($ioc -notmatch ('(?m)^' + [regex]::Escape($line) + '\r?$')) { throw "CubeMX mismatch: $line" }
}
[xml]$options = Get-Content -LiteralPath "$root\MDK-ARM\Flymachine_code1.uvoptx" -Raw
$algorithms = @($options.ProjectOpt.Target.TargetOption.TargetDriverDllRegistry.SetRegEntry |
    Where-Object { $_.Key -in @('UL2CM3', 'ST-LINKIII-KEIL_SWO') })
if ($algorithms.Count -ne 2) { throw 'Missing debug/programming algorithm settings' }
foreach ($entry in $algorithms) {
    if ($entry.Name -notmatch 'STM32F4xx_256' -or $entry.Name -notmatch '\-FL040000\b' -or
        $entry.Name -notmatch 'Device:STM32F411RCTx') { throw "Wrong flash algorithm: $($entry.Key)" }
}
Write-Output 'PASS: STM32F411RCT6 / LQFP64, 256 KB Flash, 128 KB RAM, ST shared startup and retained peripheral pins'
