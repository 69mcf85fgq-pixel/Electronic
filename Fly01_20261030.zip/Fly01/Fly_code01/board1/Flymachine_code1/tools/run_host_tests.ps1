param([string]$Compiler = 'D:\MinGWDownload\bin\gcc.exe')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
& "$PSScriptRoot\check_target.ps1"
$out = Join-Path $root 'tests\out'
New-Item -ItemType Directory -Path $out -Force | Out-Null
$env:PATH = (Split-Path -Parent $Compiler) + ';' + $env:PATH
foreach ($test in @('config','flight','flight_no_baro','mpu','baro','runtime','runtime_no_baro','i2c_startup','i2c_startup_no_baro')) {
    $sourceTest = $test -replace '_no_baro$', ''
    $sources = @(Join-Path $root "tests\test_$sourceTest.c")
    $mock = Join-Path $root 'tests\mock'
    $extraFlags = @()
    if ($sourceTest -in @('flight','runtime','i2c_startup')) {
        $enabled = if ($test -like '*_no_baro') { 0 } else { 1 }
        $extraFlags += "-DFC_BARO_ENABLED=$enabled"
    }
    if ($sourceTest -in @('flight','runtime')) {
        # Match Cortex-M4 float evaluation; mingw32 x87 otherwise retains excess precision at thresholds.
        $extraFlags += @('-msse2', '-mfpmath=sse', '-DFC_M3_TRIM_RATIO=0.0f')
        $sources += Join-Path $root 'BSP\flight_control.c'
        $sources += Join-Path $root 'BSP\flight_link.c'
    } elseif ($sourceTest -eq 'mpu') { $sources += Join-Path $root 'BSP\bsp_mpu6050.c' }
    elseif ($sourceTest -eq 'i2c_startup') { $sources += Join-Path $root 'BSP\bsp_i2c_startup.c' }
    elseif ($sourceTest -eq 'baro') { $sources += Join-Path $root 'BSP\bsp_spa06.c' }
    if ($sourceTest -eq 'runtime') {
        $mock = Join-Path $root 'tests\runtime_mock'
    }
    $exe = Join-Path $out "$test.exe"
    & $Compiler -std=c11 -Wall -Wextra -Werror @extraFlags "-I$mock" "-I$root\BSP" @sources -lm -o $exe
    if ($LASTEXITCODE -ne 0) { throw "$test compilation failed" }
    & $exe
    if ($LASTEXITCODE -ne 0) { throw "$test assertions failed" }
}
& "$PSScriptRoot\run_radio_checks.ps1" -Compiler $Compiler

$m3exe = Join-Path $out 'm3_trim.exe'
& $Compiler -std=c11 -Wall -Wextra -Werror -msse2 -mfpmath=sse "-I$root/tests/mock" "-I$root/BSP" (Join-Path $root 'tests/test_m3_trim.c') (Join-Path $root 'BSP/flight_control.c') (Join-Path $root 'BSP/flight_link.c') -lm -o $m3exe
if ($LASTEXITCODE -ne 0) { throw 'M3 trim compilation failed' }
& $m3exe
if ($LASTEXITCODE -ne 0) { throw 'M3 trim assertions failed' }
