param([string]$Compiler = 'D:\MinGWDownload\bin\gcc.exe')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$base = Split-Path -Parent (Split-Path -Parent $root)
$rc = Join-Path $base 'board_control\Flymachine_rc1'
$out = Join-Path $root 'tests\out'
New-Item -ItemType Directory -Path $out -Force | Out-Null
$env:PATH = (Split-Path -Parent $Compiler) + ';' + $env:PATH
foreach ($test in @('nrf','nrf_failure')) {
    $exe = Join-Path $out "$test.exe"
    & $Compiler -std=c11 -Wall -Wextra -Werror "-I$root\tests\nrf_mock" "-I$root\BSP" "$root\tests\test_$test.c" "$root\BSP\bsp_nrf.c" -o $exe
    if ($LASTEXITCODE -ne 0) { throw "$test compilation failed" }
    & $exe
    if ($LASTEXITCODE -ne 0) { throw "$test assertions failed" }
}
foreach ($file in @('flight_link.c','flight_link.h')) {
    if ((Get-FileHash "$root\BSP\$file").Hash -ne (Get-FileHash "$rc\BSP\$file").Hash) {
        throw "Aircraft/remote protocol differs: $file"
    }
}
Write-Output 'PASS: aircraft and remote protocol sources are byte-identical'
