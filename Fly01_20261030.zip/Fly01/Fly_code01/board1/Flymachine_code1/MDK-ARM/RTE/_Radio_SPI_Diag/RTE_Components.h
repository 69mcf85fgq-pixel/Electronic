
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Radio_SPI_Diag' 
 * Target:  'Radio_SPI_Diag' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H



#endif /* RTE_COMPONENTS_H */
