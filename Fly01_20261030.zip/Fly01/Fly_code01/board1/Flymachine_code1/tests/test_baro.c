#include "bsp_spa06.h"
#include "i2c.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
I2C_HandleTypeDef hi2c1;
static uint8_t coefficients[21], registers[256], bus_failed;
static uint8_t sensor_id = 0x11, status = 0xF0;
static uint16_t failed_read = 0xFFFF, failed_write = 0xFFFF;
static uint32_t waited_ms, data_reads;
static int32_t raw_pressure, raw_temperature;
void HAL_Delay(uint32_t ms) { waited_ms += ms; }
HAL_StatusTypeDef HAL_I2C_Mem_Write(I2C_HandleTypeDef *i2c, uint16_t address, uint16_t reg,
                                  uint16_t size, uint8_t *data, uint16_t length, uint32_t timeout)
{
    (void)i2c; (void)size; (void)timeout;
    assert(address == 0xEC && length == 1);
    if (bus_failed || reg == failed_write) return HAL_ERROR;
    registers[reg] = data[0]; return HAL_OK;
}
HAL_StatusTypeDef HAL_I2C_Mem_Read(I2C_HandleTypeDef *i2c, uint16_t address, uint16_t reg,
                                 uint16_t size, uint8_t *data, uint16_t length, uint32_t timeout)
{
    (void)i2c; (void)size; (void)timeout;
    assert(address == 0xEC);
    if (bus_failed || reg == failed_read) return HAL_ERROR;
    if (reg == 0x0D) { assert(length == 1); data[0] = sensor_id; }
    else if (reg == 8) { assert(length == 1); data[0] = status; }
    else if (reg == 0x10) { assert(length == 21); memcpy(data, coefficients, 21); }
    else {
        assert(reg == 0 && length == 6);
        memset(data, 0, 6);
        data[0] = (uint8_t)(raw_pressure >> 16);
        data[1] = (uint8_t)(raw_pressure >> 8);
        data[2] = (uint8_t)raw_pressure;
        data[3] = (uint8_t)(raw_temperature >> 16);
        data[4] = (uint8_t)(raw_temperature >> 8);
        data[5] = (uint8_t)raw_temperature;
        data_reads++;
    }
    return HAL_OK;
}

static void pair12(uint8_t *p, int32_t first, int32_t second)
{
    p[0] = (uint8_t)((uint32_t)first >> 4);
    p[1] = (uint8_t)(((uint32_t)first & 15U) << 4 | ((uint32_t)second >> 8 & 15U));
    p[2] = (uint8_t)second;
}

static void pair20(uint8_t *p, int32_t first, int32_t second)
{
    p[0] = (uint8_t)((uint32_t)first >> 12);
    p[1] = (uint8_t)((uint32_t)first >> 4);
    p[2] = (uint8_t)(((uint32_t)first & 15U) << 4 | ((uint32_t)second >> 16 & 15U));
    p[3] = (uint8_t)((uint32_t)second >> 8); p[4] = (uint8_t)second;
}

static void signed_coefficients(void)
{
    const int16_t terms[5] = {-30, 20, -40, 50, -60};
    spa06_data_t out;
    pair12(coefficients, 50, -10);
    pair20(&coefficients[3], 101325, -1000);
    for (unsigned i = 0; i < 5; i++) {
        coefficients[8 + 2 * i] = (uint8_t)((uint16_t)terms[i] >> 8);
        coefficients[9 + 2 * i] = (uint8_t)terms[i];
    }
    pair12(&coefficients[18], -70, -80);
    assert(bsp_spa06_init());
    raw_pressure = 3932160; raw_temperature = 262144; /* p=0.5, t=0.5 */
    assert(bsp_spa06_read(&out));
    assert(fabsf(out.pressure_pa - 100794.375f) < 0.02f && out.temperature_dC == 200);
    raw_pressure = -3932160; raw_temperature = -262144;
    assert(bsp_spa06_read(&out));
    assert(fabsf(out.pressure_pa - 101826.875f) < 0.02f && out.temperature_dC == 300);
    memset(coefficients, 0, sizeof(coefficients));
    pair12(coefficients, -20, 100); pair20(&coefficients[3], -100000, 400000);
    assert(bsp_spa06_init());
    raw_pressure = 3932160; raw_temperature = 262144;
    assert(bsp_spa06_read(&out));
    assert(fabsf(out.pressure_pa - 100000) < 0.02f && out.temperature_dC == 400);
    raw_pressure = 7864320; assert(!bsp_spa06_read(&out));
    raw_pressure = 3932160; raw_temperature = 1048576;
    assert(!bsp_spa06_read(&out));
}

static void failure_cases(void)
{
    spa06_data_t out, saved;
    const uint8_t not_ready[] = {0xC0, 0xD0, 0xE0};
    const uint8_t read_regs[] = {0x0D, 0x10};
    const uint8_t write_regs[] = {6, 7, 9, 8};
    bus_failed = 0; raw_temperature = 262144;
    assert(bsp_spa06_read(&out)); memcpy(&saved, &out, sizeof(out));
    for (unsigned i = 0; i < sizeof(not_ready); i++) {
        uint32_t count = data_reads;
        status = not_ready[i]; assert(!bsp_spa06_read(&out));
        assert(count == data_reads && !memcmp(&out, &saved, sizeof(out)));
    }
    status = 0xF0; failed_read = 0;
    assert(!bsp_spa06_read(&out) && !memcmp(&out, &saved, sizeof(out)));
    failed_read = 0xFFFF; assert(!bsp_spa06_read(NULL));
    sensor_id = 0x10; assert(!bsp_spa06_init()); sensor_id = 0x11;
    status = 0; waited_ms = 0;
    assert(!bsp_spa06_init() && waited_ms == 100); status = 0xF0;
    for (unsigned i = 0; i < sizeof(read_regs); i++) {
        failed_read = read_regs[i]; assert(!bsp_spa06_init());
    }
    failed_read = 0xFFFF;
    for (unsigned i = 0; i < sizeof(write_regs); i++) {
        failed_write = write_regs[i]; assert(!bsp_spa06_init());
    }
    failed_write = 0xFFFF; assert(bsp_spa06_init());
}
int main(void)
{
    spa06_data_t before, after;
    const uint32_t c00 = 101325;
    coefficients[0] = 3; coefficients[1] = 0x20; /* c0=50 -> 25 C */
    coefficients[3] = (uint8_t)(c00 >> 12);
    coefficients[4] = (uint8_t)(c00 >> 4);
    coefficients[5] = (uint8_t)((c00 & 15U) << 4);
    coefficients[6] = 1; coefficients[7] = 0xF4; /* c10=500 */
    assert(bsp_spa06_init());
    assert(registers[6] == 0x53 && registers[7] == 0x50 && registers[9] == 0 && registers[8] == 7);
    assert(bsp_spa06_read(&before));
    assert(fabsf(before.pressure_pa - 101325) < 0.1f && before.temperature_dC == 250);
    raw_pressure = 62914; /* 4 Pa, smaller than the legacy 10 Pa telemetry quantum */
    assert(bsp_spa06_read(&after));
    assert(after.pressure_pa - before.pressure_pa > 3.5f);
    assert(after.pressure_pa - before.pressure_pa < 4.5f);
    assert(after.pressure_dhpa == before.pressure_dhpa);
    raw_pressure = -62914; assert(bsp_spa06_read(&after));
    assert(before.pressure_pa - after.pressure_pa > 3.5f);
    bus_failed = 1; assert(!bsp_spa06_read(&after)); bus_failed = 0;
    signed_coefficients(); failure_cases();
    puts("PASS: SPA06 signed coefficients/samples, full compensation, 32 Hz configuration, sub-10 Pa precision, ready bits, range and I2C failures");
    return 0;
}
