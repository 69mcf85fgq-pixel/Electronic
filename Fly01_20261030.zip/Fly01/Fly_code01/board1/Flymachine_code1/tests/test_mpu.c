#include "bsp_mpu6050.h"
#include "i2c.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static I2C_TypeDef mock_i2c;
I2C_HandleTypeDef hi2c1 = {&mock_i2c, 0};
GPIO_TypeDef mock_gpio_b;
static int16_t sample[7] = {0, 0, 8192, 0, 0, 0, 0};
static uint8_t registers[256], bus_failed, sample_bus_failed, alternate_gyro;
static HAL_StatusTypeDef bus_status = HAL_ERROR;
static unsigned sample_count, read_count, write_count, sample_reads, bad_accel_at;
static uint32_t tick, delay_count, delay_total;
static uint8_t simulate_scale_change;
static uint32_t scale_valid_tick;
static uint32_t next_data_tick;
static uint8_t no_data_ready, status_read_failed, wrong_range;
static uint8_t ignore_writes, fail_write_reg, gyro_warmup;
static unsigned wake_writes, ignore_wake_attempts;
static uint8_t ignore_once_reg;
static uint8_t wrong_register, drifting_gyro;
static unsigned sample_failure_at, noisy_gyro_after;
void HAL_Delay(uint32_t ms) { tick += ms; delay_total += ms; delay_count++; }
uint32_t HAL_GetTick(void) { return tick; }
HAL_StatusTypeDef HAL_I2C_Mem_Write(I2C_HandleTypeDef *i2c, uint16_t address, uint16_t reg,
                                  uint16_t size, uint8_t *data, uint16_t length, uint32_t timeout)
{
    (void)i2c; (void)size; (void)timeout;
    assert(address == 0xD0 && length == 1);
    write_count++;
    if (reg == 0x6B) wake_writes++;
    if (bus_failed) return bus_status;
    if (reg == fail_write_reg) { hi2c1.ErrorCode = 4; return HAL_ERROR; }
    if (ignore_writes || wake_writes <= ignore_wake_attempts) return HAL_OK;
    if (reg == ignore_once_reg) { ignore_once_reg = 0; return HAL_OK; }
    registers[reg] = data[0];
    if (reg == 0x1C && simulate_scale_change) scale_valid_tick = tick + 4U;
    if (reg == 0x38) next_data_tick = tick;
    return HAL_OK;
}
HAL_StatusTypeDef HAL_I2C_Mem_Read(I2C_HandleTypeDef *i2c, uint16_t address, uint16_t reg,
                                 uint16_t size, uint8_t *data, uint16_t length, uint32_t timeout)
{
    (void)i2c; (void)size; (void)timeout;
    assert(address == 0xD0);
    read_count++;
    if (bus_failed) return bus_status;
    if (reg == 0x75) { assert(length == 1); data[0] = 0x68; }
    else if (reg == 0x3A) {
        assert(length == 1 && (registers[0x38] & 1U));
        if (status_read_failed) { hi2c1.ErrorCode = 0x20; return HAL_BUSY; }
        data[0] = !no_data_ready && (int32_t)(tick - next_data_tick) >= 0;
        if (data[0]) next_data_tick = tick + 4U;
    } else if (reg == 0x3B) {
        assert(length == 14);
        sample_reads++;
        if (sample_bus_failed || (sample_failure_at && sample_reads == sample_failure_at)) return HAL_ERROR;
        int16_t gyro_x = alternate_gyro && (sample_count++ & 1U) ? 300 : sample[4];
        for (unsigned i = 0; i < 7; i++) {
            int16_t value = i == 4 ? gyro_x : sample[i];
            if (gyro_warmup && i >= 4)
                value = sample_reads <= 100 ? (i == 4 ? 655 : i == 5 ? -655 : 1310) : 0;
            if (drifting_gyro && i == 4) value = (int16_t)(sample_reads * 2U);
            if (noisy_gyro_after && sample_reads > noisy_gyro_after && i == 4)
                value = sample_reads & 1U ? 300 : 0;
            if (simulate_scale_change && i < 3 && (int32_t)(tick - scale_valid_tick) < 0)
                value = (int16_t)(value * 2);
            if (bad_accel_at && sample_reads == bad_accel_at && i < 3)
                value = i == 2 ? 16384 : 0;
            data[2 * i] = (uint8_t)((uint16_t)value >> 8);
            data[2 * i + 1] = (uint8_t)value;
        }
    } else {
        assert(length == 1 && (reg == 0x6B || (reg >= 0x19 && reg <= 0x1C) || reg == 0x38));
        data[0] = registers[reg];
        if (wrong_range && reg == 0x1C) data[0] = 0;
        if (reg == wrong_register) data[0] = reg == 0x6B ? 0x41 : 0;
    }
    return HAL_OK;
}
static void reset_sensor(void)
{
    memset(sample, 0, sizeof(sample)); sample[2] = 8192;
    assert(bsp_mpu6050_init());
    assert(registers[0x1A] == 3 && registers[0x19] == 3);
    assert(registers[0x1B] == 8 && registers[0x1C] == 8);
}

static void startup_diagnostics(void)
{
    mpu_init_diag_t d;
    memset(sample, 0, sizeof(sample)); sample[2] = 8192;
    memset(registers, 0, sizeof(registers));
    tick = 10; read_count = write_count = sample_reads = delay_count = delay_total = 0;
    mock_gpio_b.IDR = (1U << 6) | (1U << 7);
    assert(bsp_mpu6050_init());
    /* Verified configuration, fresh data, 200 stable samples, then 500 calibration samples. */
    assert(read_count == 714 && write_count == 6 && delay_count == 706 && delay_total == 2924);
    bsp_mpu6050_read_init_diag(&d);
    assert(read_count == 717 && write_count == 6 && delay_count == 706);
    assert(d.start_ms == 10 && d.end_ms == 2934 && d.io_ms == 10 && d.samples == 500);
    assert(d.hal_status == HAL_OK && d.reg == 0x75 && !d.write && d.scl && d.sda);
    assert(d.first_accel[2] == 8192 && d.last_accel[2] == 8192);
    assert(d.config_ms == 2934 && d.config[0] == 1 && d.config[1] == 8 && d.config[2] == 8);
    assert(d.attempts == 1 && d.stable && d.settle_samples == 200 && d.settle_ms == 800);
    assert(d.settle_windows == 2 && !d.settle_reject);
    assert(!d.settle_bad_accel && !d.settle_bad_variance && !d.settle_bad_drift);
    assert(d.settle_accel[2] == 8192 && d.settle_accel_min_sq == 1 && d.settle_accel_max_sq == 1);
    for (unsigned axis = 0; axis < 3; axis++) {
        assert(!d.settle_gyro[axis] && d.settle_mean[axis] == 0);
        assert(d.settle_variance[axis] == 0 && d.settle_delta[axis] == 0);
    }
    assert(d.verify_reg == 0x38 && d.verify_value == 1 && d.verify_expected == 1 && d.verify_status == HAL_OK);
    assert(d.write_count == 6 && d.gyro_samples == 500);
    const uint8_t write_regs[6] = {0x6B, 0x1A, 0x19, 0x1B, 0x1C, 0x38};
    const uint8_t write_values[6] = {1, 3, 3, 8, 8, 1};
    for (unsigned i = 0; i < 6; i++) {
        assert(d.writes[i].reg == write_regs[i] && d.writes[i].value == write_values[i]);
        assert(d.writes[i].status == HAL_OK && !d.writes[i].error);
        assert(d.writes[i].ms == (i ? 110U : 10U));
    }
    assert(d.range_value[0] == 8 && d.range_value[1] == 8);
    assert(d.range_status[0] == HAL_OK && d.range_status[1] == HAL_OK);
    for (unsigned segment = 0; segment < 5; segment++) {
        assert(d.gyro_segments[segment].samples == 100);
        for (unsigned axis = 0; axis < 3; axis++) {
            assert(d.gyro_sum[axis] == 0 && d.gyro_sum_sq[axis] == 0);
            assert(d.gyro_segments[segment].sum[axis] == 0);
            assert(d.gyro_segments[segment].minimum[axis] == 0);
            assert(d.gyro_segments[segment].maximum[axis] == 0);
        }
    }
    for (unsigned i = 0; i < 3; i++) assert(d.config_status[i] == HAL_OK && !d.config_error[i]);

    for (unsigned status = HAL_ERROR; status <= HAL_TIMEOUT; status++) {
        tick = 20; read_count = write_count = delay_count = delay_total = 0;
        bus_failed = 1; bus_status = (HAL_StatusTypeDef)status;
        hi2c1.ErrorCode = status == HAL_BUSY ? 0 : 0x20;
        mock_i2c.SR1 = 0x80; mock_i2c.SR2 = 2; mock_gpio_b.IDR = 1U << 6;
        assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 1 && bsp_mpu6050_whoami() == 0xFF);
        assert(read_count == 3 && !write_count && delay_count == 2 && delay_total == 100);
        /* Later accesses must not overwrite the original failure snapshot. */
        tick = 170; hi2c1.ErrorCode = 4; mock_i2c.SR1 = mock_i2c.SR2 = 0; mock_gpio_b.IDR = 0;
        bsp_mpu6050_read_init_diag(&d);
        assert(d.start_ms == 20 && d.end_ms == 120 && d.io_ms == 120 && !d.samples);
        assert(d.attempts == 3 && !d.stable && !d.settle_samples);
        assert(!d.write_count && !d.gyro_samples);
        assert(d.range_status[0] == 0xFF && d.range_status[1] == 0xFF);
        assert(d.hal_status == status && d.i2c_error == (status == HAL_BUSY ? 0U : 0x20U));
        assert(d.sr1 == 0x80 && d.sr2 == 2 && d.scl == 1 && d.sda == 0);
        assert(read_count == 6 && !write_count && delay_count == 2);
        for (unsigned i = 0; i < 3; i++) {
            assert(d.config[i] == 0xFF && d.config_status[i] == status && d.config_error[i] == 4);
        }
    }
    bus_failed = 0; bus_status = HAL_ERROR; hi2c1.ErrorCode = 0;
    sample[2] = 16384; read_count = write_count = sample_reads = delay_count = delay_total = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 10);
    assert(read_count == 764 && write_count == 6 && delay_count == 756 && delay_total == 3124);
    bsp_mpu6050_read_init_diag(&d);
    assert(!d.samples && !d.stable && d.settle_samples == 750 && d.settle_ms == 3000);
    assert(d.settle_windows == 7 && d.settle_bad_accel == 750);
    assert(d.settle_reject == (MPU_SETTLE_ACCEL | MPU_SETTLE_PREVIOUS));
    assert(!d.settle_bad_variance && !d.settle_bad_drift);
    assert(d.settle_accel_min_sq == 4 && d.settle_accel_max_sq == 4);
    assert(!d.gyro_samples && !d.gyro_segments[0].samples);
    assert(d.config[2] == 8 && d.config_status[2] == HAL_OK);

    sample[2] = 8192; bad_accel_at = 208; sample_reads = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 6);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.samples == 8 && d.first_accel[2] == 8192 && d.last_accel[2] == 16384);
    assert(d.gyro_samples == 7 && d.gyro_segments[0].samples == 7);
    for (unsigned segment = 1; segment < 5; segment++) assert(!d.gyro_segments[segment].samples);
    bad_accel_at = 0; sample_bus_failed = 1;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 10);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.hal_status == HAL_ERROR && d.reg == 0x3B && !d.write && !d.samples);
    assert(d.settle_reject == MPU_SETTLE_IO && !d.settle_samples && !d.settle_windows);
    sample_bus_failed = 0;

    tick = 0; sample_reads = 0; no_data_ready = 1;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 9);
    bsp_mpu6050_read_init_diag(&d);
    assert(!sample_reads && !d.samples && d.end_ms == 150);
    assert(d.hal_status == HAL_TIMEOUT && d.reg == 0x3A && !d.write);
    no_data_ready = 0; status_read_failed = 1;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 9);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.hal_status == HAL_BUSY && d.i2c_error == 0x20 && !d.samples);
    status_read_failed = 0; hi2c1.ErrorCode = 0;

    wrong_range = 1;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 4);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.reg == 0x1C && !d.samples && d.config[2] == 0);
    assert(d.range_value[0] == 8 && d.range_value[1] == 0 && d.range_status[1] == HAL_OK);
    wrong_range = 0;
    tick = UINT32_MAX - 110U;
    assert(bsp_mpu6050_init());
    bsp_mpu6050_read_init_diag(&d);
    assert(d.end_ms - d.start_ms == 2924 && d.samples == 500);
}

static void configuration_and_gyro_diagnostics(void)
{
    mpu_init_diag_t d;
    memset(sample, 0, sizeof(sample)); sample[2] = 8192;
    memset(registers, 0, sizeof(registers)); registers[0x6B] = 0x41;
    ignore_writes = 1; tick = 0;
    read_count = write_count = sample_reads = delay_count = delay_total = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 3);
    assert(read_count == 6 && write_count == 3 && delay_count == 5 && delay_total == 400);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.write_count == 3 && d.writes[0].value == 1 && d.writes[0].status == HAL_OK);
    assert(d.attempts == 3 && d.verify_reg == 0x6B && d.verify_value == 0x41 && d.verify_expected == 1);
    assert(d.range_value[0] == 0xFF && d.range_status[0] == 0xFF);
    assert(d.range_value[1] == 0xFF && d.range_status[1] == 0xFF);
    assert(d.config[0] == 0x41 && d.config[1] == 0 && d.config[2] == 0 && !d.gyro_samples);
    ignore_writes = 0; fail_write_reg = 0x1B;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 4);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.write_count == 12 && d.writes[3].reg == 0x1B && d.writes[3].value == 8);
    assert(d.attempts == 3);
    assert(d.writes[3].status == HAL_ERROR && d.writes[3].error == 4);
    assert(d.range_status[0] == 0xFF && !d.gyro_samples);
    fail_write_reg = 0; hi2c1.ErrorCode = 0;

    gyro_warmup = 1; sample_reads = 0; tick = 0;
    read_count = write_count = delay_count = delay_total = 0;
    assert(bsp_mpu6050_init() && bsp_mpu6050_init_step() == 0);
    assert(read_count == 814 && write_count == 6 && delay_count == 806 && delay_total == 3324);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.gyro_samples == 500 && d.gyro_segments[0].samples == 100);
    assert(d.stable && d.settle_samples == 300 && d.settle_ms == 1200);
    assert(d.settle_windows == 3 && !d.settle_reject && d.settle_bad_drift == 1);
    assert(!d.settle_bad_accel && !d.settle_bad_variance);
    for (unsigned axis = 0; axis < 3; axis++) {
        assert(d.gyro_sum[axis] == 0 && d.gyro_sum_sq[axis] == 0);
        for (unsigned segment = 0; segment < 5; segment++) {
            assert(d.gyro_segments[segment].samples == 100);
            assert(d.gyro_segments[segment].sum[axis] == 0);
            assert(d.gyro_segments[segment].minimum[axis] == 0 && d.gyro_segments[segment].maximum[axis] == 0);
        }
    }
    gyro_warmup = 0; noisy_gyro_after = 200; sample_count = sample_reads = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 8);
    bsp_mpu6050_read_init_diag(&d);
    for (unsigned segment = 0; segment < 5; segment++) {
        assert(d.gyro_segments[segment].samples == 100 && d.gyro_segments[segment].sum[0] == 15000);
        assert(d.gyro_segments[segment].minimum[0] == 0 && d.gyro_segments[segment].maximum[0] == 300);
    }
    noisy_gyro_after = 0;
}

static void startup_recovery(uint8_t warmup)
{
    mpu_init_diag_t d;
    memset(sample, 0, sizeof(sample)); sample[2] = 8192;
    memset(registers, 0, sizeof(registers)); registers[0x6B] = 0x41;
    tick = read_count = write_count = sample_reads = delay_count = delay_total = wake_writes = 0;
    ignore_wake_attempts = warmup ? 0 : 1;
    gyro_warmup = warmup;
    assert(bsp_mpu6050_init() && bsp_mpu6050_init_step() == 0);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.gyro_samples == 500 && d.samples == 500);
    assert(d.stable && d.settle_samples == (warmup ? 300U : 200U));
    for (unsigned i = 0; i < 3; i++) assert(d.gyro_sum[i] == 0 && d.gyro_sum_sq[i] == 0);
    if (warmup) assert(sample_reads > 600);
    else assert(wake_writes == 2);
    ignore_wake_attempts = gyro_warmup = 0;
}

static void bounded_startup_and_calibration(void)
{
    mpu_init_diag_t d;
    const uint8_t regs[6] = {0x6B, 0x1A, 0x19, 0x1B, 0x1C, 0x38};
    memset(sample, 0, sizeof(sample)); sample[2] = 8192;
    for (unsigned i = 0; i < 6; i++) {
        memset(registers, 0, sizeof(registers)); registers[0x6B] = 0x41;
        tick = wake_writes = sample_reads = 0;
        ignore_once_reg = regs[i];
        assert(bsp_mpu6050_init());
        bsp_mpu6050_read_init_diag(&d);
        assert(d.attempts == 2 && d.stable && d.samples == 500 && d.write_count <= MPU_DIAG_WRITES);

        wrong_register = regs[i]; tick = wake_writes = sample_reads = 0;
        assert(!bsp_mpu6050_init());
        assert(bsp_mpu6050_init_step() == (i ? 4 : 3));
        bsp_mpu6050_read_init_diag(&d);
        assert(d.attempts == 3 && d.verify_reg == regs[i] && d.verify_value != d.verify_expected);
        assert(!d.stable && !d.samples && !sample_reads && tick == 400);
        assert(d.write_count == (i ? 18 : 3));
        wrong_register = 0;
    }

    alternate_gyro = 1; sample_count = sample_reads = tick = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 10);
    bsp_mpu6050_read_init_diag(&d);
    assert(!d.stable && !d.samples && d.settle_ms == 3000 && d.settle_samples == 750);
    assert(d.settle_windows == 7 && d.settle_bad_variance == 7);
    assert(d.settle_reject == (MPU_SETTLE_VARIANCE | MPU_SETTLE_PREVIOUS));
    assert(!d.settle_bad_accel && !d.settle_bad_drift && d.settle_variance[0] > 4);
    alternate_gyro = 0; drifting_gyro = 1; sample_reads = tick = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 10);
    bsp_mpu6050_read_init_diag(&d);
    assert(!d.stable && !d.samples && d.settle_ms == 3000);
    assert(d.settle_windows == 7 && d.settle_bad_drift == 6 && d.settle_reject == MPU_SETTLE_DRIFT);
    assert(!d.settle_bad_accel && !d.settle_bad_variance);
    assert(d.settle_variance[0] < 4 && d.settle_delta[0] > 0.5f);
    drifting_gyro = 0;

    /* A fault after stability must still fail the original calibration, without retries. */
    sample_failure_at = 208; sample_reads = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 5);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.stable && d.attempts == 1 && d.samples == 7 && d.hal_status == HAL_ERROR);
    sample_failure_at = 0; sample[4] = 5000;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 7);
    bsp_mpu6050_read_init_diag(&d);
    assert(d.stable && d.attempts == 1 && d.samples == 500);
    sample[4] = 0;

    startup_recovery(0); startup_recovery(1);
    gyro_warmup = 1; sample_reads = 0; tick = UINT32_MAX - 200U;
    assert(bsp_mpu6050_init());
    bsp_mpu6050_read_init_diag(&d);
    assert(d.end_ms - d.start_ms == 3324 && d.settle_samples == 300 && d.samples == 500);
    gyro_warmup = 0;
}

static void saved_diagnostics_no_io(void)
{
    const mpu_init_diag_t *d;
    unsigned reads, writes;
    uint32_t delays, time;
    sample[0] = -321; sample[1] = 460; sample[2] = 7553;
    sample[4] = -9; sample[5] = 350; sample[6] = -94;
    sample_reads = 0;
    assert(bsp_mpu6050_init());
    reads = read_count; writes = write_count; delays = delay_count; time = tick;
    bus_failed = 1;
    d = bsp_mpu6050_init_diag();
    assert(read_count == reads && write_count == writes && delay_count == delays && tick == time);
    assert(d->stable && d->settle_windows == 2 && !d->settle_reject);
    assert(d->settle_accel[0] == -321 && d->settle_accel[1] == 460 && d->settle_accel[2] == 7553);
    for (unsigned axis = 0; axis < 3; axis++) {
        assert(d->settle_gyro[axis] == sample[axis + 4]);
        assert(fabsf(d->settle_mean[axis] - sample[axis + 4] / 65.5f) < 0.001f);
        assert(d->settle_delta[axis] == 0);
    }
    assert(d->settle_accel_min_sq > 0.85f && d->settle_accel_max_sq < 0.86f);
    bus_failed = 0; sample_failure_at = 50; sample_reads = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 10);
    reads = read_count; writes = write_count; delays = delay_count; time = tick;
    d = bsp_mpu6050_init_diag();
    assert(read_count == reads && write_count == writes && delay_count == delays && tick == time);
    assert(d->settle_samples == 49 && !d->settle_windows && d->settle_reject == MPU_SETTLE_IO);
    assert(d->hal_status == HAL_ERROR && d->reg == 0x3B && !d->samples);
    sample_failure_at = 0;
}

static void low_acceleration_keeps_gyro_prediction(void)
{
    mpu_attitude_t a = {0};
    reset_sensor();
    sample[2] = 410; sample[4] = 655;
    assert(!bsp_mpu6050_update(0.004f, &a)); /* No initial gravity reference yet. */
    memset(&a, 0, sizeof(a)); sample[2] = 8192; sample[4] = 0;
    assert(bsp_mpu6050_update(0.004f, &a));
    sample[4] = 655;
    for (unsigned phase = 0; phase < 3; phase++) {
        sample[2] = phase == 0 ? 410 : phase == 1 ? 0 : 16384;
        for (unsigned i = 0; i < 25; i++) assert(bsp_mpu6050_update(0.004f, &a));
        assert(a.roll_deg > (float)phase + 0.8f && a.roll_deg < (float)phase + 1.1f);
        assert(fabsf(a.pitch_deg) < 0.01f);
    }
    sample_bus_failed = 1; assert(!bsp_mpu6050_update(0.004f, &a));
    sample_bus_failed = 0; assert(!bsp_mpu6050_update(0.03f, &a));
    memset(sample, 0, sizeof(sample)); sample[2] = 8192;
    puts("PASS: initial gravity reference required; 0.05g/freefall/2g preserve gyro prediction; I2C and dt faults still rejected");
}

int main(int argc, char **argv)
{
    mpu_attitude_t a = {0};
    if (argc == 2) {
        startup_recovery(strcmp(argv[1], "warmup") == 0);
        return 0;
    }
    low_acceleration_keeps_gyro_prediction();
    simulate_scale_change = 1;
    assert(bsp_mpu6050_init());
    simulate_scale_change = 0;
    reset_sensor();
    assert(bsp_mpu6050_update(0.004f, &a));
    assert(fabsf(a.roll_deg) < 0.01f && fabsf(a.pitch_deg) < 0.01f);
    assert(a.accel_g[2] == -1);
    /* Actual driver must report right-down as +roll, nose-up as +pitch. */
    sample[1] = 1423; sample[2] = 8068;
    for (unsigned i = 0; i < 500; i++) assert(bsp_mpu6050_update(0.004f, &a));
    assert(a.roll_deg > 9 && a.roll_deg < 11);
    memset(&a, 0, sizeof(a)); reset_sensor();
    sample[0] = 1423; sample[2] = 8068;
    assert(bsp_mpu6050_update(0.004f, &a));
    assert(a.pitch_deg > 9 && a.pitch_deg < 11);
    reset_sensor(); memset(&a, 0, sizeof(a));
    sample[4] = 655; sample[5] = 1310; sample[6] = 1965;
    for (unsigned i = 0; i < 100; i++) assert(bsp_mpu6050_update(0.004f, &a));
    assert(fabsf(a.rate_dps[0] - 10) < 0.01f);
    assert(fabsf(a.rate_dps[1] + 20) < 0.01f);
    assert(fabsf(a.rate_dps[2] + 30) < 0.01f);
    assert(!bsp_mpu6050_update(0.03f, &a));
    bus_failed = 1; assert(!bsp_mpu6050_update(0.004f, &a)); bus_failed = 0;
    sample[5] = sample[6] = 0;
    sample[4] = 5000;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 7);
    sample[4] = 655;
    assert(bsp_mpu6050_init() && bsp_mpu6050_init_step() == 0);
    memset(&a, 0, sizeof(a));
    assert(bsp_mpu6050_update(0.004f, &a) && fabsf(a.rate_dps[0]) < 0.01f);
    sample[4] = 0; sample[2] = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 10);
    sample[2] = 8192; sample_bus_failed = 1;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 10);
    sample_bus_failed = 0; alternate_gyro = 1; sample_count = 0;
    assert(!bsp_mpu6050_init() && bsp_mpu6050_init_step() == 10);
    alternate_gyro = 0;
    startup_diagnostics();
    configuration_and_gyro_diagnostics();
    bounded_startup_and_calibration();
    saved_diagnostics_no_io();
    puts("PASS: MPU bounded verified startup, unchanged calibration/axes/timing, ACC/noise/drift/I2C rejection diagnostics, saved getter without I/O, tick wrap");
    return 0;
}
