#include "flight_control.h"
#include "flight_config.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static fc_state_t s;
static fl_control_t c;
static mpu_attitude_t a;
static uint32_t now;

static void prepare(void)
{
    fc_init(&s);
    memset(&c, 0, sizeof(c)); memset(&a, 0, sizeof(a));
    c.param_value = fl_param_default(FL_RATE_P);
    now = 4;
    for (unsigned i = 0; i < 32; i++) { now += 32; fc_pressure(&s, 101325, 25, now); }
    c.flags = FL_ARM;
    fc_step(&s, &c, &a, 1, now, now, 0.004f);
    assert(s.armed && s.state == FL_MANUAL);
}

static void step(unsigned count)
{
    for (unsigned i = 0; i < count; i++) {
        now += 4;
        if (now - s.baro_tick >= 32) fc_pressure(&s, 101325, 25, now);
        fc_step(&s, &c, &a, 1, now, now, 0.004f);
    }
}
static void all_zero(void) { for (unsigned i = 0; i < 4; i++) assert(s.motors[i] == 0); }

static void codec(void)
{
    uint8_t data[FL_TELEMETRY_LEN];
    fl_control_t in = {0}, out;
    fl_telemetry_t tin = {0}, tout;
    in.seq = 255; in.gear = 2; in.axes[0] = -1000; in.axes[1] = 1000;
    in.axes[2] = -257; in.param_value = fl_param_default(FL_RATE_P);
    fl_encode_control(data, &in);
    assert(data[6] == 0x18 && data[7] == 0xFC);
    assert(fl_decode_control(&out, data, FL_CONTROL_LEN));
    assert(out.seq == 255 && out.axes[0] == -1000 && out.axes[2] == -257);
    assert(!fl_decode_control(&out, data, FL_CONTROL_LEN - 1));
    data[1] = 2; assert(!fl_decode_control(&out, data, FL_CONTROL_LEN));
    fl_encode_control(data, &in); data[4] = 3;
    assert(!fl_decode_control(&out, data, FL_CONTROL_LEN));
    tin.height_cm = -321; tin.roll_ddeg = 205; tin.motors[3] = 650;
    tin.param_value = fl_param_default(FL_RATE_P);
    fl_encode_telemetry(data, &tin);
    assert(fl_decode_telemetry(&tout, data, FL_TELEMETRY_LEN));
    assert(tout.height_cm == -321 && tout.motors[3] == 650 && tout.roll_ddeg == 205);
    data[3] = 255; assert(!fl_decode_telemetry(&tout, data, FL_TELEMETRY_LEN));
    assert(fl_param_float(FL_RATE_D, 40) > 0.000039f);
}

static void mixer(void)
{
    uint16_t m[4];
    fc_mix(0.3f, 0.05f, 0, 0, 0.65f, m);
    assert(m[0] == m[2] && m[0] > m[1] && m[1] == m[3]);
    fc_mix(0.3f, 0, 0.05f, 0, 0.65f, m);
    assert(m[0] == m[1] && m[0] > m[2] && m[2] == m[3]);
    fc_mix(0.3f, 0, 0, 0.05f, 0.65f, m);
    assert(m[0] == m[3] && m[0] > m[1] && m[1] == m[2]);
    fc_mix(0.3f, -0.05f, 0, 0, 0.65f, m);
    assert(m[1] == m[3] && m[1] > m[0] && m[0] == m[2]);
    fc_mix(0.3f, 0, -0.05f, 0, 0.65f, m);
    assert(m[2] == m[3] && m[2] > m[0] && m[0] == m[1]);
    fc_mix(0.3f, 0, 0, -0.05f, 0.65f, m);
    assert(m[1] == m[2] && m[1] > m[0] && m[0] == m[3]);
    for (int r = -20; r <= 20; r++) {
        fc_mix(0.64f, r * 0.05f, 0.8f, -0.2f, 0.65f, m);
        for (unsigned i = 0; i < 4; i++) assert(m[i] <= 650);
    }
}

static void manual_and_feedback(void)
{
    prepare(); all_zero();
    c.axes[3] = 700; step(500);
    assert(s.motors[0] == 525 && s.motors[0] == s.motors[1]);
    assert(s.motors[2] == 525 && s.motors[3] == 525);
    a.roll_deg = 5; step(1);
    assert(s.motors[1] > s.motors[0] && s.motors[3] > s.motors[2]); /* right-down -> FR/RR */
    prepare(); c.axes[3] = 700; step(150);
    a.roll_deg = -5; step(1);
    assert(s.motors[0] > s.motors[1] && s.motors[2] > s.motors[3]); /* left-down -> FL/RL */
    prepare(); c.axes[3] = 700; step(150);
    a.pitch_deg = 5; step(1);
    assert(s.motors[2] > s.motors[0] && s.motors[3] > s.motors[1]); /* nose-up -> RL/RR */
    prepare(); c.axes[3] = 700; step(150);
    a.pitch_deg = -5; step(1);
    assert(s.motors[0] > s.motors[2] && s.motors[1] > s.motors[3]); /* nose-down -> FL/FR */
    prepare(); c.axes[3] = 700; c.axes[1] = 600; step(150);
    assert(s.motors[2] > s.motors[0] && s.motors[3] > s.motors[1]); /* stick forward -> pitch down */
    c.axes[3] = 0; step(1); all_zero();
    c.axes[3] = -500; step(1); all_zero();
    prepare(); c.axes[3] = 2; c.axes[0] = 1000; c.axes[1] = 1000;
    step(250);
    for (unsigned i = 0; i < 4; i++) assert(s.motors[i] <= 3);
}

static void hover_and_takeover(void)
{
    uint16_t before;
    prepare(); c.axes[3] = 700; step(150);
    if (!FC_BARO_ENABLED) {
        c.hover_seq++; step(1);
        assert(s.state == FL_MANUAL && s.fault == FL_NO_FAULT);
        c.axes[3] = 0; step(1); all_zero();
        assert(s.armed);
        return;
    }
    c.hover_seq++; step(1); assert(s.state == FL_HOLD);
    c.axes[3] = 0; step(50);
    assert(s.state == FL_HOLD && s.motors[0] > 250);
    c.hover_seq += 2; step(1); assert(s.state == FL_HOLD);
    c.hover_seq++; step(1); assert(s.state == FL_HOLD_EXIT);
    step(250); assert(s.state == FL_HOLD_EXIT && s.motors[0] > 250);
    before = s.motors[0]; c.axes[3] = 500; step(1);
    assert(s.state == FL_MANUAL);
    assert(abs((int)s.motors[0] - before) < 5);
    c.axes[3] = 0; step(1); all_zero();
    assert(s.handover_bias == 0);
    c.axes[3] = 500;
    step(1000);
    assert(s.motors[0] == 375 && s.motors[0] == s.motors[1]);
    assert(s.motors[2] == 375 && s.motors[3] == 375);
    c.axes[3] = 0; step(1); all_zero();
}

static void takeoff_direction_and_trim_limits(void)
{
    const int16_t throttles[] = {2, 30, 100, 700, 1000};
    const uint16_t caps[] = {750, 850, 950};
    for (unsigned axis = 0; axis < 2; axis++) {
        for (int sign = -1; sign <= 1; sign += 2) {
            prepare();
            c.axes[axis] = (int16_t)(sign * 1000);
            step(20); all_zero(); /* Direction alone must not start motors. */
            c.axes[3] = 100;
            step(1); /* The very first throttle ramp step accepts direction. */
            assert(s.armed && s.state == FL_MANUAL && s.fault == FL_NO_FAULT);
            if (axis == 0 && sign > 0) {
                assert(s.motors[0] > s.motors[1] && s.motors[2] > s.motors[3]);
            } else if (axis == 0) {
                assert(s.motors[1] > s.motors[0] && s.motors[3] > s.motors[2]);
            } else if (sign > 0) {
                assert(s.motors[2] > s.motors[0] && s.motors[3] > s.motors[1]);
            } else {
                assert(s.motors[0] > s.motors[2] && s.motors[1] > s.motors[3]);
            }
            c.axes[3] = 0; step(1); all_zero();
        }
    }
    for (unsigned gear = 0; gear < 3; gear++) {
        for (unsigned j = 0; j < sizeof(throttles) / sizeof(throttles[0]); j++) {
            prepare(); c.gear = (uint8_t)gear; c.axes[3] = throttles[j]; step(250);
            assert(s.motors[0] == s.motors[1] && s.motors[2] == s.motors[3]);
            assert(s.motors[0] == s.motors[2]);
            for (int sign = -1; sign <= 1; sign += 2) {
                c.axes[0] = c.axes[1] = (int16_t)(sign * 1000);
                step(80);
                for (unsigned m = 0; m < 4; m++) assert(s.motors[m] <= caps[gear]);
            }
            c.flags = FL_KILL; step(1); all_zero();
        }
    }
    puts("PASS: symmetric level outputs, all gear caps, immediate takeoff direction and zero-throttle/KILL priority");
}

static void takeoff_imu_feedback(void)
{
    for (unsigned gear = 0; gear < 3; gear++) {
        for (unsigned axis = 0; axis < 2; axis++) {
            for (int sign = -1; sign <= 1; sign += 2) {
                prepare(); c.gear = (uint8_t)gear; c.axes[3] = 500;
                if (axis == 0) a.roll_deg = (float)sign * 10;
                else a.pitch_deg = (float)sign * 10;
                step(1); /* First 4 ms of throttle ramp, before lift-off. */
                assert(s.armed && s.state == FL_MANUAL && s.collective > 0);
                if (axis == 0 && sign > 0) assert(s.motors[1] > s.motors[0]);
                if (axis == 0 && sign < 0) assert(s.motors[0] > s.motors[1]);
                if (axis == 1 && sign > 0) assert(s.motors[2] > s.motors[0]);
                if (axis == 1 && sign < 0) assert(s.motors[0] > s.motors[2]);
                c.flags = FL_KILL; step(1); all_zero();
            }
        }
    }
    puts("PASS: IMU angle feedback starts with the first throttle ramp in all gears");
}

static void no_fixed_front_trim(void)
{
    prepare(); c.axes[3] = 400; step(1000);
    assert(s.motors[0] == 300 && s.motors[1] == 300);
    assert(s.motors[2] == 300 && s.motors[3] == 300);
    a.pitch_deg = 5; step(1);
    assert(s.motors[2] > s.motors[0] && s.motors[3] > s.motors[1]);
    c.axes[3] = 0; step(1); all_zero();
    puts("PASS: no fixed front trim, equal level outputs, nose-up feedback and zero throttle");
}

static void increased_power_and_spool_feedback(void)
{
    const uint16_t caps[] = {750, 850, 950};
    for (unsigned gear = 0; gear < 3; gear++) {
        prepare(); c.gear = (uint8_t)gear; c.axes[3] = 1000;
        step(1000);
        assert(abs((int)s.motors[0] - caps[gear]) <= 1);
        assert(abs((int)s.motors[1] - caps[gear]) <= 1);
        assert(abs((int)s.motors[2] - caps[gear]) <= 1);
        assert(s.motors[0] == s.motors[2]);
        assert(s.motors[2] == s.motors[3]);
        for (unsigned axis = 0; axis < 2; axis++) {
            prepare(); c.gear = (uint8_t)gear; c.axes[3] = 50;
            if (axis) a.pitch_deg = 5; else a.roll_deg = 5;
            a.rate_dps[2] = 2;
            step(1000);
            assert(s.integral[0] == 0 && s.integral[1] == 0 && s.yaw_integral == 0);
            if (axis) assert(s.motors[2] > s.motors[0]);
            else assert(s.motors[1] > s.motors[0]);
        }
    }
    puts("PASS: 75/85/95 percent full-stick power; low-throttle feedback without integral preload");
}

static void smooth_throttle_and_attitude_commands(void)
{
    uint16_t previous[4] = {0};
    prepare(); c.gear = 2; c.axes[3] = 1000;
    for (unsigned n = 0; n < 750; n++) {
        step(1);
        for (unsigned m = 0; m < 4; m++) {
            assert(s.motors[m] >= previous[m]);
            assert(s.motors[m] - previous[m] <= 5);
            assert(s.motors[m] <= 950);
            previous[m] = s.motors[m];
        }
    }
    assert(s.motors[0] == 950 && s.motors[2] == 950);
    c.axes[3] = 500;
    for (unsigned n = 0; n < 750; n++) {
        step(1);
        for (unsigned m = 0; m < 4; m++) {
            assert(s.motors[m] <= previous[m]);
            assert(previous[m] - s.motors[m] <= 8);
            previous[m] = s.motors[m];
        }
    }
    assert(s.motors[2] == 475);
    c.axes[0] = 1000; step(1);
    int first = (int)s.motors[0] - s.motors[1];
    assert(first > 0 && first < 20);
    step(100);
    int settled = (int)s.motors[0] - s.motors[1];
    assert(settled > first + 50);
    c.axes[0] = 0; step(1);
    int released = (int)s.motors[0] - s.motors[1];
    assert(abs(released - settled) < 20);
    c.axes[3] = 0; step(1); all_zero();
    assert(s.angle_target[0] == 0 && s.angle_target[1] == 0);
    assert(s.integral[0] == 0 && s.integral[1] == 0 && s.yaw_integral == 0);
    c.axes[3] = 500; a.roll_deg = 5; step(1);
    assert(s.motors[1] > s.motors[0]); /* Measurement feedback is never command-filtered. */
    puts("PASS: monotonic bounded throttle, gentle stick/release, immediate attitude feedback and zero-throttle reset");
}

static void integral_spool_transition(void)
{
    prepare(); c.gear = 2; c.axes[3] = 500;
    a.roll_deg = 2; a.pitch_deg = -2; a.rate_dps[2] = 2;
    step(500);
    assert(s.integral[0] < 0 && s.integral[1] > 0 && s.yaw_integral < 0);
    c.axes[3] = 50; step(800);
    assert(s.collective > 0 && s.collective < FC_I_ENABLE_DUTY);
    assert(s.integral[0] == 0 && s.integral[1] == 0 && s.yaw_integral == 0);
    c.axes[3] = 500; step(500);
    assert(s.integral[0] < 0 && s.integral[1] > 0 && s.yaw_integral < 0);

    prepare(); c.axes[3] = 500;
    /* Hold makes desired exactly equal to the boundary, without stick-scaling roundoff. */
    s.state = FL_HOLD; s.hold_cap = FC_GEAR1_DUTY;
    s.collective = s.hold_throttle = FC_I_ENABLE_DUTY;
    a.roll_deg = 2; a.pitch_deg = -2; a.rate_dps[2] = 2;
    step(1);
    assert(s.collective == FC_I_ENABLE_DUTY);
    assert(s.integral[0] < 0 && s.integral[1] > 0 && s.yaw_integral < 0);
    s.collective = s.hold_throttle = nextafterf(FC_I_ENABLE_DUTY, 0);
    step(1);
    assert(s.collective < FC_I_ENABLE_DUTY);
    assert(s.integral[0] == 0 && s.integral[1] == 0 && s.yaw_integral == 0);
    puts("PASS: roll/pitch/yaw I clears on positive low throttle and resumes, including the exact duty threshold");
}

static void allocation_antiwindup(void)
{
    /* A 15% collective gives 12% differential authority. The rate PID alone
       would permit this 15% request, so only allocation feedback can block I. */
    for (unsigned axis = 0; axis < 3; axis++) {
        for (int sign = -1; sign <= 1; sign += 2) {
            prepare(); c.axes[3] = 200; s.collective = 0.15f;
            if (axis == 0) a.roll_deg = -25.0f * sign;
            else if (axis == 1) a.pitch_deg = -25.0f * sign;
            else a.rate_dps[2] = -150.0f * sign;
            step(1);
            assert(s.integral[0] == 0 && s.integral[1] == 0 && s.yaw_integral == 0);
            step(500);
            assert(s.integral[0] == 0 && s.integral[1] == 0 && s.yaw_integral == 0);
            for (unsigned m = 0; m < 4; m++) assert(s.motors[m] <= 750);
        }
    }
    prepare(); c.axes[3] = 200; s.collective = 0.15f;
    s.integral[0] = 0.03f; a.pitch_deg = -25;
    step(100);
    assert(s.integral[0] == 0.03f && s.integral[1] == 0); /* No cross-axis leakage. */

    for (int sign = -1; sign <= 1; sign += 2) {
        prepare(); c.axes[3] = 160; s.collective = FC_I_ENABLE_DUTY;
        s.parameters[FL_RATE_P] = 0; s.integral[0] = 0.10f * sign;
        a.roll_deg = 7.5f * sign;
        step(10);
        assert(s.integral[0] * sign < 0.10f && s.integral[0] * sign > 0.09f);
    }
    puts("PASS: same-cycle allocation anti-windup in both directions, independent axes and saturated-I unwinding");
}

static void allocation_feedback(void)
{
    float front_bias, actual[3];
    prepare(); c.axes[3] = 900; s.collective = 0.675f;
    s.parameters[FL_RATE_P] = 165; /* Force mixer span limiting without front trim. */
    a.roll_deg = a.pitch_deg = -30;
    step(1); /* Neither per-axis clamp nor low-throttle budget is limiting. */
    assert(s.sat_positive == 3 && s.sat_negative == 0 && s.integrator_blocked == 3);
    assert(s.integral[0] == 0 && s.integral[1] == 0);
    assert(fabsf(s.requested[0] - 0.198f) < 0.0000001f);
    assert(fabsf(s.requested[1] - 0.198f) < 0.0000001f);
    assert(s.requested[0] < 0.20f && s.requested[1] < 0.20f);
    front_bias = 0.5f * FC_FRONT_TRIM_RATIO * s.collective;
    actual[0] = ((int)s.motors[0] - s.motors[1] + s.motors[2] - s.motors[3]) / 4000.0f;
    actual[1] = ((int)s.motors[0] + s.motors[1] - s.motors[2] - s.motors[3]) / 4000.0f - front_bias;
    actual[2] = ((int)s.motors[0] - s.motors[1] - s.motors[2] + s.motors[3]) / 4000.0f;
    for (unsigned axis = 0; axis < 3; axis++) assert(fabsf(actual[axis] - s.applied[axis]) < 0.00051f);

    prepare(); c.axes[3] = 1000; s.collective = 0.75f; a.roll_deg = -10;
    step(1); /* Collective shift at the cap retains the requested torque. */
    assert(s.sat_positive == 0 && s.sat_negative == 0 && s.integrator_blocked == 0);
    assert(s.integral[0] > 0 && s.integral[1] == 0 && s.applied[1] == 0);
    a.roll_deg = 0; s.integral[0] = 0; step(1);
    assert(!s.sat_positive && !s.sat_negative && !s.integrator_blocked);
    assert(fabsf(s.applied[0]) < 0.000001f && fabsf(s.applied[1]) < 0.000001f);
    c.flags = FL_KILL; step(1);
    assert(!s.sat_positive && !s.sat_negative && !s.integrator_blocked);
    for (unsigned axis = 0; axis < 3; axis++) {
        assert(s.rate_error[axis] == 0 && s.requested[axis] == 0 && s.applied[axis] == 0);
    }
    puts("PASS: mixer span saturation, achieved torque vs motor outputs, front trim separation and collective shifting without false saturation");
}

static void rejected_integral_updates_pwm_same_cycle(void)
{
    /* Asymmetric three-axis demand with a large trial I makes a stale
       trial allocation visible in the final PWM, not just in diagnostics. */
    prepare(); c.axes[3] = 900; s.collective = 0.675f;
    s.parameters[FL_RATE_P] = 165; /* Test fixture only; flight defaults stay unchanged. */
    s.parameters[FL_RATE_I] = 1000;
    a.roll_deg = -30; a.pitch_deg = -29.5f; a.rate_dps[2] = -90;
    now += 12;
    fc_step(&s, &c, &a, 1, now, now, 0.012f);
    assert(s.integrator_blocked == 7);
    assert(s.integral[0] == 0 && s.integral[1] == 0 && s.yaw_integral == 0);
    assert(fabsf(s.requested[0] - 0.198f) < 0.0000001f);
    assert(fabsf(s.requested[1] - 0.1947f) < 0.0000001f);
    assert(fabsf(s.requested[2] - 0.09f) < 0.0000001f);
    /* Final corrections .4827,-.0933,-.0867,-.3027, scaled to span .75. */
    assert(s.motors[0] == 750 && s.motors[1] == 200 && s.motors[2] == 206 && s.motors[3] == 0);
    puts("PASS: rejected trial I is removed from requested correction and asymmetric PWM in the same cycle");
}

static void faults_and_rearming(void)
{
    prepare(); c.axes[3] = 700; step(150);
    fc_step(&s, &c, &a, 1, now - 200, now, 0.004f);
    assert(s.armed && s.fault == FL_NO_FAULT);
    fc_step(&s, &c, &a, 1, now - 201, now, 0.004f);
    assert(s.state == FL_FAULT && s.fault == FL_RADIO_FAULT); all_zero();
    step(1); assert(s.state == FL_FAULT); all_zero();
    c.flags = 0; step(1); assert(s.state == FL_STOPPED);
    c.flags = FL_ARM; step(1); assert(!s.armed); all_zero();
    c.axes[3] = 0; step(1); assert(s.armed);
    c.axes[3] = 700; step(150);
    fc_step(&s, &c, &a, 0, now, now, 0.004f);
    assert(s.fault == FL_IMU_FAULT); all_zero();
    prepare(); c.axes[3] = 500; step(100);
    fc_step(&s, &c, &a, 1, now, now, 0.03f);
    assert(s.fault == FL_TIMING_FAULT); all_zero();
    prepare(); c.flags |= FL_KILL; step(1); all_zero();
}

static void geometry_is_informational(void)
{
    fc_init(&s);
    memset(&c, 0, sizeof(c)); memset(&a, 0, sizeof(a));
    s.geometry_ok = 0;
    c.param_value = fl_param_default(FL_RATE_P);
    now = 100;
    c.flags = FL_KILL;
    fc_step(&s, &c, &a, 1, now, now, 0.004f);
    assert(s.state == FL_STOPPED && s.fault == FL_NO_FAULT); all_zero();
    c.flags = FL_ARM;
    fc_step(&s, &c, &a, 1, now, now, 0.004f);
    assert(s.armed && s.state == FL_MANUAL && s.fault == FL_NO_FAULT);
    c.axes[3] = 700; step(150);
    assert(s.armed && s.fault == FL_NO_FAULT && s.motors[0] > 0);
    c.flags = FL_KILL; step(1);
    assert(!s.armed && s.fault == FL_NO_FAULT); all_zero();
}

static void altitude_and_parameters(void)
{
    prepare();
    now += 32; fc_pressure(&s, 101300, 25, now);
    assert(s.height > 0 && s.vertical_speed > 0);
    c.flags = FL_KILL; step(1);
    c.param_rev = 1; c.param_id = FL_RATE_P; c.param_value = 180;
    step(1); assert(s.param_rev == 1 && s.parameters[FL_RATE_P] == 180);
    c.param_rev = 2; c.param_value = 65535;
    step(1); assert(s.param_rev == 1 && s.parameters[FL_RATE_P] == 180);
    if (!FC_BARO_ENABLED) return;
    prepare(); c.axes[3] = 700; step(150); c.hover_seq++; step(1);
    now += 301; fc_step(&s, &c, &a, 1, now, now, 0.004f);
    assert(s.state == FL_HOLD_EXIT && s.fault == FL_BARO_FAULT);
    assert(s.motors[0] > 0); /* barometer failure does not abruptly stop motors */
    /* With a sustained 20 cm height error, the tuned PI raises collective. */
    prepare(); c.gear = 2; c.axes[3] = 650; step(250);
    c.hover_seq++; step(1); assert(s.state == FL_HOLD);
    {
        float start = s.collective, target = s.hold_height;
        for (unsigned i = 0; i < 250; i++) {
            now += 4; s.baro_tick = now; s.height = target - 0.2f; s.vertical_speed = 0;
            fc_step(&s, &c, &a, 1, now, now, 0.004f);
            if (i == 0) {
                /* React within the first control cycle, still bounded by the rise slew. */
                assert(s.collective > start + 0.003f && s.collective <= start + 0.00321f);
            }
        }
        assert(s.state == FL_HOLD && s.hold_height == target);
        assert(s.collective > start + 0.04f && s.collective < start + 0.055f);
        assert(s.collective <= s.hold_cap);
    }
    prepare(); c.gear = 2; c.axes[3] = 800; step(200);
    c.hover_seq++; step(1); assert(s.state == FL_HOLD);
    c.gear = 0; step(1); assert(s.motors[0] >= 515);
    a.roll_deg = 10; step(1);
    c.hover_seq++; step(1); assert(s.state == FL_HOLD_EXIT);
    {
        uint16_t before[4];
        memcpy(before, s.motors, sizeof(before));
        c.axes[3] = 500; step(1);
        assert(s.state == FL_MANUAL);
        for (unsigned i = 0; i < 4; i++) assert(abs((int)s.motors[i] - before[i]) < 8);
    }
    prepare();
    now += 601; fc_pressure(&s, 101000, 25, now);
    assert(s.height > 20 && s.vertical_speed == 0 && s.baro_tick == now);
}

static void tilt_does_not_disarm(void)
{
    for (unsigned axis = 0; axis < 2; axis++) {
        for (int sign = -1; sign <= 1; sign += 2) {
            for (unsigned angle = 20; angle <= 65; angle += 45) {
                fc_init(&s);
                memset(&c, 0, sizeof(c)); memset(&a, 0, sizeof(a));
                c.flags = FL_ARM; c.param_value = fl_param_default(FL_RATE_P);
                if (axis) a.pitch_deg = sign * (float)angle;
                else a.roll_deg = sign * (float)angle;
                now = 100;
                fc_step(&s, &c, &a, 1, 100, 100, 0.004f);
                assert(s.armed && s.state == FL_MANUAL && s.fault == FL_NO_FAULT); all_zero();
                c.axes[3] = 700; step(150);
                assert(s.armed && s.state == FL_MANUAL && s.fault == FL_NO_FAULT);
                assert(s.motors[0] + s.motors[1] + s.motors[2] + s.motors[3] > 0);
                c.flags = FL_KILL; step(1);
                assert(!s.armed); all_zero();
            }
        }
    }
    prepare(); c.axes[3] = 700; step(150);
    a.roll_deg = 65; a.pitch_deg = -65; step(1);
    assert(s.armed && s.fault == FL_NO_FAULT);
    a.roll_deg = NAN; step(1);
    assert(!s.armed && s.fault == FL_IMU_FAULT); all_zero();
}

static void armed_pid_change_is_rejected(void)
{
    prepare(); c.axes[3] = 700; step(150);
    c.param_rev = 1; c.param_id = FL_RATE_P; c.param_value = 180;
    step(1);
    assert(s.armed && s.param_rev == 0 && s.parameters[FL_RATE_P] == fl_param_default(FL_RATE_P));
    c.hover_seq++; step(1);
    assert(s.state == (FC_BARO_ENABLED ? FL_HOLD : FL_MANUAL) && s.param_rev == 0);
    c.flags = FL_KILL; step(2);
    assert(!s.armed && s.state == FL_STOPPED && s.param_rev == 1 && s.parameters[FL_RATE_P] == 180);
    all_zero();
    c.flags = FL_ARM; c.axes[3] = 0;
    c.param_rev = 2; c.param_value = 200;
    step(1);
    assert(s.armed && s.param_rev == 1 && s.parameters[FL_RATE_P] == 180);
}

static void manual_without_baro(void)
{
    for (unsigned samples = 0; samples < 32; samples++) {
        fc_init(&s);
        memset(&c, 0, sizeof(c)); memset(&a, 0, sizeof(a));
        c.flags = FL_ARM; c.param_value = fl_param_default(FL_RATE_P);
        s.height_samples = (uint8_t)samples;
        now = 100;
        c.axes[3] = 100;
        fc_step(&s, &c, &a, 1, now, now, 0.004f);
        assert(!s.armed); all_zero();
        c.axes[3] = 0;
        fc_step(&s, &c, &a, 1, now, now, 0.004f);
        assert(s.armed && s.state == FL_MANUAL); all_zero();
        c.axes[3] = 700; step(150);
        assert(s.state == FL_MANUAL && s.motors[0] > 0);
        c.hover_seq++; step(1);
        assert(s.state == FL_MANUAL && s.fault == FL_NO_FAULT);
    }
    puts("PASS: disabled barometer never blocks manual arming or enables height hold; zero-throttle arming retained");
}

int main(void)
{
    no_fixed_front_trim();
    allocation_antiwindup();
    allocation_feedback();
    rejected_integral_updates_pwm_same_cycle();
    if (!FC_BARO_ENABLED) manual_without_baro();
    increased_power_and_spool_feedback(); smooth_throttle_and_attitude_commands(); integral_spool_transition();
    codec(); mixer(); manual_and_feedback(); hover_and_takeover();
    takeoff_direction_and_trim_limits(); takeoff_imu_feedback();
    geometry_is_informational(); tilt_does_not_disarm();
    faults_and_rearming(); altitude_and_parameters(); armed_pid_change_is_rejected();
    puts("PASS: protocol, motor mapping, feedback, throttle, hold/takeover, retained faults, altitude, stopped-only PID; mapping/tilt gates removed");
    return 0;
}
