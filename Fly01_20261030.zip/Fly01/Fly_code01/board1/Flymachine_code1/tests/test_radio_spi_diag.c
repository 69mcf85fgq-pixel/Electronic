#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>

#define RADIO_DIAG_HOST 1
#define GPIO_PIN_5 (1U << 5)
#define GPIO_PIN_12 (1U << 12)
#define GPIO_PIN_13 (1U << 13)
#define GPIO_PIN_14 (1U << 14)
#define GPIO_PIN_15 (1U << 15)
#define GPIO_PIN_RESET 0
#define GPIO_PIN_SET 1
#define GPIO_MODE_INPUT 0
#define GPIO_MODE_OUTPUT_PP 1
#define GPIO_MODE_AF_PP 2
#define GPIO_NOPULL 0
#define GPIO_SPEED_FREQ_LOW 0
#define GPIO_AF5_SPI2 5
#define SPI_BAUDRATEPRESCALER_64 40
#define SPI_BAUDRATEPRESCALER_256 56
#define HAL_OK 0
#define NRF_REG_CONFIG 0
#define NRF_REG_RF_CH 5
#define NRF_REG_SETUP_AW 3
#define NRF_CMD_W_REGISTER 0x20
#define NRF_CMD_R_REGISTER 0

typedef struct { uint32_t MODER, AFR[2], ODR; } GPIO_TypeDef;
typedef struct { uint32_t CR1; } SPI_TypeDef;
typedef struct { SPI_TypeDef *Instance; struct { uint32_t BaudRatePrescaler; } Init; uint32_t ErrorCode; } SPI_HandleTypeDef;
typedef struct { uint32_t Pin, Mode, Pull, Speed, Alternate; } GPIO_InitTypeDef;
static GPIO_TypeDef port;
static SPI_TypeDef spi;
static SPI_HandleTypeDef hspi2 = {.Instance = &spi};
static int huart1;
#define GPIOB (&port)
#define CE_GPIO_Port GPIOB
#define CE_Pin GPIO_PIN_5
#define CSN_GPIO_Port GPIOB
#define CSN_Pin GPIO_PIN_12
#define __HAL_SPI_ENABLE(h) ((h)->Instance->CR1 |= 64U)
#define __HAL_SPI_DISABLE(h) ((h)->Instance->CR1 &= ~64U)
#define __HAL_RCC_SPI2_FORCE_RESET() (spi.CR1 = 0)
#define __HAL_RCC_SPI2_RELEASE_RESET() ((void)0)

static uint32_t tick;
static unsigned selected, bits, command, outgoing, incoming, response, sample;
static unsigned mode, waits, gpio_frames, hw_frames, motor_off;
static uint8_t regs[32];
static char output[18000];
static size_t output_size;
static jmp_buf done;

static void HAL_Init(void) { }
static void SystemClock_Config(void) { }
static void MX_GPIO_Init(void) { port.ODR = CSN_Pin; }
static void MX_USART1_UART_Init(void) { }
static void MX_TIM3_Init(void) { }
static void flight_emergency_stop(void) { motor_off++; }
static void Error_Handler(void) { assert(0); }
static uint32_t HAL_GetTick(void) { return tick; }
static void HAL_Delay(uint32_t ms)
{
    assert(!(port.ODR & CE_Pin)); tick += ms;
    if (ms == 5000 && ++waits == 2) longjmp(done, 1);
}
static void HAL_GPIO_Init(GPIO_TypeDef *p, const GPIO_InitTypeDef *g)
{
    assert(!(g->Pin & GPIO_PIN_14) || g->Mode != GPIO_MODE_OUTPUT_PP);
    for (unsigned pin = 0; pin < 16; pin++) if (g->Pin & (1U << pin)) {
        p->MODER = (p->MODER & ~(3U << (pin * 2))) | (g->Mode << (pin * 2));
        if (g->Mode == GPIO_MODE_AF_PP)
            p->AFR[1] = (p->AFR[1] & ~(15U << ((pin - 8) * 4))) | (5U << ((pin - 8) * 4));
    }
}
static int HAL_SPI_Init(SPI_HandleTypeDef *h) { h->Instance->CR1 = 0x304U | h->Init.BaudRatePrescaler; return HAL_OK; }
static int HAL_SPI_DeInit(SPI_HandleTypeDef *h) { h->Instance->CR1 = 0; return HAL_OK; }
static void MX_SPI2_Init(void)
{
    GPIO_InitTypeDef g = {GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15, GPIO_MODE_AF_PP, 0, 0, 5};
    HAL_GPIO_Init(GPIOB, &g); hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
    HAL_SPI_Init(&hspi2);
}
static void HAL_GPIO_WritePin(GPIO_TypeDef *p, unsigned pin, unsigned value)
{
    if (value) p->ODR |= pin; else p->ODR &= ~pin;
    assert(!(p->ODR & CE_Pin));
    if (pin == CSN_Pin) {
        if (!value) { assert(!selected); selected = 1; bits = outgoing = incoming = 0; response = 0x0E; }
        else { selected = 0; }
    }
    if (pin == GPIO_PIN_13 && value && selected) {
        assert(((p->MODER >> 28) & 3U) == GPIO_MODE_INPUT);
        sample = mode == 2 ? 0 : mode == 3 ? 1 : !!(response & (0x80U >> (bits & 7U)));
        outgoing = (outgoing << 1) | !!(p->ODR & GPIO_PIN_15);
        if ((++bits & 7U) == 0) {
            if (bits == 8) { command = outgoing; response = regs[command & 31U]; }
            else { if ((command & 0xE0U) == 0x20U) regs[command & 31U] = (uint8_t)outgoing; gpio_frames++; }
            outgoing = 0;
        }
    }
}
static unsigned HAL_GPIO_ReadPin(GPIO_TypeDef *p, unsigned pin)
{ return pin == GPIO_PIN_14 ? sample : !!(p->ODR & pin); }
static int HAL_SPI_TransmitReceive(SPI_HandleTypeDef *h, uint8_t *tx, uint8_t *rx, uint16_t size, uint32_t timeout)
{
    assert(selected && size == 2 && timeout == 3 && (h->Instance->CR1 & 64U)); hw_frames++;
    h->ErrorCode = 0;
    if (mode == 4) { h->ErrorCode = 0x20; return 2; }
    rx[0] = mode == 3 ? 0xFF : 0x0E;
    rx[1] = 0;
    if (mode == 1 || mode == 2) { rx[0] = rx[1] = 0; return HAL_OK; }
    if ((tx[0] & 0xE0U) == 0x20U) regs[tx[0] & 31U] = tx[1];
    else rx[1] = regs[tx[0] & 31U];
    return HAL_OK;
}
static int HAL_UART_Transmit(int *u, uint8_t *data, uint16_t len, uint32_t timeout)
{
    (void)u; (void)timeout;
    assert(!selected && output_size + len < sizeof(output));
    memcpy(output + output_size, data, len); output_size += len; output[output_size] = 0;
    return HAL_OK;
}

#define main radio_diag_entry
#include "../diagnostics/radio_spi_main.c"
#undef main

int main(void)
{
    for (mode = 0; mode < 5; mode++) {
        memset(&port, 0, sizeof(port)); memset(regs, 0, sizeof(regs));
        tick = selected = waits = gpio_frames = hw_frames = motor_off = 0;
        output_size = 0;
        if (!setjmp(done)) radio_diag_entry();
        assert(!selected && !(port.ODR & CE_Pin) && motor_off);
        assert(hw_frames == 48 && gpio_frames == 12);
        assert(strstr(output, "motors=OFF CE=0") && strstr(output, "DIAG DONE"));
        assert(strstr(output, mode == 0 ? "phase=HW_ORIG pass=6/6" : "phase=HW_ORIG pass=0/6"));
        assert(strstr(output, mode < 2 || mode == 4 ? "phase=GPIO pass=6/6" : "phase=GPIO pass=0/6"));
        assert(strstr(output, "phase=HW_RESET") && strstr(output, "phase=HW_SLOW") && strstr(output, "phase=HW_RETURN"));
    }
    puts("PASS: actual diagnostic main; motors disabled, CE low, MISO never driven; valid, HW-only failure, all-zero, all-FF and HAL failure; GPIO bit timing and five phases");
    return 0;
}
