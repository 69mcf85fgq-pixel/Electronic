#include "bsp_nrf.h"
#include "spi.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

SPI_HandleTypeDef hspi2;
GPIO_TypeDef test_gpio;
SPI_TypeDef test_spi;
uint32_t test_primask;
static unsigned selected, calls;
uint32_t HAL_GetTick(void) { return 0; }
void HAL_Delay(uint32_t ms) { (void)ms; }
void HAL_GPIO_WritePin(GPIO_TypeDef *port, unsigned pin, unsigned value)
{
    (void)port;
    if (pin == CSN_Pin) selected = value == GPIO_PIN_RESET;
}
int HAL_SPI_TransmitReceive(SPI_HandleTypeDef *spi, uint8_t *tx, uint8_t *rx,
                            uint16_t size, uint32_t timeout)
{
    (void)tx; (void)timeout;
    assert(selected);
    calls++;
    memset(rx, 0x55, size); /* Partial DMA/polling data must not survive a failed transfer. */
    spi->ErrorCode = 0x20;
    return HAL_TIMEOUT;
}
int HAL_SPI_Transmit(SPI_HandleTypeDef *spi, uint8_t *tx, uint16_t size, uint32_t timeout)
{ (void)spi; (void)tx; (void)size; (void)timeout; return HAL_TIMEOUT; }

int main(void)
{
    assert(bsp_nrf_read_reg(NRF_REG_CONFIG) == 0xFF);
    assert(calls == 1 && !selected);
    assert(bsp_nrf_write_reg(NRF_REG_CONFIG, 0x0F) == 0xFF);
    assert(calls == 2 && !selected);
    puts("PASS: failed SPI register transfers never return partial data; CSN released");
    return 0;
}
