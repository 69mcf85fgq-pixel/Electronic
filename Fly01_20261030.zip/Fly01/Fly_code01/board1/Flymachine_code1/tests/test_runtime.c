#include "flight_control.h"
#include "flight_config.h"
#include "runtime.h"
#include <assert.h>
#include <stdlib.h>
#include <math.h>
#include <setjmp.h>
#include <stdio.h>
#include <string.h>

TIM_TypeDef runtime_timer;
IWDG_TypeDef runtime_watchdog;
TIM_HandleTypeDef htim3 = {{4799}};
UART_HandleTypeDef huart1;

typedef struct {
    uint32_t tick, compare[4];
    float dt, roll_deg, pitch_deg;
    uint8_t imu_valid;
    fl_telemetry_t telemetry;
} output_t;
static output_t outputs[2048];
static unsigned output_count, output_limit, command_count, delay_applied;
static uint32_t tick, delay_start, delay_ms, kill_after, center_after;
static uint8_t delay_imu, radio_expired, idle_command, no_command, last_imu_valid;
static float last_dt, last_roll, last_pitch;
static mpu_attitude_t measured_attitude = {.roll_deg = -2.0f, .pitch_deg = 2.0f};
static mpu_attitude_t prior_imu;
static unsigned imu_calls;
static jmp_buf task_exit, boot_exit, log_exit, radio_exit;
static uint8_t boot_testing, log_testing, radio_testing;
static uint8_t boot_stage, boot_imu_bad, boot_radio_bad, boot_baro_bad, boot_ce;
static uint8_t boot_config_probe, boot_probe_stuck;
static unsigned boot_probe_calls;
static unsigned boot_radio_calls, boot_transient_failures, boot_delay_ms;
static char boot_log[2048], runtime_log[4096];
static mpu_init_diag_t boot_imu_diag;
static unsigned boot_length, log_length, queue_creations;
static int command_token, telemetry_token, stop_token;
static uint8_t stop_pending;
static unsigned stop_writes;
static uint8_t radio_round, radio_packet, radio_io_bad;
static unsigned fifo_reads, status_writes, command_writes, ack_writes;
static uint8_t radio_packets[8][FL_CONTROL_LEN], radio_lengths[8], accepted_seq[8];
static unsigned snapshot_calls, radio_round_limit = 3;
static uint8_t gap_testing;
static uint8_t baro_testing;
static uint32_t baro_failed_after;
void HAL_Delay(uint32_t ms);

static void runtime_fc_step(fc_state_t *s, const fl_control_t *c, const mpu_attitude_t *a,
                            uint8_t imu_valid, uint32_t last_rx, uint32_t now, float dt)
{
    last_dt = dt; last_imu_valid = imu_valid;
    last_roll = a->roll_deg; last_pitch = a->pitch_deg;
    fc_step(s, c, a, imu_valid, last_rx, now, dt);
}
#define fc_step runtime_fc_step
#include "../BSP/flight_app.c"
#undef fc_step
static stop_event_t saved_stop;

uint32_t HAL_GetTick(void) { return tick; }
void HAL_Delay(uint32_t ms)
{
    assert(boot_testing && ms == 50 && !boot_ce);
    assert(!TIM3->CCR1 && !TIM3->CCR2 && !TIM3->CCR3 && !TIM3->CCR4);
    boot_delay_ms += ms; tick += ms;
}
TickType_t xTaskGetTickCount(void) { return tick; }
void vTaskDelayUntil(TickType_t *wake, TickType_t interval)
{
    if (radio_testing) {
        assert(interval == 10);
        if (++radio_round == radio_round_limit) longjmp(radio_exit, 1);
        tick += gap_testing ? 10 : radio_round == 1 ? 10 : 30; *wake = tick;
        return;
    }
    if (output_count == output_limit) longjmp(task_exit, 1);
    *wake += interval;
    if ((int32_t)(tick - *wake) < 0) tick = *wake;
}
void vTaskDelay(TickType_t interval)
{
    assert(log_testing && interval == 500);
    tick += interval; longjmp(log_exit, 1);
}
int xQueueReceive(QueueHandle_t queue, void *out, TickType_t wait)
{
    received_t *rx = out;
    assert(wait == 0);
    if (queue == &stop_token) {
        if (!stop_pending) return 0;
        *(stop_event_t *)out = saved_stop; stop_pending = 0;
        return pdPASS;
    }
    assert(queue == commands);
    if (no_command) return 0;
    memset(rx, 0, sizeof(*rx));
    rx->control.seq = (uint8_t)command_count++;
    rx->control.flags = idle_command ? FL_KILL : FL_ARM;
    rx->control.axes[3] = command_count > 1 ? 700 : 0;
    if (center_after && tick >= center_after) rx->control.axes[3] = 0;
    if (kill_after && tick >= kill_after) {
        rx->control.flags = FL_KILL; rx->control.axes[3] = 0;
    }
    if (baro_testing) {
        rx->control.flags = tick < 1200 ? FL_KILL : FL_ARM;
        rx->control.axes[3] = tick <= 1212 ? 0 : 700;
        rx->control.hover_seq = tick >= 2000;
    }
    rx->control.param_value = fl_param_default(FL_RATE_P);
    rx->rx_tick = radio_expired ? 0 : tick;
    return pdPASS;
}
int xQueueOverwrite(QueueHandle_t queue, const void *in)
{
    if (radio_testing && queue == commands) {
        const received_t *rx = in;
        assert(command_writes < 8 && rx->rx_tick == tick);
        accepted_seq[command_writes++] = rx->control.seq;
    } else if (queue == &stop_token) {
        saved_stop = *(const stop_event_t *)in; stop_pending = 1; stop_writes++;
    } else {
        output_t *o;
        assert(queue == telemetry_queue && output_count < output_limit);
        o = &outputs[output_count++];
        o->tick = tick; o->dt = last_dt; o->imu_valid = last_imu_valid;
        o->roll_deg = last_roll; o->pitch_deg = last_pitch;
        o->telemetry = *(const fl_telemetry_t *)in;
        o->compare[0] = TIM3->CCR1; o->compare[1] = TIM3->CCR2;
        o->compare[2] = TIM3->CCR3; o->compare[3] = TIM3->CCR4;
    }
    return pdPASS;
}
int xQueuePeek(QueueHandle_t queue, void *out, TickType_t wait)
{
    assert(wait == 0 && queue == telemetry_queue);
    if (radio_testing) {
        fl_telemetry_t *t = out;
        memset(t, 0, sizeof(*t)); t->param_value = fl_param_default(FL_RATE_P);
        return pdPASS;
    }
    if (log_testing && output_count) {
        *(fl_telemetry_t *)out = outputs[output_count - 1].telemetry;
        return pdPASS;
    }
    return 0;
}
QueueHandle_t xQueueCreate(unsigned count, unsigned size)
{
    assert(count == 1);
    switch (queue_creations++) {
    case 0: assert(size == sizeof(received_t)); return &command_token;
    case 1: assert(size == sizeof(fl_telemetry_t)); return &telemetry_token;
    default: assert(size == sizeof(stop_event_t)); return &stop_token;
    }
}
int xTaskCreate(void (*entry)(void *), const char *name, unsigned stack,
                void *argument, unsigned priority, TaskHandle_t *handle)
{
    (void)name; (void)argument; (void)handle;
    if (entry == control_task) assert(priority == 4 && stack >= 640);
    else if (entry == radio_task) assert(priority == 3 && stack >= 384);
    else { assert(entry == log_task && priority == 1 && stack >= 384); }
    return pdPASS;
}
void vTaskStartScheduler(void) { assert(boot_testing); longjmp(boot_exit, 1); }
void runtime_set_compare(TIM_HandleTypeDef *timer, uint32_t channel, uint32_t value)
{
    assert(timer == &htim3 && value <= 4800);
    switch (channel) {
    case TIM_CHANNEL_1: TIM3->CCR1 = value; break;
    case TIM_CHANNEL_2: TIM3->CCR2 = value; break;
    case TIM_CHANNEL_3: TIM3->CCR3 = value; break;
    case TIM_CHANNEL_4: TIM3->CCR4 = value; break;
    default: assert(0);
    }
}
HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *timer, uint32_t channel)
{ (void)timer; (void)channel; return HAL_OK; }
void HAL_GPIO_WritePin(unsigned port, unsigned pin, unsigned value)
{ (void)port; (void)pin; assert(boot_testing); boot_ce = (uint8_t)value; }
HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *uart, uint8_t *data,
                                    uint16_t length, uint32_t timeout)
{
    (void)uart; (void)timeout;
    assert(boot_testing || log_testing); /* Never print from control/radio tasks. */
    if (boot_testing) {
        assert(boot_stage == 3U + FC_BARO_ENABLED && boot_length + length < sizeof(boot_log));
        assert(!TIM3->CCR1 && !TIM3->CCR2 && !TIM3->CCR3 && !TIM3->CCR4);
        memcpy(boot_log + boot_length, data, length); boot_length += length;
        boot_log[boot_length] = 0;
    } else {
        assert(log_length + length < sizeof(runtime_log));
        memcpy(runtime_log + log_length, data, length); log_length += length;
        runtime_log[log_length] = 0;
    }
    return HAL_OK;
}
void bsp_led_toggle(void) {}
void bsp_i2c_startup(i2c_startup_diag_t *d)
{
    assert(boot_testing && boot_stage++ == 0);
    assert(!TIM3->CCR1 && !TIM3->CCR2 && !TIM3->CCR3 && !TIM3->CCR4);
    memset(d, 0, sizeof(*d));
}
uint8_t bsp_mpu6050_init(void)
{
    assert(boot_stage++ == 1);
    memset(&boot_imu_diag, 0, sizeof(boot_imu_diag));
    boot_imu_diag.reg = 0x75;
    boot_imu_diag.range_value[0] = boot_imu_diag.range_value[1] = 8;
    if (boot_imu_bad != 1) {
        boot_imu_diag.stable = !boot_imu_bad;
        boot_imu_diag.settle_samples = boot_imu_bad ? 750 : 200;
        boot_imu_diag.settle_ms = boot_imu_bad ? 3000 : 800;
        boot_imu_diag.settle_windows = boot_imu_bad ? 7 : 2;
        boot_imu_diag.settle_reject = boot_imu_bad ? MPU_SETTLE_DRIFT : 0;
        boot_imu_diag.settle_bad_drift = boot_imu_bad ? 6 : 0;
        boot_imu_diag.settle_accel[2] = 8192;
        boot_imu_diag.settle_accel_min_sq = boot_imu_diag.settle_accel_max_sq = 1;
        boot_imu_diag.settle_mean[0] = 0.25f;
        boot_imu_diag.settle_mean[1] = -0.5f;
        boot_imu_diag.settle_mean[2] = 5;
        boot_imu_diag.settle_variance[0] = 1;
        boot_imu_diag.settle_variance[1] = 0.25f;
        boot_imu_diag.settle_variance[2] = 0.0625f;
        boot_imu_diag.settle_delta[0] = boot_imu_bad ? 0.75f : 0.25f;
        boot_imu_diag.settle_delta[1] = 0.125f;
    }
    return !boot_imu_bad;
}
uint8_t bsp_mpu6050_init_step(void) { return boot_imu_bad == 2 ? 10 : boot_imu_bad ? 4 : 0; }
uint8_t bsp_mpu6050_whoami(void) { return 0x68; }
const mpu_init_diag_t *bsp_mpu6050_init_diag(void)
{
    assert(boot_testing && boot_stage == 3U + FC_BARO_ENABLED);
    return &boot_imu_diag;
}
uint8_t bsp_spa06_init(void) { assert(FC_BARO_ENABLED && boot_stage++ == 2); return !boot_baro_bad; }
uint8_t bsp_spa06_id(void) { assert(FC_BARO_ENABLED); return 1; }
uint8_t bsp_mpu6050_update(float dt, mpu_attitude_t *a)
{
    /* The estimator must receive its previous RAW state, never the leveled copy. */
    if (imu_calls++) assert(memcmp(a, &prior_imu, sizeof(*a)) == 0);
    *a = measured_attitude;
    prior_imu = *a;
    if (delay_imu && !delay_applied && tick == delay_start) { tick += delay_ms; delay_applied = 1; }
    return isfinite(dt) && dt >= 0.001f && dt <= 0.012f;
}
uint8_t bsp_spa06_read(spa06_data_t *b)
{
    assert(FC_BARO_ENABLED);
    if (!delay_imu && !delay_applied && tick == delay_start) { tick += delay_ms; delay_applied = 1; }
    if (baro_testing && tick < baro_failed_after) {
        b->pressure_pa = 101325; b->temperature_c = 25;
        b->pressure_dhpa = 10133; b->temperature_dC = 250;
        return 1;
    }
    return 0;
}
uint8_t bsp_nrf_init(void)
{
    if (!boot_radio_calls) assert(boot_stage++ == 2U + FC_BARO_ENABLED);
    boot_radio_calls++;
    boot_ce = 0;
    return boot_radio_bad || boot_radio_calls <= boot_transient_failures;
}
void bsp_nrf_get_error(nrf_error_t *e)
{
    assert(boot_testing); memset(e, 0, sizeof(*e));
    e->reg = NRF_REG_RF_CH; e->expected = 40;
    if (boot_config_probe) {
        e->reg = NRF_REG_CONFIG; e->expected = 0x0C; e->actual = 0x08;
    }
    e->boot_count = 2;
    for (unsigned i = 0; i < 2; i++) {
        nrf_spi_diag_t *d = &e->boot_io[i];
        d->ms = 100; d->command = i ? 0x00 : 0x20;
        d->tx_data = i ? 0xFF : 0x0C; d->bytes = 2;
        d->status = !i && boot_config_probe ? 0x1C : 0x0E;
        d->rx_data = i ? (boot_config_probe ? 0x08 : 0x0C) : 0;
        d->valid = 1; d->csn_idle = 1;
    }
}
uint8_t bsp_nrf_read_reg(uint8_t reg)
{
    if (boot_testing) {
        assert(boot_radio_bad && boot_config_probe && !boot_ce && reg == NRF_REG_CONFIG);
        assert(++boot_probe_calls % 2 == 0);
        return boot_probe_stuck ? 0x08 : 0x0C;
    }
    assert(radio_testing && reg == NRF_REG_FIFO_STATUS); fifo_reads++;
    if (gap_testing) return radio_packet == 0 || (radio_packet == 1 && tick >= 360) ?
                            0 : NRF_FIFO_RX_EMPTY;
    return radio_io_bad ? 0xFF : radio_packet < 8 ? 0 : NRF_FIFO_RX_EMPTY;
}
void bsp_nrf_snapshot(nrf_snapshot_t *out)
{
    assert(radio_testing && radio_ready);
    snapshot_calls++;
    memset(out, 0, sizeof(*out));
    out->tick = tick; out->valid = 0xFFF; out->ce = out->csn = 1;
    out->regs[NRF_SNAP_CONFIG] = 0x0F;
    out->regs[NRF_SNAP_CH] = 40;
}
uint8_t bsp_nrf_write_reg(uint8_t reg, uint8_t value)
{
    if (boot_testing) {
        assert(boot_radio_bad && boot_config_probe && !boot_ce);
        assert(reg == NRF_REG_CONFIG && value == 0x0C && ++boot_probe_calls % 2 == 1);
        return 0x0E;
    }
    assert(radio_testing && reg == NRF_REG_STATUS && value == (NRF_FLAG_RX_DR | NRF_FLAG_TX_DS));
    status_writes++; return 0;
}
uint8_t bsp_nrf_read_packet(uint8_t *data, uint8_t capacity)
{
    uint8_t size = radio_lengths[radio_packet];
    assert(radio_testing && capacity >= size);
    memcpy(data, radio_packets[radio_packet++], size);
    return size;
}
uint8_t bsp_nrf_write_ack_payload(const uint8_t *data, uint8_t length)
{
    fl_telemetry_t t;
    assert(radio_testing && fl_decode_telemetry(&t, data, length)); ack_writes++;
    return 1;
}

static void startup(void)
{
    boot_testing = 1; boot_length = boot_stage = queue_creations = 0; boot_ce = 0xFF;
    boot_probe_calls = boot_radio_calls = boot_delay_ms = 0;
    memset(&runtime_timer, 0xFF, sizeof(runtime_timer));
    if (!setjmp(boot_exit)) flight_app_start();
    boot_testing = 0;
    assert(strstr(boot_log, "FC NORMAL v3"));
    assert(strstr(boot_log, "FC CONTROL v3 cap_pct=75,85,95 smooth_ms=80,80 i_start_pct=12 aw=axis"));
    assert(strstr(boot_log, "FC TRIM v1 R_zero_ddeg=-20 P_zero_ddeg=20 front_pct=0 left_stick=live"));
    assert(boot_radio_calls == (boot_radio_bad ? 3U : boot_transient_failures + 1U));
    assert(boot_delay_ms == 50U * (boot_radio_calls - 1U));
    if (boot_radio_calls > 1) {
        assert(strstr(boot_log, boot_radio_calls == 2 ? "RADIO BOOT tries=2" : "RADIO BOOT tries=3"));
        assert(strstr(boot_log, "RADIO FIRST FAIL"));
    }
    assert(strstr(boot_log, "FC SPI DIAG v3"));
    assert(strstr(boot_log, "RADIO SPI n=1"));
    assert(strstr(boot_log, "RADIO SPI n=2"));
    assert(strstr(boot_log, boot_config_probe ? "cmd=20 tx=0C bytes=2 raw=1C,00" :
                                             "cmd=20 tx=0C bytes=2 raw=0E,00"));
    assert(strstr(boot_log, boot_config_probe ? "cmd=00 tx=FF bytes=2 raw=0E,08" :
                                             "cmd=00 tx=FF bytes=2 raw=0E,0C"));
    assert(strstr(boot_log, "valid=1 csn=0->1 CE=0"));
    assert(strstr(boot_log, boot_imu_bad == 2 ? "IMU=0 STEP=10" :
                          boot_imu_bad ? "IMU=0 STEP=4" : "IMU=1 STEP=0"));
    assert(strstr(boot_log, "MPU CHECK v1"));
    assert(strstr(boot_log, "MPU IO t=0 reg=75 HAL=0 E=00000000"));
    assert(strstr(boot_log, "MPU RANGE GYR=08/0 ACC=08/0"));
    if (boot_imu_bad != 1) {
        assert(strstr(boot_log, boot_imu_bad ?
            "stable=0 N=750 ms=3000 win=7 rej=04 badA=0 badV=0 badD=6" :
            "stable=1 N=200 ms=800 win=2 rej=00 badA=0 badV=0 badD=0"));
        assert(strstr(boot_log, "MPU RAW A=0,0,8192 G=0,0,0 norm_mg=1000..1000"));
        assert(strstr(boot_log, "mean_cds=25,-50,500 std_cds=100,50,25"));
        assert(strstr(boot_log, boot_imu_bad ? "delta_cds=75,12,0" : "delta_cds=25,12,0"));
    }
    assert(strstr(boot_log, FC_BARO_ENABLED && !boot_baro_bad ? "BARO=1" : "BARO=0"));
    assert(radio_ready == !boot_radio_bad && boot_ce == !boot_radio_bad);
    if (boot_config_probe) {
        assert(boot_probe_calls == 6 && !radio_ready && !boot_ce);
        assert(strstr(boot_log, "RADIO INIT FAIL reg=00 want=0C got=08"));
        assert(strstr(boot_log, "RADIO PROBE n=1") && strstr(boot_log, "RADIO PROBE n=3"));
        assert(!strstr(boot_log, "RADIO PROBE n=4"));
        assert(strstr(boot_log, boot_probe_stuck ? "want=0C got=08 RH=0" : "want=0C got=0C RH=0"));
    } else {
        assert(!boot_probe_calls && !strstr(boot_log, "RADIO PROBE"));
        assert((strstr(boot_log, "RADIO INIT FAIL reg=05 want=28 got=00") != NULL) == !!boot_radio_bad);
    }
    assert(!strstr(boot_log, "GPIO DIAG") && !strstr(boot_log, "FC AUTO") && !strstr(boot_log, "MPU GSEG"));
    assert(queue_creations == 3 && !TIM3->CCR1 && !TIM3->CCR2 && !TIM3->CCR3 && !TIM3->CCR4);
}
static void run_control(unsigned count, uint8_t imu)
{
    tick = output_count = command_count = delay_applied = stop_writes = stop_pending = 0;
    imu_calls = 0;
    output_limit = count; imu_ready = imu; baro_ready = FC_BARO_ENABLED && !boot_baro_bad;
    memset(outputs, 0, sizeof(outputs)); memset(&runtime_timer, 0, sizeof(runtime_timer));
    if (!setjmp(task_exit)) control_task(NULL);
    assert(output_count == count && IWDG->KR == 0xAAAA && IWDG->RLR == 499);
    if (!FC_BARO_ENABLED) {
        for (unsigned i = 0; i < output_count; i++) {
            const fl_telemetry_t *t = &outputs[i].telemetry;
            assert(!(t->flags & (FL_BARO_READY | FL_BARO_OK | FL_HEIGHT_READY)));
            assert(!t->baro_id && !t->pressure_dhpa && !t->temperature_dC);
            assert(!t->height_cm && !t->speed_cms);
        }
    }
}
static unsigned delayed_case(uint32_t at, uint32_t duration, uint8_t imu, uint8_t expired)
{
    unsigned found = 0;
    delay_start = at; delay_ms = duration; delay_imu = imu; radio_expired = expired;
    run_control(at / 4 + 6, 1);
    assert(delay_applied);
    for (unsigned i = 0; i < output_count; i++) {
        assert(outputs[i].dt >= 0.001f);
        if (i) assert(outputs[i].tick > outputs[i - 1].tick);
        if (outputs[i].tick == at + duration) found = i;
    }
    assert(found > 1 && outputs[found - 1].compare[0]);
    assert(outputs[found + 1].tick == at + duration + 4);
    return found;
}
static void assert_stopped(unsigned first, uint8_t fault)
{
    for (unsigned i = first; i < output_count; i++) {
        assert(outputs[i].telemetry.state == FL_FAULT && outputs[i].telemetry.fault == fault);
        assert(!(outputs[i].telemetry.flags & FL_ARMED));
        for (unsigned m = 0; m < 4; m++) assert(!outputs[i].compare[m] && !outputs[i].telemetry.motors[m]);
    }
}
static void read_log(void)
{
    log_length = 0; runtime_log[0] = 0; log_testing = 1;
    if (!setjmp(log_exit)) log_task(NULL);
    log_testing = 0;
}
static void control_cases(void)
{
    unsigned first;
    for (unsigned missing = 0; missing < 2; missing++) {
        no_command = (uint8_t)missing; idle_command = 1;
        run_control(1600, 1);
        for (unsigned i = 0; i < output_count; i++) {
            assert(outputs[i].telemetry.state == FL_STOPPED);
            for (unsigned m = 0; m < 4; m++) assert(!outputs[i].compare[m]);
        }
    }
    no_command = idle_command = 0;
    run_control(1600, 1);
    assert(outputs[1599].telemetry.state == FL_MANUAL && outputs[1599].compare[0] > 1440);
    center_after = 36; run_control(20, 1);
    assert(outputs[19].telemetry.state == FL_MANUAL && !outputs[19].compare[0] && !stop_writes);
    center_after = 0;
    first = delayed_case(32, 5, !FC_BARO_ENABLED, 0);
    assert(fabsf(outputs[first].dt - 0.009f) < 0.000001f);
    assert(outputs[first].telemetry.state == FL_MANUAL);
    first = delayed_case(32, 9, !FC_BARO_ENABLED, 0); assert_stopped(first, FL_TIMING_FAULT);
    first = delayed_case(192, 26, !FC_BARO_ENABLED, 1); assert_stopped(first, FL_RADIO_FAULT);
    first = delayed_case(32, 26, 1, 0); assert_stopped(first, FL_TIMING_FAULT);
    radio_expired = 0; run_control(6, 0); assert_stopped(0, FL_IMU_FAULT);
    kill_after = 45; first = delayed_case(32, 9, !FC_BARO_ENABLED, 0);
    assert(outputs[first].telemetry.fault == FL_TIMING_FAULT);
    assert(outputs[first + 1].telemetry.state == FL_STOPPED);
    read_log();
    assert(strstr(runtime_log, "FC STOP t=41 from=1 to=4 fault=5 cmd=01"));
    assert(strstr(runtime_log, FC_BARO_ENABLED ? "thr=700 dt=13 rx_age=0 imu_age=9" :
                                               "thr=700 dt=13 rx_age=0 imu_age=0"));
    assert(stop_writes == 1 && !stop_pending);
    read_log(); assert(!strstr(runtime_log, "FC STOP"));
    kill_after = 36; delayed_case(32, 0, !FC_BARO_ENABLED, 0); read_log();
    assert(strstr(runtime_log, "FC STOP t=36 from=1 to=0 fault=0 cmd=02"));
    kill_after = 0;
    puts("PASS: actual control task, 6.4s idle/held-throttle, zero throttle stays armed, PWM conversion, timing/IMU/radio/KILL stops, retained stop reason");
}

static void level_trim_cases(void)
{
    uint8_t packet[FL_TELEMETRY_LEN];
    fl_telemetry_t decoded;
    run_control(1600, 1);
    for (unsigned i = 0; i < output_count; i++) {
        assert(outputs[i].imu_valid && (outputs[i].telemetry.flags & FL_IMU_OK));
        assert(outputs[i].roll_deg == 0 && outputs[i].pitch_deg == 0);
        assert(!outputs[i].telemetry.roll_ddeg && !outputs[i].telemetry.pitch_ddeg);
    }
    assert(outputs[1599].telemetry.motors[0] == 525);
    assert(outputs[1599].telemetry.motors[0] == outputs[1599].telemetry.motors[1]);
    assert(outputs[1599].telemetry.motors[2] == 525 && outputs[1599].telemetry.motors[3] == 525);
    read_log();
    assert(strstr(runtime_log, "FC CTRL v1 t=6400 seq=63 st=1 thr=700 C=524 imu=1 A=0,0 T=0,0 E=0,0,0 I=0,0,0 sat=00/00 blk=00 M="));
    assert(strstr(runtime_log, "FC ALLOC v1 t=6400 Q=0,0,0 U=0,0,0\r\n"));
    fl_encode_telemetry(packet, &outputs[1599].telemetry);
    assert(fl_decode_telemetry(&decoded, packet, sizeof(packet)));
    assert(!decoded.roll_ddeg && !decoded.pitch_ddeg);
    measured_attitude.roll_deg = 3; /* Raw +3 means corrected right-down +5. */
    run_control(150, 1);
    assert(outputs[149].roll_deg == 5 && outputs[149].telemetry.roll_ddeg == 50);
    assert(outputs[149].telemetry.motors[1] > outputs[149].telemetry.motors[0]);
    assert(outputs[149].telemetry.motors[3] > outputs[149].telemetry.motors[2]);
    kill_after = 36; run_control(20, 1); read_log();
    assert(strstr(runtime_log, "R=50 P=0"));
    assert(saved_stop.roll_ddeg == 50 && saved_stop.pitch_ddeg == 0);
    kill_after = 0;
    measured_attitude.roll_deg = -2; measured_attitude.pitch_deg = 7;
    run_control(150, 1); /* Nose-up must still accelerate the rear with fixed trim disabled. */
    assert(outputs[149].pitch_deg == 5 && outputs[149].telemetry.pitch_ddeg == 50);
    assert(outputs[149].telemetry.motors[2] > outputs[149].telemetry.motors[0]);
    assert(outputs[149].telemetry.motors[3] > outputs[149].telemetry.motors[1]);
    measured_attitude.pitch_deg = 2;
    run_control(10, 0);
    for (unsigned i = 0; i < output_count; i++) {
        assert(!outputs[i].imu_valid && !(outputs[i].telemetry.flags & FL_IMU_OK));
        assert(!outputs[i].telemetry.roll_ddeg && !outputs[i].telemetry.pitch_ddeg);
        for (unsigned m = 0; m < 4; m++) assert(!outputs[i].compare[m]);
    }
    puts("PASS: level trim reaches control/telemetry/stop trace once per sample, preserves raw estimator state and feedback signs, never fabricates missing IMU data");
}
static void control_diagnostic_cases(void)
{
    fc_state_t state = {0};
    received_t rx = {0};
    mpu_attitude_t attitude = {0};
    unsigned spi_before = snapshot_calls, pwm_before[4];
    pwm_before[0] = TIM3->CCR1; pwm_before[1] = TIM3->CCR2;
    pwm_before[2] = TIM3->CCR3; pwm_before[3] = TIM3->CCR4;
    state.state = FL_HOLD; state.collective = 0.95f;
    state.height = 0.8f; state.hold_height = 1.0f; state.vertical_speed = -0.2f;
    state.hold_throttle = 0.5f; state.hold_cap = 0.95f; state.height_integral = 0.03f;
    state.baro_tick = UINT32_MAX - 32;
    state.parameters[FL_HEIGHT_P] = 120; state.parameters[FL_HEIGHT_I] = 30;
    state.parameters[FL_HEIGHT_D] = 80;
    state.angle_target[0] = -16; state.angle_target[1] = 16;
    state.integral[0] = 0.10f; state.integral[1] = -0.10f; state.yaw_integral = -0.05f;
    state.sat_positive = state.sat_negative = state.integrator_blocked = 7;
    for (unsigned axis = 0; axis < 3; axis++) {
        state.rate_error[axis] = -100000;
        state.requested[axis] = -100000;
        state.applied[axis] = -0.2f;
    }
    for (unsigned m = 0; m < 4; m++) state.motors[m] = 950;
    rx.control.seq = 255; rx.control.axes[3] = -1000;
    attitude.roll_deg = -180; attitude.pitch_deg = 180;
    save_control_diag(&state, &rx, &attitude, 1, UINT32_MAX);
    read_log();
    assert(strstr(runtime_log, "FC CTRL v1 t=4294967295 seq=255 st=2 thr=-1000 C=950 imu=1 A=-1800,1800 T=-160,160 E=-32767,-32767,-32767 I=100,-100,-50 sat=07/07 blk=07 M=950,950,950,950\r\n"));
    assert(strstr(runtime_log, "FC ALLOC v1 t=4294967295 Q=-32767,-32767,-32767 U=-200,-200,-200\r\n"));
    assert(strstr(runtime_log, "FC ALT v1 t=4294967295 st=2 fault=0 active=1 H=80 HT=100 V=-20 base=500 C=950 cap=950 I=30 age=32 PID=120,30,80\r\n"));
    assert(snapshot_calls == spi_before);
    assert(TIM3->CCR1 == pwm_before[0] && TIM3->CCR2 == pwm_before[1]);
    assert(TIM3->CCR3 == pwm_before[2] && TIM3->CCR4 == pwm_before[3]);
    attitude.roll_deg = NAN; attitude.pitch_deg = INFINITY;
    save_control_diag(&state, &rx, &attitude, 0, 12);
    assert(control_diag.angle[0] == 0 && control_diag.angle[1] == 0 && !control_diag.imu);
    puts("PASS: coherent controller snapshot, bounded log lines at extreme values, no diagnostic SPI/PWM operations and invalid-float handling");
}

static void barometer_cases(void)
{
    baro_testing = 1; baro_failed_after = 2300;
    for (unsigned failed = 0; failed < 2; failed++) {
        const fl_telemetry_t *last;
        fl_telemetry_t decoded;
        uint8_t packet[FL_TELEMETRY_LEN];
        boot_baro_bad = (uint8_t)failed; startup();
        run_control(700, 1); last = &outputs[699].telemetry;
        assert(last->flags & FL_ARMED);
        if (FC_BARO_ENABLED && !failed) {
            assert(outputs[0].telemetry.flags & FL_BARO_READY);
            assert(!(outputs[0].telemetry.flags & (FL_BARO_OK | FL_HEIGHT_READY)));
            assert(outputs[7].telemetry.flags & FL_BARO_OK);
            assert(outputs[255].telemetry.flags & FL_HEIGHT_READY);
            assert(outputs[500].telemetry.state == FL_HOLD);
            assert(last->state == FL_HOLD_EXIT && last->fault == FL_BARO_FAULT);
            assert(!(last->flags & FL_BARO_OK));
            assert(last->pressure_dhpa == 10133 && last->temperature_dC == 250 && last->baro_id == 1);
            fl_encode_telemetry(packet, last);
            assert(fl_decode_telemetry(&decoded, packet, sizeof(packet)));
            assert(decoded.pressure_dhpa == last->pressure_dhpa && decoded.temperature_dC == 250);
            assert(decoded.flags == last->flags && decoded.fault == FL_BARO_FAULT);
        } else {
            assert(last->state == FL_MANUAL && last->fault == FL_NO_FAULT);
            assert(!(last->flags & (FL_BARO_READY | FL_BARO_OK | FL_HEIGHT_READY)));
            assert(!last->pressure_dhpa && !last->temperature_dC);
        }
        assert(last->motors[0] > 0);
    }
    boot_baro_bad = baro_testing = 0; baro_failed_after = 0;
    puts("PASS: actual barometer task path, reference readiness, telemetry codec, K4 hold, stale-data takeover and failed-init manual flight");
}

static void radio_cases(void)
{
    const uint8_t seq[8] = {254,254,255,255,255,253,255,0};
    fl_control_t c = {0}; c.param_value = fl_param_default(FL_RATE_P);
    for (unsigned i = 0; i < 8; i++) {
        c.seq = seq[i]; fl_encode_control(radio_packets[i], &c); radio_lengths[i] = FL_CONTROL_LEN;
    }
    radio_lengths[2]--; radio_packets[3][0] ^= 0xFF; radio_lengths[4] = 0;
    for (unsigned failure = 0; failure < 3; failure++) {
        tick = 100; radio_round = radio_packet = 0;
        fifo_reads = status_writes = command_writes = ack_writes = 0;
        radio_io_bad = failure == 1; radio_ready = failure != 2; radio_testing = 1;
        if (!setjmp(radio_exit)) radio_task(NULL);
        radio_testing = 0;
        if (!failure) {
            assert(command_writes == 3 && accepted_seq[0] == 254 && accepted_seq[1] == 255 && accepted_seq[2] == 0);
            assert(fifo_reads == 9 && status_writes == 3 && ack_writes == 3);
        } else {
            assert(!command_writes && !radio_packet);
            if (failure == 2) assert(!fifo_reads && !status_writes && !ack_writes);
        }
        read_log();
        assert(strstr(runtime_log, "FC RX v1"));
        if (!failure) assert(strstr(runtime_log, "FC RF v1 tag=BOOT"));
        assert(strstr(runtime_log, "read=8 ok=3 bad=2 zero=1 old=2"));
        assert(strstr(runtime_log, "len=18 head=C3,03"));
        if (!failure) {
            assert(strstr(runtime_log, "loops=3 on=1 age=0 fifo=01 S=00"));
            assert(strstr(runtime_log, "ff=0 ack=3"));
            assert(snapshot_calls == 1);
        } else if (failure == 1) {
            assert(strstr(runtime_log, "loops=6 on=1 age=0 fifo=FF S=00"));
            assert(strstr(runtime_log, "ff=3 ack=6"));
        } else {
            assert(strstr(runtime_log, "loops=9 on=0 age=0 fifo=FF S=00"));
            assert(strstr(runtime_log, "ff=3 ack=6"));
            assert(snapshot_calls == 2); /* Failed init must not trigger diagnostic SPI. */
        }
    }
    puts("PASS: actual radio task and RX diagnostics, invalid/zero/old packets, SPI-FF and failed-init gate; unchanged SPI/queue counts, logging outside radio task");
}
static void snapshot_cases(void)
{
    fl_control_t c = {0};
    c.param_value = fl_param_default(FL_RATE_P);
    for (unsigned i = 0; i < 2; i++) {
        c.seq = (uint8_t)(254 + i);
        fl_encode_control(radio_packets[i], &c); radio_lengths[i] = FL_CONTROL_LEN;
    }
    memset(&radio_rx_diag, 0, sizeof(radio_rx_diag));
    memset(radio_snapshots, 0, sizeof(radio_snapshots)); radio_snapshot_number = 0;
    tick = 100; radio_round = radio_packet = radio_io_bad = 0;
    fifo_reads = status_writes = command_writes = ack_writes = snapshot_calls = 0;
    radio_ready = radio_testing = gap_testing = 1; radio_round_limit = 30;
    if (!setjmp(radio_exit)) radio_task(NULL);
    radio_testing = gap_testing = 0; radio_round_limit = 3;
    assert(command_writes == 2 && accepted_seq[0] == 254 && accepted_seq[1] == 255);
    assert(snapshot_calls == 4 && status_writes == 30 && ack_writes == 30);
    assert(radio_snapshots[RADIO_BOOT].chip.tick == 100);
    assert(radio_snapshots[RADIO_GAP].chip.tick == 160 && radio_snapshots[RADIO_GAP].rx_age == 60);
    assert(radio_snapshots[RADIO_LATE].chip.tick == 280 && radio_snapshots[RADIO_LATE].rx_age == 180);
    assert(radio_snapshots[RADIO_BACK].chip.tick == 360 && !radio_snapshots[RADIO_BACK].rx_age);
    read_log();
    assert(strstr(runtime_log, "FC RF v1 tag=GAP n=2 t=160"));
    assert(strstr(runtime_log, "FC RF v1 tag=LATE n=3 t=280"));
    assert(strstr(runtime_log, "FC RF v1 tag=BACK n=4 t=360"));
    assert(strstr(runtime_log, "FC REG tag=GAP") && strstr(runtime_log, "FC SPI tag=GAP"));
    assert(strstr(runtime_log, "CE=1 CSN=1 CR1=0000 valid=FFF"));
    puts("PASS: baseline, 60ms gap, 180ms late gap and recovery retained separately; no repeated probes while disconnected; only radio task probes");
}
int main(void)
{
    assert(FC_LINK_TIMEOUT_MS == 200 && NRF_RADIO_CHANNEL == 40);
    for (unsigned failed = 0; failed < 4; failed++) {
        boot_imu_bad = failed & 1; boot_radio_bad = (failed >> 1) & 1; startup();
    }
    boot_radio_bad = boot_config_probe = 1;
    for (boot_probe_stuck = 0; boot_probe_stuck < 2; boot_probe_stuck++) startup();
    boot_config_probe = 0;
    boot_imu_bad = boot_radio_bad = 0;
    for (boot_transient_failures = 1; boot_transient_failures <= 2; boot_transient_failures++) startup();
    boot_transient_failures = 0;
    boot_imu_bad = 2; boot_radio_bad = 0; startup();
    boot_imu_bad = boot_radio_bad = 0; startup();
    level_trim_cases(); control_cases(); barometer_cases(); radio_cases(); snapshot_cases();
    control_diagnostic_cases();
    puts("PASS: boot retries recover 1/2 transient init failures; three persistent failures remain disabled; first failure retained and PWM stays zero during retry waits");
    puts("PASS: startup order, zero motors, bounded CONFIG probes preserve original failure and keep RX disabled even on successful readback");
    return 0;
}
