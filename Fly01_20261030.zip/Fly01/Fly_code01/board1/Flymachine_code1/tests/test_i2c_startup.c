#include "bsp_i2c_startup.h"
#include "i2c.h"
#include "flight_config.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

I2C_HandleTypeDef hi2c1;
GPIO_TypeDef mock_gpio_b;
static uint32_t tick, gpio_mode, released, device_ready[2], stretch_until;
static unsigned rises, deinit_count, init_count, probes[2];
static uint8_t held_sda, hard_sda_low, hard_scl_low, absent_mask, stretch_on_rise;

void HAL_Delay(uint32_t ms) { tick += ms; }
uint32_t HAL_GetTick(void) { return tick; }
HAL_StatusTypeDef HAL_I2C_DeInit(I2C_HandleTypeDef *i2c)
{ assert(i2c == &hi2c1); deinit_count++; gpio_mode = 0; return HAL_OK; }
HAL_StatusTypeDef HAL_I2C_Init(I2C_HandleTypeDef *i2c)
{ assert(i2c == &hi2c1); init_count++; gpio_mode = GPIO_MODE_AF_OD; return HAL_OK; }
void HAL_GPIO_Init(GPIO_TypeDef *port, GPIO_InitTypeDef *config)
{
    assert(port == GPIOB && config->Pin == (GPIO_PIN_6 | GPIO_PIN_7));
    assert(config->Mode == GPIO_MODE_OUTPUT_OD && config->Pull == GPIO_NOPULL);
    assert(released == (GPIO_PIN_6 | GPIO_PIN_7));
    gpio_mode = config->Mode;
}
void HAL_GPIO_WritePin(GPIO_TypeDef *port, uint16_t pins, GPIO_PinState state)
{
    assert(port == GPIOB);
    if (gpio_mode == GPIO_MODE_OUTPUT_OD && (pins & GPIO_PIN_6) &&
        state == GPIO_PIN_SET && !(released & GPIO_PIN_6)) {
        rises++;
        if (rises == stretch_on_rise) stretch_until = tick + 3U;
        if (rises >= 9) held_sda = 0;
    }
    if (state == GPIO_PIN_SET) released |= pins;
    else released &= ~(uint32_t)pins;
}
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *port, uint16_t pin)
{
    assert(port == GPIOB && (pin == GPIO_PIN_6 || pin == GPIO_PIN_7));
    if (!(released & pin)) return GPIO_PIN_RESET;
    if (pin == GPIO_PIN_6 && (hard_scl_low || (int32_t)(tick - stretch_until) < 0))
        return GPIO_PIN_RESET;
    if (pin == GPIO_PIN_7 && (hard_sda_low || held_sda)) return GPIO_PIN_RESET;
    return GPIO_PIN_SET;
}
HAL_StatusTypeDef HAL_I2C_IsDeviceReady(I2C_HandleTypeDef *i2c, uint16_t address,
                                      uint32_t trials, uint32_t timeout)
{
    unsigned sensor = address == 0xD0 ? 0U : 1U;
    assert(i2c == &hi2c1 && (address == 0xD0 || address == 0xEC));
    assert(trials == 1 && timeout == 5 && gpio_mode == GPIO_MODE_AF_OD);
    assert(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6) == GPIO_PIN_SET);
    assert(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_SET);
    if (!FC_BARO_ENABLED) assert(sensor == 0);
    probes[sensor]++;
    return !(absent_mask & (1U << sensor)) && (int32_t)(tick - device_ready[sensor]) >= 0 ? HAL_OK : HAL_ERROR;
}
static void reset_case(void)
{
    tick = gpio_mode = released = rises = deinit_count = init_count = stretch_until = 0;
    memset(probes, 0, sizeof(probes)); memset(device_ready, 0, sizeof(device_ready));
    held_sda = hard_sda_low = hard_scl_low = absent_mask = stretch_on_rise = 0;
}
int main(void)
{
    i2c_startup_diag_t d;
    if (!FC_BARO_ENABLED) {
        reset_case(); device_ready[0] = 75; absent_mask = 2;
        bsp_i2c_startup(&d);
        assert(d.ready_mask == 1 && probes[0] > 1 && !probes[1]);
        assert(d.end_ms == 75 && init_count == 1 && gpio_mode == GPIO_MODE_AF_OD);
        reset_case(); hard_sda_low = 1;
        bsp_i2c_startup(&d);
        assert(!d.ready_mask && !probes[0] && !probes[1]);
        puts("PASS: disabled barometer is never probed; MPU bus recovery and stuck-line checks retained");
        return 0;
    }
    reset_case(); device_ready[0] = 75; device_ready[1] = 90;
    bsp_i2c_startup(&d);
    assert(d.ready_mask == 3 && !d.pulses && probes[0] > 1 && probes[1] > 1);
    assert(d.start_ms == 0 && d.end_ms >= 90 && d.end_ms < 300);
    assert(d.scl_before && d.sda_before && d.scl_after && d.sda_after);
    assert(deinit_count == 1 && init_count == 1 && gpio_mode == GPIO_MODE_AF_OD);

    reset_case(); held_sda = 1; stretch_on_rise = 4;
    bsp_i2c_startup(&d);
    assert(d.ready_mask == 3 && d.pulses == 9 && rises >= 9);
    assert(d.scl_before && !d.sda_before && d.scl_after && d.sda_after);
    assert(released == (GPIO_PIN_6 | GPIO_PIN_7) && gpio_mode == GPIO_MODE_AF_OD);

    reset_case(); hard_sda_low = 1;
    bsp_i2c_startup(&d);
    assert(!d.ready_mask && d.pulses == 9 && !d.sda_after && !probes[0] && !probes[1]);
    assert(d.end_ms - d.start_ms < 100 && init_count == 1);

    reset_case(); hard_scl_low = 1;
    bsp_i2c_startup(&d);
    assert(!d.ready_mask && !d.pulses && !d.scl_after && !probes[0] && !probes[1]);
    assert(d.end_ms - d.start_ms < 100 && init_count == 1);
    assert(released == (GPIO_PIN_6 | GPIO_PIN_7));

    reset_case(); absent_mask = 1;
    bsp_i2c_startup(&d);
    assert(d.ready_mask == 2 && probes[0] > 1 && probes[1] == 1);
    assert(d.end_ms - d.start_ms >= 100 && d.end_ms - d.start_ms < 300);
    reset_case(); absent_mask = 3;
    bsp_i2c_startup(&d);
    assert(!d.ready_mask && d.end_ms - d.start_ms >= 200 && d.end_ms - d.start_ms < 400);

    reset_case(); tick = UINT32_MAX - 25U; stretch_until = tick;
    device_ready[0] = device_ready[1] = tick + 75U;
    bsp_i2c_startup(&d);
    assert(d.ready_mask == 3 && d.end_ms - d.start_ms >= 75 && d.end_ms - d.start_ms < 300);
    puts("PASS: I2C boot probes, nine-clock recovery, stretch, bounded stuck/absent faults, AF restore, tick wrap");
    return 0;
}
