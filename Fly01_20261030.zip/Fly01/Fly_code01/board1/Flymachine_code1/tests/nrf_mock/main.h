#ifndef NRF_TEST_MAIN_H
#define NRF_TEST_MAIN_H
#include <stdint.h>
typedef int HAL_StatusTypeDef;
enum { HAL_OK, HAL_ERROR, HAL_BUSY, HAL_TIMEOUT };
typedef struct { uint32_t CR1; } SPI_TypeDef;
typedef struct { uint32_t ErrorCode; SPI_TypeDef *Instance; } SPI_HandleTypeDef;
typedef struct { uint32_t IDR, ODR, MODER, AFR[2]; } GPIO_TypeDef;
extern GPIO_TypeDef test_gpio;
extern SPI_TypeDef test_spi;
#define GPIOB (&test_gpio)
#define SPI2 (&test_spi)
#define SPI_CR1_SPE (1U << 6)
#define __HAL_SPI_ENABLE(handle) ((handle)->Instance->CR1 |= SPI_CR1_SPE)
enum { GPIO_PIN_RESET, GPIO_PIN_SET };
#define CSN_GPIO_Port GPIOB
#define CSN_Pin (1U << 12)
#define CE_GPIO_Port GPIOB
#define CE_Pin (1U << 5)
extern uint32_t test_primask;
#define __get_PRIMASK() test_primask
#define __disable_irq() (test_primask = 1U)
#define __set_PRIMASK(mask) (test_primask = (mask))
uint32_t HAL_GetTick(void);
void HAL_Delay(uint32_t ms);
void HAL_GPIO_WritePin(GPIO_TypeDef *port, unsigned pin, unsigned value);
int HAL_SPI_TransmitReceive(SPI_HandleTypeDef *, uint8_t *, uint8_t *, uint16_t, uint32_t);
int HAL_SPI_Transmit(SPI_HandleTypeDef *, uint8_t *, uint16_t, uint32_t);
#endif
