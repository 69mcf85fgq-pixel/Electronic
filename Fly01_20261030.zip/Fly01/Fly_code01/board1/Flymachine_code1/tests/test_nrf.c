#include "bsp_nrf.h"
#include "flight_link.h"
#include "spi.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

SPI_HandleTypeDef hspi2 = {.Instance = &test_spi};
GPIO_TypeDef test_gpio;
SPI_TypeDef test_spi;
uint32_t test_primask;
static uint8_t registers[32], address[5], ack[32];
static uint8_t selected, tx_queued, rx_queued, width, ack_size;
static uint8_t bad_reg, bad_address, bad_status, all_zero, flush_broken;
static uint8_t config_read_override, config_read_value;
static unsigned calls, fault_call, fail_kind, transactions, flush_tx, flush_rx;
static unsigned bad_status_call;
static uint32_t tick, powered_at;
static uint8_t snapshot_testing;

uint32_t HAL_GetTick(void) { return tick; }
void HAL_Delay(uint32_t ms)
{
    if (ms == 100) {
        assert(!selected && (test_gpio.ODR & CSN_Pin) && !(test_gpio.ODR & CE_Pin));
        assert(test_spi.CR1 & SPI_CR1_SPE);
    }
    tick += ms;
}
void HAL_GPIO_WritePin(GPIO_TypeDef *port, unsigned pin, unsigned value)
{
    if (value) port->IDR = port->ODR |= pin;
    else port->IDR = port->ODR &= ~pin;
    if (pin == CSN_Pin) {
        if (!value) {
            assert(!selected && (test_spi.CR1 & SPI_CR1_SPE));
            transactions++;
        }
        selected = !value;
    }
}

int HAL_SPI_TransmitReceive(SPI_HandleTypeDef *spi, uint8_t *tx, uint8_t *rx,
                            uint16_t size, uint32_t timeout)
{
    uint8_t command = tx[0];
    assert(selected && !test_primask && size >= 1 && size <= 33);
    assert(tick >= 100); /* Si24R1 cold power-on interval, datasheet figure 3-1. */
    assert(timeout == NRF_SPI_TIMEOUT_MS);
    calls++;
    if (snapshot_testing) assert(command <= NRF_REG_FEATURE); /* Read commands only. */
    spi->ErrorCode = 0;
    if (calls == fault_call) {
        memset(rx, 0x55, size);
        spi->ErrorCode = 0x20;
        tick += NRF_SPI_TIMEOUT_MS;
        return (int)fail_kind;
    }
    memset(rx, 0, size);
    rx[0] = bad_status || calls == bad_status_call ? 0xFF : 0x0E;
    if (all_zero) return HAL_OK;
    if ((command & 0xE0U) == NRF_CMD_W_REGISTER) {
        uint8_t reg = command & 0x1FU;
        assert(!(test_gpio.ODR & CE_Pin) || reg == NRF_REG_STATUS);
        if (reg == NRF_REG_RX_ADDR_P0) {
            assert(size == 6); memcpy(address, tx + 1, 5);
        } else {
            assert(size == 2);
            registers[reg] = reg == NRF_REG_STATUS ? registers[reg] & ~tx[1] : tx[1];
            if (reg == NRF_REG_CONFIG && (tx[1] & 2)) powered_at = tick;
        }
    } else if (command <= NRF_REG_FEATURE) {
        for (unsigned i = 1; i < size; i++) assert(tx[i] == 0xFF);
        if (command == NRF_REG_RX_ADDR_P0) {
            assert(size == 6); memcpy(rx + 1, address, 5);
            if (bad_address < 5) rx[1 + bad_address] ^= 1;
        } else {
            assert(size == 2);
            rx[1] = command == NRF_REG_FIFO_STATUS ?
                    (tx_queued ? 0 : NRF_FIFO_TX_EMPTY) | (rx_queued ? 0 : NRF_FIFO_RX_EMPTY) :
                    registers[command];
            if (command == bad_reg) rx[1] ^= 1;
            if (command == NRF_REG_CONFIG && config_read_override) rx[1] = config_read_value;
        }
    } else if (command == NRF_CMD_FLUSH_TX) {
        assert(size == 1 && !(test_gpio.ODR & CE_Pin));
        flush_tx++;
        if (!flush_broken) tx_queued = 0;
    } else if (command == NRF_CMD_FLUSH_RX) {
        assert(size == 1 && !(test_gpio.ODR & CE_Pin));
        flush_rx++; rx_queued = 0;
    } else if (command == NRF_CMD_R_RX_PL_WID) {
        assert(size == 2 && tx[1] == 0xFF); rx[1] = width;
    } else if (command == NRF_CMD_R_RX_PAYLOAD) {
        assert(size == width + 1U);
        for (unsigned i = 1; i < size; i++) { assert(tx[i] == 0xFF); rx[i] = (uint8_t)(i - 1); }
        rx_queued = 0;
    } else if (command == NRF_CMD_W_ACK_PAYLOAD) {
        assert(!tx_queued && size >= 2); ack_size = (uint8_t)(size - 1);
        memcpy(ack, tx + 1, ack_size); tx_queued = 1;
    } else assert(0); /* In particular, no undocumented ACTIVATE fallback. */
    return HAL_OK;
}
int HAL_SPI_Transmit(SPI_HandleTypeDef *spi, uint8_t *tx, uint16_t size, uint32_t timeout)
{ (void)spi; (void)tx; (void)size; (void)timeout; assert(0); return HAL_ERROR; }

static void reset(void)
{
    memset(registers, 0xA5, sizeof(registers)); memset(address, 0, sizeof(address));
    registers[NRF_REG_STATUS] = NRF_FLAG_CLR_ALL;
    selected = ack_size = bad_status = all_zero = flush_broken = 0;
    config_read_override = config_read_value = 0;
    bad_status_call = 0;
    tx_queued = 3; rx_queued = 1; width = FL_CONTROL_LEN;
    bad_reg = bad_address = 0xFF;
    tick = powered_at = calls = transactions = fault_call = flush_tx = flush_rx = 0;
    test_spi.CR1 = 0;
    test_gpio.IDR = test_gpio.ODR = CE_Pin | CSN_Pin;
    fail_kind = HAL_TIMEOUT;
}

static void init_cases(void)
{
    static const uint8_t wanted_address[5] = {0xA1, 0xB2, 0xC3, 0xD4, 0xE5};
    static const uint8_t regs[] = {0,1,2,3,4,5,6,0x11,0x1D,0x1C};
    static const uint8_t values[] = {0x0F,1,1,3,0x1A,40,6,18,6,1};
    unsigned successful_calls;
    nrf_error_t error;
    reset();
    assert(bsp_nrf_init() == 0);
    assert(!selected && !(test_gpio.ODR & CE_Pin));
    assert(tick - powered_at >= 2 && tick >= 102);
    for (unsigned i = 0; i < sizeof(regs); i++) assert(registers[regs[i]] == values[i]);
    assert(!memcmp(address, wanted_address, 5));
    assert(flush_tx == 1 && flush_rx == 1 && !tx_queued && !rx_queued);
    assert((registers[NRF_REG_STATUS] & NRF_FLAG_CLR_ALL) == 0);
    assert(calls == transactions); /* Every complete command uses one HAL transfer. */
    assert(calls == 28); /* Diagnostics must not add initialization transactions. */
    successful_calls = calls;
    /* A warm MCU reset must also discard pending ACKs, not inherit the old session. */
    tx_queued = 3; rx_queued = 1; test_gpio.ODR |= CE_Pin;
    test_spi.CR1 = 0;
    assert(bsp_nrf_init() == 0 && !tx_queued && !rx_queued);
    for (unsigned status = HAL_ERROR; status <= HAL_TIMEOUT; status++) {
        for (unsigned i = 1; i <= successful_calls; i++) {
            reset(); fault_call = i; fail_kind = status;
            assert(bsp_nrf_init() != 0 && calls == i);
            assert(!selected && !(test_gpio.ODR & CE_Pin));
            bsp_nrf_get_error(&error);
            assert(error.hal == status && error.spi_error == 0x20);
        }
    }
    for (unsigned i = 0; i < sizeof(regs); i++) {
        reset(); bad_reg = regs[i];
        assert(bsp_nrf_init() != 0);
        bsp_nrf_get_error(&error);
        assert(error.reg == regs[i] && error.expected != error.actual);
    }
    for (unsigned i = 0; i < 5; i++) {
        reset(); bad_address = (uint8_t)i;
        assert(bsp_nrf_init() != 0);
        bsp_nrf_get_error(&error);
        assert(error.reg == NRF_REG_RX_ADDR_P0 && error.expected == wanted_address[i]);
    }
    reset(); flush_broken = 1; assert(bsp_nrf_init() != 0);
    reset(); bad_status = 1; assert(bsp_nrf_init() != 0);
    reset(); all_zero = 1; assert(bsp_nrf_init() != 0);
    puts("PASS: SPI enabled before boot wait and CSN selection on cold/warm initialization; full register/address verification, FIFO reset, all-zero/all-FF, HAL ERROR/BUSY/TIMEOUT at every init transaction");
}

static void payload_cases(void)
{
    uint8_t data[32];
    reset(); assert(bsp_nrf_init() == 0);
    test_gpio.ODR |= CE_Pin;
    for (unsigned len = 1; len <= 32; len++) {
        width = (uint8_t)len; rx_queued = 1;
        assert(bsp_nrf_read_packet(data, sizeof(data)) == len);
        for (unsigned i = 0; i < len; i++) assert(data[i] == i);
    }
    for (unsigned failed_part = 1; failed_part <= 2; failed_part++) {
        width = 18; memset(data, 0xAA, sizeof(data)); fault_call = calls + failed_part;
        assert(bsp_nrf_read_packet(data, sizeof(data)) == 0);
        for (unsigned i = 0; i < sizeof(data); i++) assert(data[i] == 0xAA);
        assert(!selected); fault_call = 0;
    }
    width = 33; assert(!bsp_nrf_read_packet(data, sizeof(data)) && !rx_queued);
    assert(test_gpio.ODR & CE_Pin);
    width = 0; assert(!bsp_nrf_read_packet(data, sizeof(data)));
    width = 32; assert(!bsp_nrf_read_packet(data, 18));
    unsigned before = calls;
    assert(!bsp_nrf_read_packet(NULL, 32) && !bsp_nrf_read_packet(data, 0));
    assert(calls == before);
    memset(data, 0xC3, sizeof(data));
    assert(bsp_nrf_write_ack_payload(data, 32));
    assert(ack_size == 32 && !memcmp(ack, data, 32));
    assert(!bsp_nrf_write_ack_payload(data, 32));
    tx_queued = 0; fault_call = calls + 1;
    assert(!bsp_nrf_write_ack_payload(data, 32));
    fault_call = calls + 2;
    assert(!bsp_nrf_write_ack_payload(data, 32) && !tx_queued && !selected);
    fault_call = 0;
    before = calls;
    assert(!bsp_nrf_write_ack_payload(NULL, 32));
    assert(!bsp_nrf_write_ack_payload(data, 0) && !bsp_nrf_write_ack_payload(data, 33));
    assert(calls == before);
    puts("PASS: payload lengths 1..32, invalid widths, partial transfer rejection, ACK framing/backpressure, CSN cleanup, 3ms HAL timeout");
}

static void boot_diag_cases(void)
{
    nrf_error_t error;
    nrf_spi_diag_t saved[2];
    unsigned before;
    reset();
    assert(bsp_nrf_init() == 0);
    before = calls;
    bsp_nrf_get_error(&error);
    assert(calls == before && error.boot_count == 2);
    assert(error.boot_io[0].ms == 100 && error.boot_io[0].command == 0x20);
    assert(error.boot_io[0].tx_data == 0x0C && error.boot_io[0].bytes == 2);
    assert(error.boot_io[0].status == 0x0E && error.boot_io[0].valid);
    assert(error.boot_io[1].command == 0x00 && error.boot_io[1].tx_data == 0xFF);
    assert(error.boot_io[1].status == 0x0E && error.boot_io[1].rx_data == 0x0C);
    for (unsigned i = 0; i < 2; i++) {
        assert(error.boot_io[i].hal == HAL_OK && !error.boot_io[i].spi_error);
        assert(!error.boot_io[i].csn_active && error.boot_io[i].csn_idle);
        assert(!error.boot_io[i].ce);
    }
    memcpy(saved, error.boot_io, sizeof(saved));
    assert(bsp_nrf_read_reg(NRF_REG_CONFIG) == 0x0F);
    bsp_nrf_get_error(&error);
    assert(error.boot_count == 2 && !memcmp(saved, error.boot_io, sizeof(saved)));

    reset(); bad_status = 1;
    assert(bsp_nrf_init() != 0 && calls == 1);
    bsp_nrf_get_error(&error);
    assert(error.actual == 0xFF && error.boot_count == 1);
    assert(error.boot_io[0].command == 0x20 && error.boot_io[0].status == 0xFF);
    assert(error.boot_io[0].hal == HAL_OK && !error.boot_io[0].valid);

    reset(); bad_status_call = 2;
    assert(bsp_nrf_init() != 0 && calls == 2);
    bsp_nrf_get_error(&error);
    assert(error.actual == 0xFF && error.boot_count == 2);
    assert(error.boot_io[0].valid && !error.boot_io[1].valid);
    assert(error.boot_io[1].command == 0x00 && error.boot_io[1].status == 0xFF);

    reset(); config_read_override = 1; config_read_value = 0x08;
    assert(bsp_nrf_init() != 0 && calls == 2);
    bsp_nrf_get_error(&error);
    assert(error.actual == 0x08 && error.boot_io[1].rx_data == 0x08);
    assert(error.boot_io[1].valid);

    reset(); config_read_override = 1; config_read_value = 0xFF;
    assert(bsp_nrf_init() != 0 && calls == 2);
    bsp_nrf_get_error(&error);
    assert(error.actual == 0xFF && error.boot_io[1].status == 0x0E);
    assert(error.boot_io[1].rx_data == 0xFF && error.boot_io[1].valid);

    reset(); fault_call = 1;
    assert(bsp_nrf_init() != 0 && calls == 1);
    bsp_nrf_get_error(&error);
    assert(error.boot_count == 1 && error.boot_io[0].hal == HAL_TIMEOUT);
    assert(error.boot_io[0].spi_error == 0x20 && error.boot_io[0].status == 0x55);
    assert(!error.boot_io[0].valid && !selected);

    reset();
    assert(bsp_nrf_init() == 0);
    bsp_nrf_get_error(&error);
    assert(error.boot_count == 2 && error.boot_io[0].hal == HAL_OK);
    puts("PASS: boot raw SPI distinguishes invalid write/read STATUS, real 08/FF readback and HAL failure; two frozen records, no extra transactions");
}

static void snapshot_cases(void)
{
    nrf_snapshot_t s;
    unsigned before, tx_flushes, rx_flushes;
    reset(); assert(bsp_nrf_init() == 0);
    test_gpio.IDR = test_gpio.ODR |= CE_Pin;
    tx_queued = rx_queued = 1;
    before = calls; tx_flushes = flush_tx; rx_flushes = flush_rx;
    snapshot_testing = 1;
    bsp_nrf_snapshot(&s);
    assert(calls - before == 12 && s.valid == 0xFFF && s.ce && s.csn);
    assert(s.regs[NRF_SNAP_CONFIG] == 0x0F && s.regs[NRF_SNAP_CH] == 40);
    assert(s.regs[NRF_SNAP_RF] == 6 && !memcmp(s.address, address, 5));
    assert(s.io.calls == calls && !s.io.hal_errors && !s.io.bad_status);
    assert(tx_queued && rx_queued && flush_tx == tx_flushes && flush_rx == rx_flushes);
    assert(!selected && (test_gpio.ODR & CE_Pin));
    before = calls; bsp_nrf_snapshot(NULL); assert(before == calls);

    fault_call = calls + 3; fail_kind = HAL_TIMEOUT;
    bsp_nrf_snapshot(&s);
    assert(calls == fault_call && s.valid == 3 && s.regs[NRF_SNAP_EN] == 0xFF);
    assert(s.elapsed_ms == NRF_SPI_TIMEOUT_MS && s.io.hal_errors == 1);
    assert(s.io.hal == HAL_TIMEOUT && s.io.spi_error == 0x20);
    assert(s.io.command == NRF_REG_EN_RXADDR && s.io.max_ms == NRF_SPI_TIMEOUT_MS);
    fault_call = 0;
    bsp_nrf_snapshot(&s);
    assert(s.valid == 0xFFF && s.io.hal_errors == 1 && s.io.hal == HAL_TIMEOUT);
    assert(s.io.spi_error == 0x20); /* Good transfers do not erase the last failure. */
    bad_status_call = calls + 1;
    bsp_nrf_snapshot(&s);
    assert(!s.valid && s.io.bad_status == 1 && s.io.hal_errors == 1);
    assert(s.io.hal == HAL_OK && s.io.status == 0xFF);
    assert(!selected && (test_gpio.ODR & CE_Pin) && tx_queued && rx_queued);
    bad_status_call = 0;
    for (unsigned part = 1; part <= 12; part++) {
        fault_call = calls + part;
        bsp_nrf_snapshot(&s);
        assert(calls == fault_call && s.valid == (1U << (part - 1)) - 1U);
        assert(s.io.command == (part == 12 ? NRF_REG_RX_ADDR_P0 :
            (uint8_t[]){0,1,2,3,5,6,7,0x17,0x11,0x1D,0x1C}[part - 1]));
        assert(!selected && (test_gpio.ODR & CE_Pin) && tx_queued && rx_queued);
    }
    fault_call = 0;
    registers[NRF_REG_CONFIG] = 0x08; registers[NRF_REG_RF_CH] = 70;
    bsp_nrf_snapshot(&s);
    assert(s.valid == 0xFFF && s.regs[NRF_SNAP_CONFIG] == 8 && s.regs[NRF_SNAP_CH] == 70);
    assert(registers[NRF_REG_CONFIG] == 8 && registers[NRF_REG_RF_CH] == 70);
    snapshot_testing = 0;
    puts("PASS: read-only RF snapshots, address/config, validity mask, first-error abort, sticky HAL/STATUS failures and CE/FIFO preservation");
}

int main(void)
{
    init_cases(); payload_cases(); boot_diag_cases(); snapshot_cases();
    return 0;
}
