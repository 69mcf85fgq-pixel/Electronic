#define main original_flight_test_main
#include "test_flight.c"
#undef main
int main(void) {
 prepare(); c.axes[3]=400; step(1000);
 assert(s.motors[0]==300 && s.motors[1]==300 && s.motors[2]==303 && s.motors[3]==300);
 assert(s.sat_positive==0 && s.sat_negative==0);
 c.axes[3]=0; step(1); all_zero();
 prepare(); c.axes[3]=1000; step(1000);
 for(unsigned i=0;i<4;i++) assert(s.motors[i]<=750);
 c.flags=FL_KILL; step(1); all_zero();
 puts("PASS: M3 trim, cap and shutdown"); return 0;
}
