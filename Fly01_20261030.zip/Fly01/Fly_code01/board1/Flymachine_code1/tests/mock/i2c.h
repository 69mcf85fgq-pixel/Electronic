#ifndef MOCK_I2C_H
#define MOCK_I2C_H
#include <stdint.h>
#define I2C_MEMADD_SIZE_8BIT 1U
typedef enum {HAL_OK, HAL_ERROR, HAL_BUSY, HAL_TIMEOUT} HAL_StatusTypeDef;
typedef struct { uint32_t SR1, SR2; } I2C_TypeDef;
typedef struct { I2C_TypeDef *Instance; uint32_t ErrorCode; } I2C_HandleTypeDef;
typedef struct { uint32_t IDR; } GPIO_TypeDef;
typedef struct { uint32_t Pin, Mode, Pull, Speed; } GPIO_InitTypeDef;
typedef enum { GPIO_PIN_RESET, GPIO_PIN_SET } GPIO_PinState;
#define GPIO_PIN_6 (1U << 6)
#define GPIO_PIN_7 (1U << 7)
#define GPIO_MODE_OUTPUT_OD 1U
#define GPIO_MODE_AF_OD 2U
#define GPIO_NOPULL 0U
#define GPIO_SPEED_FREQ_LOW 0U
#define __HAL_RCC_GPIOB_CLK_ENABLE() ((void)0)
extern I2C_HandleTypeDef hi2c1;
extern GPIO_TypeDef mock_gpio_b;
#define GPIOB (&mock_gpio_b)
HAL_StatusTypeDef HAL_I2C_Mem_Write(I2C_HandleTypeDef *i2c, uint16_t address, uint16_t reg,
                                  uint16_t size, uint8_t *data, uint16_t length, uint32_t timeout);
HAL_StatusTypeDef HAL_I2C_Mem_Read(I2C_HandleTypeDef *i2c, uint16_t address, uint16_t reg,
                                 uint16_t size, uint8_t *data, uint16_t length, uint32_t timeout);
void HAL_Delay(uint32_t ms);
uint32_t HAL_GetTick(void);
HAL_StatusTypeDef HAL_I2C_Init(I2C_HandleTypeDef *i2c);
HAL_StatusTypeDef HAL_I2C_DeInit(I2C_HandleTypeDef *i2c);
HAL_StatusTypeDef HAL_I2C_IsDeviceReady(I2C_HandleTypeDef *i2c, uint16_t address,
                                      uint32_t trials, uint32_t timeout);
void HAL_GPIO_Init(GPIO_TypeDef *port, GPIO_InitTypeDef *config);
void HAL_GPIO_WritePin(GPIO_TypeDef *port, uint16_t pins, GPIO_PinState state);
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *port, uint16_t pin);
#endif
