#ifndef RUNTIME_MOCK_H
#define RUNTIME_MOCK_H
#include <stdint.h>

typedef uint32_t TickType_t;
typedef void *TaskHandle_t;
typedef void *QueueHandle_t;
typedef enum { HAL_OK, HAL_ERROR } HAL_StatusTypeDef;
typedef struct { volatile uint32_t CCR1, CCR2, CCR3, CCR4, CCER, CR1; } TIM_TypeDef;
typedef struct { volatile uint32_t KR, PR, RLR; } IWDG_TypeDef;
typedef struct { struct { uint32_t Period; } Init; } TIM_HandleTypeDef;
typedef struct { unsigned unused; } UART_HandleTypeDef;

extern TIM_TypeDef runtime_timer;
extern IWDG_TypeDef runtime_watchdog;
extern TIM_HandleTypeDef htim3;
extern UART_HandleTypeDef huart1;
#define TIM3 (&runtime_timer)
#define IWDG (&runtime_watchdog)
#define TIM_CR1_CEN 1U
#define TIM_CHANNEL_1 0U
#define TIM_CHANNEL_2 4U
#define TIM_CHANNEL_3 8U
#define TIM_CHANNEL_4 12U
#define CE_GPIO_Port 0U
#define CE_Pin 0U
#define GPIO_PIN_RESET 0U
#define GPIO_PIN_SET 1U
#define pdPASS 1
#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))
#define __disable_irq() ((void)0)
#define taskENTER_CRITICAL() ((void)0)
#define taskEXIT_CRITICAL() ((void)0)
#define __HAL_TIM_SET_COMPARE(handle, channel, value) runtime_set_compare(handle, channel, value)

uint32_t HAL_GetTick(void);
TickType_t xTaskGetTickCount(void);
void vTaskDelayUntil(TickType_t *wake, TickType_t interval);
void vTaskDelay(TickType_t interval);
int xQueueReceive(QueueHandle_t queue, void *out, TickType_t wait);
int xQueueOverwrite(QueueHandle_t queue, const void *in);
int xQueuePeek(QueueHandle_t queue, void *out, TickType_t wait);
QueueHandle_t xQueueCreate(unsigned count, unsigned size);
int xTaskCreate(void (*entry)(void *), const char *name, unsigned stack,
                void *argument, unsigned priority, TaskHandle_t *handle);
void vTaskStartScheduler(void);
void runtime_set_compare(TIM_HandleTypeDef *timer, uint32_t channel, uint32_t value);
HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *timer, uint32_t channel);
void HAL_GPIO_WritePin(unsigned port, unsigned pin, unsigned value);
HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *uart, uint8_t *data,
                                    uint16_t length, uint32_t timeout);
#endif
