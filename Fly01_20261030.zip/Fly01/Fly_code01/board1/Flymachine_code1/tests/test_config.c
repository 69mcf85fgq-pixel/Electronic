#include "flight_config.h"
#include <stdio.h>

_Static_assert(FC_BARO_ENABLED == 1U, "Normal aircraft firmware must enable the barometer");
_Static_assert(FC_FRONT_TRIM_RATIO == 0.0f, "Fixed front-motor trim must remain disabled");

int main(void)
{
    puts("PASS: normal aircraft configuration enables the barometer by default");
    return 0;
}
