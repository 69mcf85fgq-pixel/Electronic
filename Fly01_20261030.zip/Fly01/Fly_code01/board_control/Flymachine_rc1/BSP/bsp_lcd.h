#ifndef __BSP_LCD_H
#define __BSP_LCD_H
#include "main.h"

/* ==========================================================================
   1.69" 240x280 TFT —— ST7789V3  —— 遥控器板 P1 排座
   参数来源（都在 E:\2026Flymachine01\模块-8针蓝板模块\）：
     · 分辨率 240x280 / 驱动 IC ST7789V3 → 《1.69不带字库模块图纸.pdf》NOTES
     · 接线                              → 打板网表（tools\epru_netlist.py 还原）
     · 寄存器位定义                      → 《ST7789V.pdf》；**改任何值前先翻手册**

   ---- 接线（网表核实，P1 8 脚座）----
     P1.1 GND      P1.2 VCC(板上接 3V3)   P1.3 SCL -> PA5 (SPI1_SCK)
     P1.4 SDA -> PA7 (SPI1_MOSI)          P1.5 RES -> PA8
     P1.6 DC  -> PB15                     P1.7 CS  -> PB14
     P1.8 BLK -> 3V3 硬接，**常亮，软件关不掉**

   ---- ⚠️⚠️ 铁律：SPI1 是与 G01-S 无线模块**共享**的 ----
     nRF 用 PA5/PA6/PA7，屏幕只用 PA5/PA7（只写不读，不需要 MISO）。
     两个从设备靠各自的 CS 互斥，所以：
       ① 本文件所有函数**进出都把 CS 拉高**，绝不留低 —— 否则 nRF 收不到命令
       ② 绝不在 bsp_nrf_* 的一次事务中间插屏幕操作
       ③ 两边都是 Mode 0，共用一份 SPI 配置，不需要来回切换
     CubeMX 里 LCD_CS 必须设成**上电初始高电平**（空闲 = 不选中）。
   ========================================================================== */

/* ==========================================================================
   ---- 几何：**横屏**（面板物理竖装 240x280，但遥控器是横着拿的）----
   面板原生是 240(宽) x 280(高) 竖屏。靠 MADCTL 的 MV 位（bit5，"页列交换"）
   把显存行列转置，逻辑坐标就变成 280 宽 x 240 高。
   ========================================================================== */
#define LCD_W        280
#define LCD_H        240

/* ==========================================================================
   ---- 四个「旋钮」：第一次点亮就是要验证这四个值 ----
   这四个是**推导**出来的，不是抄厂商例程的（那份例程是 1.8" ST7735 的，尺寸都不一样）。
   每一个都在 lcd_selftest() 的画面里有对应的判据。
   ========================================================================== */

/* 列偏移。
   ⚠️ 推导：ST7789 显存是 **240 x 320**，而屏只有 280 行 —— 差 40 行，
      假设面板在显存里居中对齐 → 偏移 (320-280)/2 = **20**。
      竖屏（MV=0）时这 20 落在**行**上；转置横屏（MV=1）后，
      CASET 管的是原来那个"行"方向，所以偏移**跑到了 X 上**。 */
#define LCD_XOFF     20

/* 行偏移。转置后 Y 方向对应的是显存宽度 240 = 屏宽 240 → 必然 0。
   ⚠️ 如果点亮后发现**画面整体横向偏了约 20 像素**（一边缺一条、另一边多一条），
      说明转置方向跟我推的相反 —— **把 LCD_XOFF 和 LCD_YOFF 的值对调**就行。 */
#define LCD_YOFF     0

/* MADCTL(0x36) 扫描方向。位定义（ST7789V.pdf p215）：
     D7 MY  页地址序   D6 MX 列地址序   D5 MV 页列交换   D4 ML 行地址序
     D3 RGB/BGR 序     D2 MH 锁存序     D1/D0 保留

   **横屏必须先置 MV(0x20)**，再用 MX/MY 选四个方向之一：

     0x60  = MV|MX    ← 先用这个试（最常用的横屏值）
     0xA0  = MV|MY
     0xE0  = MV|MX|MY （= 0x60 转 180°）
     0x20  = MV
     以上任意一个再 |0x08 可修"红蓝对调"

   判据看自检画面里的**向上箭头**：
     · 箭头朝上 + "LANDSCAPE" 从左往右读 → 这个值对了 ✅
     · 箭头朝下                  → 换成 0x60 <-> 0xE0 里另一个
     · 箭头朝上但字是**反着读**的 → 镜像了，换 0x60 <-> 0xA0
     · 红蓝对调                  → 再 |0x08 */
#define LCD_MADCTL   0x60

/* 反显。1 = 发 0x21(INVON)。
   实测判据：看画面里那块白底黑字 —— 应该真的是"白底黑字"。
   如果整屏像"反色照片"（该白的发黑、该黑的发白）→ 改成 0（发 0x20 INVOFF）。
   ※ 这个值不同批次的屏不一样，ST7789 面板多数要 INVON。 */
#define LCD_INVON    1

/* ==========================================================================
   颜色：RGB565（高 5 位红 / 中 6 位绿 / 低 5 位蓝）
   ⚠️ 如果整体红蓝对调，**改上面的 LCD_MADCTL，不要改这里** ——
      颜色值是协议，MADCTL 才是"面板怎么接线"。
   ========================================================================== */
#define LCD_BLACK    0x0000
#define LCD_WHITE    0xFFFF
#define LCD_RED      0xF800
#define LCD_GREEN    0x07E0
#define LCD_BLUE     0x001F
#define LCD_YELLOW   0xFFE0
#define LCD_CYAN     0x07FF
#define LCD_MAGENTA  0xF81F
#define LCD_GRAY     0x8410
#define LCD_DARK     0x18E3

/* ---- 字库（BSP\lcdfont.h 的 ascii_1608）---- */
#define LCD_FONT_W   8
#define LCD_FONT_H   16

/* ---- API ----
   坐标一律是**屏幕坐标**，左上角 (0,0)。越界自动裁剪，不会写飞。 */
void bsp_lcd_init(void);                       /* 上电复位 + 初始化表 */
void bsp_lcd_fill(uint16_t color);             /* 全屏填色 */
void bsp_lcd_fill_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
/* Rounded glass rim; flat interior supports flicker-free text replacement. */
void bsp_lcd_panel(uint16_t x, uint16_t y, uint16_t w, uint16_t h,
                   uint16_t fill, uint16_t edge);
void bsp_lcd_char(uint16_t x, uint16_t y, char c, uint16_t fc, uint16_t bc);
void bsp_lcd_str (uint16_t x, uint16_t y, const char *s, uint16_t fc, uint16_t bc);
void bsp_lcd_text(uint16_t x, uint16_t y, const char *utf8, uint16_t fc, uint16_t bc);

#endif
