#include "bsp_led.h"

/* 蓝板板载 LED：PC13，**低电平点亮**。
   极性要是反了，只改这两个宏，别动函数的调用方。 */
#define LED_PORT  LED_GPIO_Port
#define LED_PIN   LED_Pin

void bsp_led_on(void)
{
	HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_RESET);   /* 低 = 亮 */
}

void bsp_led_off(void)
{
	HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_SET);     /* 高 = 灭 */
}

void bsp_led_toggle(void)
{
	HAL_GPIO_TogglePin(LED_PORT, LED_PIN);
}
