#ifndef  __BSP_LED_H
#define __BSP_LED_H
#include "main.h"

void bsp_led_on(void);
void bsp_led_off(void);
void bsp_led_toggle(void);

#endif
