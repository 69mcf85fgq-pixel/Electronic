#ifndef BSP_SPI_BUS_H
#define BSP_SPI_BUS_H
#include <stdint.h>
uint8_t bsp_spi_bus_init(void);
void bsp_spi_bus_lock(void);
void bsp_spi_bus_unlock(void);
#endif
