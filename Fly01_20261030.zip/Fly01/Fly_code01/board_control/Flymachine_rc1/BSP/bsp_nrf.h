#ifndef BSP_NRF_H
#define BSP_NRF_H
#include "main.h"

/* Si24R1 PTX; SPI1 is shared with the LCD through bsp_spi_bus. */
#define NRF_RADIO_CHANNEL 40U
#define NRF_SPI_TIMEOUT_MS 3U
#define NRF_CMD_R_REGISTER 0x00
#define NRF_CMD_W_REGISTER 0x20
#define NRF_CMD_R_RX_PL_WID 0x60
#define NRF_CMD_R_RX_PAYLOAD 0x61
#define NRF_CMD_W_TX_PAYLOAD 0xA0
#define NRF_CMD_FLUSH_TX 0xE1
#define NRF_CMD_FLUSH_RX 0xE2
#define NRF_REG_CONFIG 0x00
#define NRF_REG_EN_AA 0x01
#define NRF_REG_EN_RXADDR 0x02
#define NRF_REG_SETUP_AW 0x03
#define NRF_REG_SETUP_RETR 0x04
#define NRF_REG_RF_CH 0x05
#define NRF_REG_RF_SETUP 0x06
#define NRF_REG_STATUS 0x07
#define NRF_REG_RX_ADDR_P0 0x0A
#define NRF_REG_TX_ADDR 0x10
#define NRF_REG_RX_PW_P0 0x11
#define NRF_REG_FIFO_STATUS 0x17
#define NRF_REG_DYNPD 0x1C
#define NRF_REG_FEATURE 0x1D
#define NRF_FLAG_RX_DR 0x40
#define NRF_FLAG_TX_DS 0x20
#define NRF_FLAG_MAX_RT 0x10
#define NRF_FLAG_CLR_ALL 0x70
#define NRF_FIFO_RX_EMPTY 0x01
#define NRF_FIFO_TX_EMPTY 0x10

typedef struct {
    uint32_t spi_error;
    uint8_t reg, expected, actual, hal;
} nrf_error_t;

uint8_t bsp_nrf_init(void); /* Zero means complete configuration verified. */
void bsp_nrf_get_error(nrf_error_t *out);
uint8_t bsp_nrf_read_reg(uint8_t reg); /* FF on failed transfer. */
uint8_t bsp_nrf_write_reg(uint8_t reg, uint8_t value);
uint8_t bsp_nrf_flush_tx(void);
uint8_t bsp_nrf_send(const uint8_t *buf, uint8_t len); /* One if submitted, not ACKed. */
uint8_t bsp_nrf_read_ack_payload(uint8_t *buf, uint8_t capacity);
#endif
