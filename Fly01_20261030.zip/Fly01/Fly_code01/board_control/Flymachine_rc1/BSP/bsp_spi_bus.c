#include "bsp_spi_bus.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

static SemaphoreHandle_t spi_mutex;

uint8_t bsp_spi_bus_init(void)
{
    spi_mutex = xSemaphoreCreateMutex();
    return spi_mutex != NULL;
}

void bsp_spi_bus_lock(void)
{
    if (xTaskGetSchedulerState() == taskSCHEDULER_NOT_STARTED) return;
    configASSERT(spi_mutex != NULL);
    configASSERT(xSemaphoreTake(spi_mutex, portMAX_DELAY) == pdTRUE);
}

void bsp_spi_bus_unlock(void)
{
    if (xTaskGetSchedulerState() == taskSCHEDULER_NOT_STARTED) return;
    configASSERT(xSemaphoreGive(spi_mutex) == pdTRUE);
}
