#include "bsp_lcd.h"
#include "spi.h"
#include "lcdfont.h"      /* ascii_1608 —— ⚠️ 只在本文件 include（数组定义，不能多处包含） */
#include "hanzi_font.h"
#include "bsp_spi_bus.h"

/* ==========================================================================
   1.69" 240x280 ST7789V3 驱动
   寄存器全部核过《ST7789V.pdf》（317 页，Sitronix v1.0），改值前先翻手册。
   ==========================================================================

   ---- 为什么有那多"magic number"（0xB2/0xB7/0xBB/0xC0/0xE0/0xE1）----
   ST7789V 是**带片上电源系统**的驱动 IC：它自己用电荷泵生成 VGH(+13V)/
   VGL(-10V)/GVDD/VCOM 这些面板需要的电压。初始化表里那一堆值就是在调这套
   内部电源和 Gamma 曲线，属于"面板厂调好的参数" —— 厂商 BSP 里都长这样，
   照抄即可，**不要自己发挥**。真正需要你调的是 bsp_lcd.h 里那四个旋钮。

   ---- 一次像素刷新的流程（记住这个，以后加图形也这么写）----
     CASET(0x2A) 设列范围 → RASET(0x2B) 设行范围 → RAMWR(0x2C) → 灌像素
     像素是 16 位 RGB565，**高字节先发**。
   ========================================================================== */

/* ---- 底层三件套：命令 / 命令+数据 / 纯数据 ---------------------------------
   全部遵守"进出都把 CS 拉高"的铁律（见 .h 顶部）。 */

static void lcd_cs(uint8_t level)
{ 
    HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, level ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

/* 只发命令字节：DC=0 */
static void lcd_cmd(uint8_t c)
{
    lcd_cs(0);
    HAL_GPIO_WritePin(LCD_DC_GPIO_Port, LCD_DC_Pin, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &c, 1, 100);
    lcd_cs(1);
}

/* 命令 + N 个参数：**CS 全程拉低**，DC 在命令字节后翻高。
   比"每个字节一次 CS"少一半开销，也少一半出错机会。 */
static void lcd_cmd_n(uint8_t c, const uint8_t *d, uint16_t n)
{
    lcd_cs(0);
    HAL_GPIO_WritePin(LCD_DC_GPIO_Port, LCD_DC_Pin, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &c, 1, 100);

    if (n)
    {
        HAL_GPIO_WritePin(LCD_DC_GPIO_Port, LCD_DC_Pin, GPIO_PIN_SET);
        HAL_SPI_Transmit(&hspi1, (uint8_t *)d, n, 100);
    }
    lcd_cs(1);
}

/* 开一个矩形窗口，并进入"写显存"模式。
   之后连续灌 w*h 个像素即可，不用再发命令。
   ⚠️ 调用后需要**自己**保持 CS 低来灌数据，或者每次 lcd_dat() 自带 CS 翻转
      ——本文件用的是后者（每段数据一次 CS），ST7789 允许。 */
static void lcd_window(uint16_t x, uint16_t y, uint16_t w, uint16_t h)
{
    uint8_t p[4];

    /* CASET 0x2A：列起始/结束（含两端！所以是 x+w-1） */
    p[0] = (x + LCD_XOFF) >> 8;       p[1] = (x + LCD_XOFF) & 0xFF;
    p[2] = (x + LCD_XOFF + w - 1) >> 8; p[3] = (x + LCD_XOFF + w - 1) & 0xFF;
    lcd_cmd_n(0x2A, p, 4);

    /* RASET 0x2B：行起始/结束 */
    p[0] = (y + LCD_YOFF) >> 8;       p[1] = (y + LCD_YOFF) & 0xFF;
    p[2] = (y + LCD_YOFF + h - 1) >> 8; p[3] = (y + LCD_YOFF + h - 1) & 0xFF;
    lcd_cmd_n(0x2B, p, 4);

    /* RAMWR 0x2C：之后的数据都算像素 */
    lcd_cmd(0x2C);
}

/* ---- 像素流：开/灌/关 三段式 ----------------------------------------------
   为什么不是"灌一段就翻一次 CS"：
     ST7789 用 **DC 引脚**区分命令和数据，CS 只管选中。所以 CS 翻转期间只要
     DC 保持高，芯片就继续往显存里灌 —— 翻 CS 不会把数据误当命令。
     但一次开窗后连续灌几千字节，**整段只翻一次 CS** 更快、也更不容易出错。
   ⚠️ begin 和 end 必须配对，中间不能插命令，也不能 return 跑掉。 */
static void lcd_pix_begin(void)
{
    HAL_GPIO_WritePin(LCD_DC_GPIO_Port, LCD_DC_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_RESET);
}
static void lcd_pix_send(const uint8_t *buf, uint16_t nbytes)
{
    HAL_SPI_Transmit(&hspi1, (uint8_t *)buf, nbytes, 100);
}
static void lcd_pix_end(void)
{
    HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_SET);
}

/* ---- 初始化表 -------------------------------------------------------------
   dly = 发完这条命令后要等的毫秒数（0 = 不等） */
typedef struct { uint8_t cmd; uint8_t n; uint8_t dly; uint8_t dat[14]; } lcd_init_t;

static const lcd_init_t lcd_init_seq[] =
{
    /* 扫描方向先设，后面所有窗口都按它算 */
    { 0x36, 1,  0, { LCD_MADCTL } },

    /* 0x3A COLMOD：像素格式。0x05 = 16bit/像素（RGB565），控制接口也是 16bit */
    { 0x3A, 1,  0, { 0x05 } },

    /* ---- 以下属于"面板厂调好的参数"，照抄，别动 ---- */
    { 0xB2, 5,  0, { 0x0C,0x0C,0x00,0x33,0x33 } },   /* PORCTRL  前/后沿 */
    { 0xB7, 1,  0, { 0x35 } },                       /* GCTRL    VGH/VGL 电平 */
    { 0xBB, 1,  0, { 0x19 } },                       /* VCOMS    VCOM 电压 */
    { 0xC0, 1,  0, { 0x2C } },                       /* LCMCTRL  显示模式 */
    { 0xC2, 1,  0, { 0x01 } },                       /* VDVVRHEN 电压使能 */
    { 0xC3, 1,  0, { 0x12 } },                       /* VRHS     VRH 电压 */
    { 0xC4, 1,  0, { 0x20 } },                       /* VDVS     VDV 电压 */
    { 0xC6, 1,  0, { 0x0F } },                       /* FRCTRL2  60Hz 帧率 */
    { 0xD0, 2,  0, { 0xA4,0xA1 } },                  /* PWCTRL1  电源控制 */
    { 0xE0, 14, 0, { 0xD0,0x04,0x0D,0x11,0x13,0x2B,0x3F,0x54,
                     0x4C,0x18,0x0D,0x0B,0x1F,0x23 } },  /* +Gamma */
    { 0xE1, 14, 0, { 0xD0,0x04,0x0C,0x11,0x13,0x2C,0x3F,0x44,
                     0x51,0x2F,0x1F,0x1F,0x20,0x23 } },  /* -Gamma */

#if LCD_INVON
    { 0x21, 0,  0, { 0 } },                          /* INVON  反显开 */
#endif
    /* 0x11 SLPOUT：退出睡眠。**必须等 120ms** 内部电源才稳 */
    { 0x11, 0, 120, { 0 } },
    { 0x29, 0,  0, { 0 } },                          /* DISPON 开显示 */
};

/* ---- 行缓冲 ---------------------------------------------------------------
   ⚠️ 必须 static，不能放栈上：240*2 = 480 字节，
      Keil 默认栈只有 0x400(1KB)，栈上放这个再一嵌套就溢出。 */
static uint8_t s_line[LCD_W * 2];

static void lcd_row(uint16_t x, uint16_t y, uint16_t width)
{
    bsp_spi_bus_lock();
    lcd_window(x, y, width, 1);
    lcd_pix_begin();
    lcd_pix_send(s_line, width * 2);
    lcd_pix_end();
    bsp_spi_bus_unlock();
}

static uint16_t lcd_highlight(uint16_t color)
{
    /* One quarter white, separately in each RGB565 channel. No alpha buffer. */
    uint16_t r = (((color >> 11) & 31) * 3 + 31) / 4;
    uint16_t g = (((color >> 5) & 63) * 3 + 63) / 4;
    uint16_t b = ((color & 31) * 3 + 31) / 4;
    return (uint16_t)((r << 11) | (g << 5) | b);
}

/* ========================================================================== */
void bsp_lcd_init(void)
{
    /* ---- 硬件复位：RES 低 20ms → 高，再等 120ms ---- */
    HAL_GPIO_WritePin(LCD_RES_GPIO_Port, LCD_RES_Pin, GPIO_PIN_RESET);
    HAL_Delay(20);
    HAL_GPIO_WritePin(LCD_RES_GPIO_Port, LCD_RES_Pin, GPIO_PIN_SET);
    HAL_Delay(120);

    /* ---- 初始化表 ---- */
    for (uint32_t i = 0; i < sizeof(lcd_init_seq) / sizeof(lcd_init_seq[0]); i++)
    {
        lcd_cmd_n(lcd_init_seq[i].cmd, lcd_init_seq[i].dat, lcd_init_seq[i].n);
        if (lcd_init_seq[i].dly) HAL_Delay(lcd_init_seq[i].dly);
    }
}

void bsp_lcd_fill(uint16_t color)
{
    bsp_lcd_fill_rect(0, 0, LCD_W, LCD_H, color);
}

void bsp_lcd_fill_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color)
{
    /* 裁剪：越界的部分直接砍掉，不让它写到别的窗口里去 */
    if (x >= LCD_W || y >= LCD_H || w == 0 || h == 0) return;
    if (x + w > LCD_W) w = LCD_W - x;
    if (y + h > LCD_H) h = LCD_H - y;

    /* 先把一行像素拼进 buffer，后面重复发 h 次 —— 比逐像素拼快得多 */
    for (uint16_t i = 0; i < w; i++)
    {
        s_line[2 * i]     = color >> 8;
        s_line[2 * i + 1] = color & 0xFF;
    }

    /* Each row is a complete transaction (<=560 pixel bytes), allowing radio preemption. */
    for (uint16_t r = 0; r < h; r++)
        lcd_row(x, y + r, w);
}

void bsp_lcd_panel(uint16_t x, uint16_t y, uint16_t w, uint16_t h,
                   uint16_t fill, uint16_t edge)
{
    static const uint8_t corner[8] = {6, 4, 2, 1, 1, 0, 0, 0};
    uint16_t highlight = lcd_highlight(edge);
    if (x >= LCD_W || y >= LCD_H || !w || !h) return;
    if (w > LCD_W - x) w = LCD_W - x;
    if (h > LCD_H - y) h = LCD_H - y;
    if (w < 18 || h < 18) { bsp_lcd_fill_rect(x, y, w, h, fill); return; }

    /* Only a 560-byte shared row buffer. Corners leave the existing canvas intact. */
    for (uint16_t row = 0; row < h; row++) {
        uint16_t distance = row < h / 2 ? row : h - 1 - row;
        uint16_t inset = distance < 8 ? corner[distance] : 0;
        uint16_t inner = distance && distance <= 8 ? corner[distance - 1] + 1 : 1;
        uint16_t width = w - inset * 2;
        for (uint16_t i = 0; i < width; i++) {
            uint16_t column = i + inset;
            uint16_t color = (!distance || column < inner || column >= w - inner) ?
                             (row < h / 2 ? highlight : edge) : fill;
            s_line[i * 2] = (uint8_t)(color >> 8);
            s_line[i * 2 + 1] = (uint8_t)color;
        }
        lcd_row(x + inset, y + row, width);
    }
}

void bsp_lcd_char(uint16_t x, uint16_t y, char c, uint16_t fc, uint16_t bc)
{
    /* 字库只覆盖可打印 ASCII，其余一律当空格 —— 防止数组越界读飞 */
    if (c < ' ' || c > '~') c = ' ';

    const uint8_t *g = ascii_1608[(uint8_t)(c - ' ')];

    /* 出界直接丢，不做部分绘制（文字被切一半更难看，也不利于调试） */
    if (x + LCD_FONT_W > LCD_W || y + LCD_FONT_H > LCD_H) return;

    static uint8_t glyph[LCD_FONT_W * LCD_FONT_H * 2];

    for (uint8_t r = 0; r < LCD_FONT_H; r++)
    {
        uint8_t bits = g[r];
        for (uint8_t b = 0; b < LCD_FONT_W; b++)
        {
            /* ⚠️ **bit0 在最左**（LSB 在左），不是 MSB！
               这个字库（厂商 lcdfont.h 的 ascii_1608）是 LSB 在左的。
               判据：拿 'F' 'L' 'P' 'R' 这种强不对称字形渲染出来看 ——
               位序写反的话整屏文字会镜像，而图形完全正常，很难一眼定位。
               写成 (0x80 >> b) 就是镜像版，别改回去。 */
            uint16_t col = (bits & (1 << b)) ? fc : bc;
            uint16_t pos = 2 * (r * LCD_FONT_W + b);
            glyph[pos]     = col >> 8;
            glyph[pos + 1] = col & 0xFF;
        }
    }
    bsp_spi_bus_lock();
    lcd_window(x, y, LCD_FONT_W, LCD_FONT_H);
    lcd_pix_begin();
    lcd_pix_send(glyph, sizeof(glyph));
    lcd_pix_end();
    bsp_spi_bus_unlock();
}

void bsp_lcd_str(uint16_t x, uint16_t y, const char *s, uint16_t fc, uint16_t bc)
{
    while (*s)
    {
        bsp_lcd_char(x, y, *s, fc, bc);
        x += LCD_FONT_W;
        s++;
    }
}

static void lcd_hanzi(uint16_t x, uint16_t y, const hanzi_glyph_t *hanzi,
                      uint16_t fc, uint16_t bc)
{
    static uint8_t pixels[16 * 16 * 2];
    if (x + 16 > LCD_W || y + 16 > LCD_H) return;

    for (uint8_t row = 0; row < 16; row++)
    {
        for (uint8_t col = 0; col < 16; col++)
        {
            uint16_t color = (hanzi->rows[row] & (0x8000U >> col)) ? fc : bc;
            uint16_t pos = 2 * (row * 16 + col);
            pixels[pos] = color >> 8;
            pixels[pos + 1] = color & 0xFF;
        }
    }
    bsp_spi_bus_lock();
    lcd_window(x, y, 16, 16);
    lcd_pix_begin();
    lcd_pix_send(pixels, sizeof(pixels));
    lcd_pix_end();
    bsp_spi_bus_unlock();
}

void bsp_lcd_text(uint16_t x, uint16_t y, const char *utf8, uint16_t fc, uint16_t bc)
{
    const uint8_t *p = (const uint8_t *)utf8;
    while (*p && x < LCD_W)
    {
        if (*p < 0x80)
        {
            bsp_lcd_char(x, y, (char)*p++, fc, bc);
            x += 8;
        }
        else if ((p[0] & 0xF0) == 0xE0 &&
                 (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80)
        {
            uint16_t code = (uint16_t)(((p[0] & 0x0F) << 12) |
                                       ((p[1] & 0x3F) << 6) | (p[2] & 0x3F));
            p += 3;
            const hanzi_glyph_t *found = 0;
            for (uint32_t i = 0; i < HANZI_FONT_COUNT; i++)
            {
                if (hanzi_font[i].code == code) { found = &hanzi_font[i]; break; }
            }
            if (found) lcd_hanzi(x, y, found, fc, bc);
            else bsp_lcd_char(x + 4, y, '?', fc, bc);
            x += 16;
        }
        else
        {
            bsp_lcd_char(x, y, '?', fc, bc);
            p++;
            x += 8;
        }
    }
}
