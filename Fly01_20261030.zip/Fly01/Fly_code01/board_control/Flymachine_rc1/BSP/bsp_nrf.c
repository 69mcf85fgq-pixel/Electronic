#include "bsp_nrf.h"
#include "bsp_spi_bus.h"
#include "flight_link.h"
#include "spi.h"
#include <string.h>

static nrf_error_t last_error;

void bsp_nrf_get_error(nrf_error_t *out)
{
    if (out) *out = last_error;
}

static uint8_t transfer(uint8_t command, const uint8_t *data, uint8_t *out, uint8_t len)
{
    uint8_t tx[33], rx[33] = {0};
    HAL_StatusTypeDef result;
    if (len > 32U) return 0xFF;
    tx[0] = command;
    if (data) memcpy(tx + 1, data, len);
    else memset(tx + 1, 0xFF, len);
    /* LCD cannot insert bytes inside this CSN window. */
    bsp_spi_bus_lock();
    HAL_GPIO_WritePin(CSN_GPIO_Port, CSN_Pin, GPIO_PIN_RESET);
    result = HAL_SPI_TransmitReceive(&hspi1, tx, rx, len + 1U, NRF_SPI_TIMEOUT_MS);
    HAL_GPIO_WritePin(CSN_GPIO_Port, CSN_Pin, GPIO_PIN_SET);
    last_error.hal = (uint8_t)result;
    last_error.spi_error = hspi1.ErrorCode;
    bsp_spi_bus_unlock();
    if (result != HAL_OK || (rx[0] & 0x80U)) return 0xFF;
    if (out) memcpy(out, rx + 1, len);
    return rx[0];
}

uint8_t bsp_nrf_read_reg(uint8_t reg)
{
    uint8_t value = 0xFF;
    if (reg > NRF_REG_FEATURE) return 0xFF;
    transfer(NRF_CMD_R_REGISTER | reg, NULL, &value, 1);
    return value;
}

uint8_t bsp_nrf_write_reg(uint8_t reg, uint8_t value)
{
    if (reg > NRF_REG_FEATURE) return 0xFF;
    return transfer(NRF_CMD_W_REGISTER | reg, &value, NULL, 1);
}

static uint8_t write_verified(uint8_t reg, uint8_t value)
{
    last_error.reg = reg; last_error.expected = value; last_error.actual = 0xFF;
    if (bsp_nrf_write_reg(reg, value) == 0xFF) return 0;
    if (reg == NRF_REG_CONFIG && (value & 0x02U)) HAL_Delay(2);
    last_error.actual = bsp_nrf_read_reg(reg);
    return last_error.actual == value;
}

uint8_t bsp_nrf_init(void)
{
    static const uint8_t address[5] = {0xA1, 0xB2, 0xC3, 0xD4, 0xE5};
    static const uint8_t settings[][2] = {
        {NRF_REG_CONFIG, 0x0E}, /* Original PTX standby startup; CE remains low. */
        {NRF_REG_EN_AA, 0x01}, {NRF_REG_EN_RXADDR, 0x01},
        {NRF_REG_SETUP_AW, 0x03}, {NRF_REG_SETUP_RETR, 0x1A},
        {NRF_REG_RF_CH, NRF_RADIO_CHANNEL},
        {NRF_REG_RF_SETUP, 0x06}, /* Si24R1: 1 Mbps, +4 dBm. */
        {NRF_REG_RX_PW_P0, FL_TELEMETRY_LEN},
        {NRF_REG_FEATURE, 0x06}, {NRF_REG_DYNPD, 0x01}
    };
    static const uint8_t address_regs[] = {NRF_REG_RX_ADDR_P0, NRF_REG_TX_ADDR};
    memset(&last_error, 0, sizeof(last_error));
    HAL_GPIO_WritePin(CE_GPIO_Port, CE_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(CSN_GPIO_Port, CSN_Pin, GPIO_PIN_SET);
    /* Si24R1 figure 3-1: 100 ms after power-on, then 2 ms after PWR_UP. */
    HAL_Delay(100);
    for (uint8_t i = 0; i < sizeof(settings) / sizeof(settings[0]); i++)
        if (!write_verified(settings[i][0], settings[i][1])) return 1;
    for (uint8_t i = 0; i < sizeof(address_regs); i++) {
        uint8_t actual[5] = {0};
        last_error.reg = address_regs[i]; last_error.expected = address[0]; last_error.actual = 0xFF;
        if (transfer(NRF_CMD_W_REGISTER | address_regs[i], address, NULL, 5) == 0xFF ||
            transfer(NRF_CMD_R_REGISTER | address_regs[i], NULL, actual, 5) == 0xFF) return 1;
        for (uint8_t j = 0; j < sizeof(address); j++) {
            if (actual[j] != address[j]) {
                last_error.expected = address[j]; last_error.actual = actual[j];
                return 1;
            }
        }
    }
    /* Discard old commands and ACKs after an MCU-only reset. */
    last_error.reg = NRF_REG_FIFO_STATUS;
    last_error.expected = NRF_FIFO_TX_EMPTY | NRF_FIFO_RX_EMPTY; last_error.actual = 0xFF;
    if (bsp_nrf_flush_tx() == 0xFF || transfer(NRF_CMD_FLUSH_RX, NULL, NULL, 0) == 0xFF ||
        bsp_nrf_write_reg(NRF_REG_STATUS, NRF_FLAG_CLR_ALL) == 0xFF) return 1;
    last_error.actual = bsp_nrf_read_reg(NRF_REG_FIFO_STATUS);
    if (last_error.actual != last_error.expected) return 1;
    return 0;
}

uint8_t bsp_nrf_flush_tx(void)
{
    return transfer(NRF_CMD_FLUSH_TX, NULL, NULL, 0);
}

uint8_t bsp_nrf_send(const uint8_t *buf, uint8_t len)
{
    if (!buf || !len || len > 32) return 0;
    if (transfer(NRF_CMD_W_TX_PAYLOAD, buf, NULL, len) == 0xFF) return 0;
    HAL_GPIO_WritePin(CE_GPIO_Port, CE_Pin, GPIO_PIN_SET);
    /* At least 10 us, independent of compiler optimization; no SPI lock held. */
    HAL_Delay(1);
    HAL_GPIO_WritePin(CE_GPIO_Port, CE_Pin, GPIO_PIN_RESET);
    return 1;
}

uint8_t bsp_nrf_read_ack_payload(uint8_t *buf, uint8_t capacity)
{
    uint8_t width = 0;
    if (!buf || !capacity) return 0;
    if (transfer(NRF_CMD_R_RX_PL_WID, NULL, &width, 1) == 0xFF) return 0;
    if (!width || width > 32 || width > capacity) {
        transfer(NRF_CMD_FLUSH_RX, NULL, NULL, 0);
        return 0;
    }
    return transfer(NRF_CMD_R_RX_PAYLOAD, NULL, buf, width) == 0xFF ? 0 : width;
}
