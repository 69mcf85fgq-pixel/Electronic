#include "bsp_nrf.h"
#include "spi.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

SPI_HandleTypeDef hspi1;
static unsigned locked, selected, ce_high;
void bsp_spi_bus_lock(void) { assert(!locked); locked = 1; }
void bsp_spi_bus_unlock(void) { assert(locked && !selected); locked = 0; }
uint32_t HAL_GetTick(void) { return 100; }
void HAL_Delay(uint32_t ms) { (void)ms; }
void HAL_GPIO_WritePin(void *port, uint16_t pin, GPIO_PinState value)
{
    (void)port;
    if (pin == CSN_Pin) selected = !value;
    if (pin == CE_Pin && value) ce_high++;
}
int HAL_SPI_TransmitReceive(SPI_HandleTypeDef *spi, uint8_t *tx, uint8_t *rx,
                            uint16_t size, uint32_t timeout)
{
    (void)tx; (void)timeout;
    assert(locked && selected);
    spi->ErrorCode = 0x20;
    memset(rx, 0x55, size);
    return 3; /* HAL_TIMEOUT after writing a partial receive buffer. */
}
int HAL_SPI_Transmit(SPI_HandleTypeDef *spi, uint8_t *tx, uint16_t size, uint32_t timeout)
{ (void)spi; (void)tx; (void)size; (void)timeout; return 3; }
int main(int argc, char **argv)
{
    uint8_t packet[18] = {0};
    if (argc > 1 && !strcmp(argv[1], "send")) {
        bsp_nrf_send(packet, sizeof(packet));
        assert(!ce_high);
    } else assert(bsp_nrf_read_reg(NRF_REG_CONFIG) == 0xFF);
    assert(!locked && !selected);
    puts("PASS: failed SPI read is invalid; failed payload never triggers CE; bus released");
    return 0;
}
