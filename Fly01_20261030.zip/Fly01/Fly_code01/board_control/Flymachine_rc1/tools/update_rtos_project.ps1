$ErrorActionPreference = 'Stop'
$projectPath = Join-Path $PSScriptRoot '../MDK-ARM/Flymachine_rc1.uvprojx'
$project = New-Object System.Xml.XmlDocument
$project.PreserveWhitespace = $false
$project.Load($projectPath)
$target = $project.SelectSingleNode('/Project/Targets/Target')
$includes = $target.SelectSingleNode('TargetOption/TargetArmAds/Cads/VariousControls/IncludePath')
foreach ($path in @('../Middlewares/FreeRTOS/include', '../Middlewares/FreeRTOS/portable/RVDS/ARM_CM3')) {
    if ($includes.InnerText.Split(';') -notcontains $path) { $includes.InnerText += ';' + $path }
}
$groups = $target.SelectSingleNode('Groups')
function Add-ProjectFile([string]$groupName, [string]$filePath) {
    $group = $groups.SelectSingleNode("Group[GroupName='$groupName']")
    if (!$group) {
        $group = $project.CreateElement('Group')
        $name = $project.CreateElement('GroupName')
        $name.InnerText = $groupName
        [void]$group.AppendChild($name)
        [void]$group.AppendChild($project.CreateElement('Files'))
        [void]$groups.AppendChild($group)
    }
    $files = $group.SelectSingleNode('Files')
    if ($files.SelectNodes('File') | Where-Object { $_.FilePath.Replace('\', '/') -eq $filePath }) { return }
    $file = $project.CreateElement('File')
    foreach ($field in @('FileName', 'FileType', 'FilePath')) {
        $node = $project.CreateElement($field)
        $node.InnerText = switch ($field) {
            'FileName' { [System.IO.Path]::GetFileName($filePath) }
            'FileType' { '1' }
            'FilePath' { $filePath }
        }
        [void]$file.AppendChild($node)
    }
    [void]$files.AppendChild($file)
}
foreach ($file in @('rc_control.c', 'rc_runtime.c', 'rc_ui.c')) { Add-ProjectFile 'Application/User' ('../Src/' + $file) }
foreach ($file in @('flight_link.c', 'bsp_spi_bus.c')) { Add-ProjectFile 'BSP' ('../BSP/' + $file) }
foreach ($file in @('tasks.c', 'queue.c', 'list.c', 'portable/RVDS/ARM_CM3/port.c', 'portable/MemMang/heap_4.c')) {
    Add-ProjectFile 'FreeRTOS' ('../Middlewares/FreeRTOS/' + $file)
}
$target.SelectSingleNode('TargetOption/TargetArmAds/ArmAdsMisc/OnChipMemories/OCR_RVCT4/Size').InnerText = '0xF800'
if ($target.SelectSingleNode('TargetOption/TargetArmAds/Cads/uC99').InnerText -ne '1' -or
    $target.SelectSingleNode('uAC6').InnerText -ne '0') { throw 'Expected original C99 ARMCC5 settings' }
$settings = New-Object System.Xml.XmlWriterSettings
$settings.Encoding = New-Object System.Text.UTF8Encoding($false)
$settings.Indent = $true
$writer = [System.Xml.XmlWriter]::Create($projectPath, $settings)
try { $project.Save($writer) } finally { $writer.Dispose() }
Write-Output 'Updated RC project using XML parser: FreeRTOS RVDS/ARM_CM3 + heap_4, C99 ARMCC5, FLASH 0xF800'
