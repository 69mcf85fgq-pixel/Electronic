#include "bsp_nrf.h"
#include "flight_link.h"
#include "spi.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

SPI_HandleTypeDef hspi1;
static uint8_t regs[32], addresses[2][5], sent[32], width;
static unsigned locked, selected, ce, pulses, calls, windows, tx_queued, rx_queued;
static unsigned fail_call, fail_status, bad_reg, bad_byte, all_zero, bad_status, bad_flush;
static uint32_t tick, powered_at, pulse_tick;

uint32_t HAL_GetTick(void) { return tick; }
void HAL_Delay(uint32_t ms) { assert(!locked); tick += ms; }
void bsp_spi_bus_lock(void) { assert(!locked && !selected); locked = 1; }
void bsp_spi_bus_unlock(void) { assert(locked && !selected); locked = 0; }
void HAL_GPIO_WritePin(void *port, uint16_t pin, GPIO_PinState value)
{
    (void)port;
    if (pin == CSN_Pin) {
        if (!value) { assert(locked && !selected); windows++; }
        selected = !value;
    }
    if (pin == CE_Pin) {
        assert(!locked);
        if (value) { assert(!ce && tx_queued); pulses++; pulse_tick = tick; }
        else if (ce) { assert(tick - pulse_tick >= 1); tx_queued = 0; }
        ce = value;
    }
}
int HAL_SPI_TransmitReceive(SPI_HandleTypeDef *spi, uint8_t *tx, uint8_t *rx,
                            uint16_t size, uint32_t timeout)
{
    uint8_t cmd = tx[0];
    assert(locked && selected && size >= 1 && size <= 33 && tick >= 100);
    assert(timeout == NRF_SPI_TIMEOUT_MS);
    calls++; spi->ErrorCode = 0;
    if (calls == fail_call) {
        spi->ErrorCode = 0x20; memset(rx, 0x55, size); return (int)fail_status;
    }
    memset(rx, 0, size);
    rx[0] = bad_status ? 0xFF : 0x0E;
    if (all_zero) return HAL_OK;
    if ((cmd & 0xE0) == NRF_CMD_W_REGISTER) {
        uint8_t reg = cmd & 31;
        assert(!ce);
        if (reg == NRF_REG_CONFIG) assert(tx[1] == 0x0E);
        if (reg == NRF_REG_RX_ADDR_P0 || reg == NRF_REG_TX_ADDR) {
            assert(size == 6); memcpy(addresses[reg == NRF_REG_TX_ADDR], tx + 1, 5);
        } else {
            assert(size == 2);
            regs[reg] = reg == NRF_REG_STATUS ? regs[reg] & ~tx[1] : tx[1];
            if (reg == NRF_REG_CONFIG && (tx[1] & 2)) powered_at = tick;
        }
    } else if (cmd <= NRF_REG_FEATURE) {
        if (cmd == NRF_REG_CONFIG) assert(tick - powered_at >= 2);
        for (unsigned i = 1; i < size; i++) assert(tx[i] == 0xFF);
        if (cmd == NRF_REG_RX_ADDR_P0 || cmd == NRF_REG_TX_ADDR) {
            assert(size == 6); memcpy(rx + 1, addresses[cmd == NRF_REG_TX_ADDR], 5);
            if (bad_reg == cmd && bad_byte < 5) rx[1 + bad_byte] ^= 1;
        } else {
            assert(size == 2);
            rx[1] = cmd == NRF_REG_FIFO_STATUS ? (tx_queued ? 0 : 0x10) | (rx_queued ? 0 : 1) : regs[cmd];
            if (bad_reg == cmd) rx[1] ^= 1;
        }
    } else if (cmd == NRF_CMD_FLUSH_TX) {
        assert(size == 1 && !ce); if (!bad_flush) tx_queued = 0;
    } else if (cmd == NRF_CMD_FLUSH_RX) {
        assert(size == 1 && !ce); rx_queued = 0;
    } else if (cmd == NRF_CMD_W_TX_PAYLOAD) {
        assert(!ce && !tx_queued && size >= 2);
        memcpy(sent, tx + 1, size - 1); tx_queued = 1;
    } else if (cmd == NRF_CMD_R_RX_PL_WID) {
        assert(size == 2 && tx[1] == 0xFF); rx[1] = width;
    } else if (cmd == NRF_CMD_R_RX_PAYLOAD) {
        assert(size == width + 1U);
        for (unsigned i = 1; i < size; i++) { assert(tx[i] == 0xFF); rx[i] = (uint8_t)(i - 1); }
        rx_queued = 0;
    } else assert(0);
    return HAL_OK;
}
int HAL_SPI_Transmit(SPI_HandleTypeDef *spi, uint8_t *tx, uint16_t size, uint32_t timeout)
{ (void)spi; (void)tx; (void)size; (void)timeout; assert(0); return 1; }

static void reset(void)
{
    memset(regs, 0xA5, sizeof(regs)); memset(addresses, 0, sizeof(addresses));
    regs[NRF_REG_STATUS] = 0x70;
    locked = selected = ce = pulses = calls = windows = fail_call = all_zero = bad_status = bad_flush = 0;
    tick = powered_at = pulse_tick = 0;
    tx_queued = rx_queued = 3; bad_reg = bad_byte = 255; fail_status = 3; width = 32;
}
static void init_cases(void)
{
    const uint8_t wanted[] = {0xA1,0xB2,0xC3,0xD4,0xE5};
    const uint8_t verify[][2] = {{0,0x0E},{1,1},{2,1},{3,3},{4,0x1A},{5,40},{6,6},{0x11,32},{0x1C,1},{0x1D,6}};
    unsigned init_calls;
    nrf_error_t error;
    reset(); assert(!bsp_nrf_init()); init_calls = calls;
    assert(tick >= 102 && tick - powered_at >= 2 && !ce && !pulses && !locked && !selected);
    for (unsigned i = 0; i < sizeof(verify) / sizeof(verify[0]); i++) assert(regs[verify[i][0]] == verify[i][1]);
    assert(!memcmp(addresses[0], wanted, 5) && !memcmp(addresses[1], wanted, 5));
    assert(!tx_queued && !rx_queued && !(regs[NRF_REG_STATUS] & 0x70) && calls == windows);
    tx_queued = rx_queued = 3;
    assert(!bsp_nrf_init() && !tx_queued && !rx_queued);
    for (unsigned status = 1; status <= 3; status++) {
        for (unsigned i = 1; i <= init_calls; i++) {
            reset(); fail_call = i; fail_status = status;
            assert(bsp_nrf_init() && calls == i && !ce && !pulses && !locked && !selected);
            bsp_nrf_get_error(&error); assert(error.hal == status && error.spi_error == 0x20);
        }
    }
    for (unsigned i = 0; i < sizeof(verify) / sizeof(verify[0]); i++) {
        reset(); bad_reg = verify[i][0]; assert(bsp_nrf_init());
    }
    for (unsigned reg = 0; reg < 2; reg++) for (unsigned byte = 0; byte < 5; byte++) {
        reset(); bad_reg = reg ? NRF_REG_TX_ADDR : NRF_REG_RX_ADDR_P0; bad_byte = byte;
        assert(bsp_nrf_init());
    }
    reset(); all_zero = 1; assert(bsp_nrf_init());
    reset(); bad_status = 1; assert(bsp_nrf_init());
    reset(); bad_flush = 1; assert(bsp_nrf_init());
    puts("PASS: RC cold/warm startup, full config and both addresses, FIFO reset, every init SPI error, all-zero/FF");
}
static void payload_cases(void)
{
    uint8_t packet[32], payload[32];
    reset(); assert(!bsp_nrf_init()); memset(packet, 0xC3, sizeof(packet));
    for (unsigned len = 1; len <= 32; len++) {
        assert(bsp_nrf_send(packet, (uint8_t)len));
        assert(!memcmp(sent, packet, len) && !ce && !locked && !selected);
        width = (uint8_t)len; rx_queued = 1;
        assert(bsp_nrf_read_ack_payload(payload, sizeof(payload)) == len);
        for (unsigned i = 0; i < len; i++) assert(payload[i] == i);
    }
    unsigned before = pulses;
    assert(!bsp_nrf_send(NULL, 18) && !bsp_nrf_send(packet, 0) && !bsp_nrf_send(packet, 33));
    fail_call = calls + 1;
    assert(!bsp_nrf_send(packet, 18) && pulses == before && !ce && !locked && !selected);
    fail_call = 0;
    for (unsigned part = 1; part <= 2; part++) {
        width = 32; memset(payload, 0xAA, sizeof(payload)); fail_call = calls + part;
        assert(!bsp_nrf_read_ack_payload(payload, sizeof(payload)));
        for (unsigned i = 0; i < sizeof(payload); i++) assert(payload[i] == 0xAA);
        assert(!locked && !selected); fail_call = 0;
    }
    width = 33; rx_queued = 1; assert(!bsp_nrf_read_ack_payload(payload, 32) && !rx_queued);
    width = 0; assert(!bsp_nrf_read_ack_payload(payload, 32));
    width = 32; assert(!bsp_nrf_read_ack_payload(payload, 18));
    assert(!bsp_nrf_read_ack_payload(NULL, 32));
    puts("PASS: RC payload 1..32, failed send has no CE pulse, failed read has no partial data, mutex/CSN cleanup");
}
int main(void) { init_cases(); payload_cases(); return 0; }
