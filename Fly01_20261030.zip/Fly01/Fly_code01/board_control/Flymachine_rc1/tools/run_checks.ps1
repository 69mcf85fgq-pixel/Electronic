param([string]$Compiler = 'D:\MinGWDownload\bin\gcc.exe')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$env:PATH = (Split-Path -Parent $Compiler) + ';' + $env:PATH
Push-Location $root
try {
    & $Compiler -std=c99 -Wall -Wextra -Werror -I tools/preview -I Inc -I BSP tools/test_startup.c -o tools/test_startup.exe
    if ($LASTEXITCODE -ne 0) { throw 'RC startup compilation failed' }
    & ./tools/test_startup.exe
    if ($LASTEXITCODE -ne 0) { throw 'RC startup assertions failed' }
    & $Compiler -std=c99 -Wall -Wextra -Werror -I Inc -I BSP tools/test_rc_control.c Src/rc_control.c BSP/flight_link.c -o tools/test_rc_control.exe
    if ($LASTEXITCODE -ne 0) { throw 'RC control compilation failed' }
    & ./tools/test_rc_control.exe
    if ($LASTEXITCODE -ne 0) { throw 'RC control assertions failed' }
    & $Compiler -std=c99 -Wall -Wextra -Werror -I tools/runtime_mock -I Inc -I BSP tools/test_rc_runtime.c Src/rc_control.c BSP/flight_link.c -o tools/test_rc_runtime.exe
    if ($LASTEXITCODE -ne 0) { throw 'RC runtime compilation failed' }
    & ./tools/test_rc_runtime.exe
    if ($LASTEXITCODE -ne 0) { throw 'RC runtime assertions failed' }
    foreach ($test in @('nrf','nrf_failure')) {
        & $Compiler -std=c99 -Wall -Wextra -Werror -I tools/preview -I BSP "tools/test_$test.c" BSP/bsp_nrf.c -o "tools/test_$test.exe"
        if ($LASTEXITCODE -ne 0) { throw "$test compilation failed" }
        & "./tools/test_$test.exe"
        if ($LASTEXITCODE -ne 0) { throw "$test assertions failed" }
    }
    & ./tools/test_nrf_failure.exe send
    if ($LASTEXITCODE -ne 0) { throw 'Failed send must not trigger CE' }
    & $Compiler -std=c99 -Wall -Wextra -Werror -Wno-unused-function -DRC_UI_PREVIEW -I tools/preview -I Inc -I BSP tools/preview/preview.c Src/rc_ui.c Src/rc_control.c BSP/flight_link.c BSP/bsp_lcd.c BSP/bsp_nrf.c -o tools/preview/rc_preview.exe
    if ($LASTEXITCODE -ne 0) { throw 'RC raster compilation failed' }
    & ./tools/preview/rc_preview.exe
    if ($LASTEXITCODE -ne 0) { throw 'RC SPI/raster assertions failed' }
    & python tools/preview/convert.py
    if ($LASTEXITCODE -ne 0) { throw 'RC preview conversion failed' }
    & python tools/preview/verify.py
    if ($LASTEXITCODE -ne 0) { throw 'RC preview pixel checks failed' }
    $base = Split-Path -Parent (Split-Path -Parent $root)
    $fc = Join-Path $base 'board1\Flymachine_code1'
    foreach ($file in @('flight_link.c','flight_link.h')) {
        if ((Get-FileHash "$root\BSP\$file").Hash -ne (Get-FileHash "$fc\BSP\$file").Hash) {
            throw "Remote/aircraft protocol differs: $file"
        }
    }
    Write-Output 'PASS: remote and aircraft protocol sources are byte-identical'
} finally { Pop-Location }
