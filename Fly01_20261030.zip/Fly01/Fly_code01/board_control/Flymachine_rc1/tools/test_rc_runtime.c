#include "runtime.h"
#include <stdlib.h>
#include <setjmp.h>
#include <string.h>
void HAL_Delay(uint32_t ms);
#include "../Src/rc_runtime.c"

UART_HandleTypeDef huart1;
volatile uint16_t adc_raw[5] = {2045,2047,2048,2065,2000};
unsigned critical_depth;
enum { NORMAL, STATUS_FF, SEND_FAIL, CLEAR_FAIL, FLUSH_FAIL, BAD_ACK, DELAYED, HELD, HOME,
       RADIO_FAILED, LOST_RX_IRQ, FIFO_FAILED, RETURN_GONE, AIR_GONE, SPI_GONE, IMU_STOP,
       TILT_STOP, ACK_BAD, ACK_OLD };
static unsigned key_test_mask;
static unsigned scenario, round_index, rounds, sends, attempts, clears, flushes, ack_used, ack_reads;
static unsigned active, init_fail, created, full_queue;
static uint32_t tick;
static jmp_buf done;
static char serial[2048];
static unsigned serial_size;
static unsigned init_calls, init_transient, init_delay_ms;

uint32_t HAL_GetTick(void) { return tick; }
void HAL_Delay(uint32_t ms)
{
    assert(!active && !critical_depth && ms == 50);
    init_delay_ms += ms; tick += ms;
}
unsigned HAL_GPIO_ReadPin(unsigned port, unsigned pin)
{ (void)port; return !((key_test_mask & pin) || (scenario == HOME && round_index == 3 && pin == GPIO_PIN_9)); }
int HAL_UART_Transmit(UART_HandleTypeDef *uart, uint8_t *data, uint16_t size, uint32_t timeout)
{
    (void)uart; (void)timeout;
    assert(!active && !critical_depth && serial_size + size < sizeof(serial));
    memcpy(serial + serial_size, data, size); serial_size += size; serial[serial_size] = 0;
    return 0;
}
int xTaskGetSchedulerState(void) { return active; }
TickType_t xTaskGetTickCount(void) { return tick; }
int xTaskDelayUntil(TickType_t *wake, TickType_t period)
{
    assert(active && !critical_depth && period == 20);
    if (scenario == STATUS_FF) assert(!shared.link_has_result && !shared.last_ack_tick);
    if (scenario == HELD || scenario == LOST_RX_IRQ)
        assert(shared.flight.session && shared.flight.command.axes[3] > 600);
    if (scenario == HOME && round_index == 3) assert(shared.flight.command.flags == FL_KILL);
    ack_used = 0;
    if (++round_index == rounds) longjmp(done, 1);
    if (scenario == DELAYED && round_index == 2) { tick += 80; return pdFALSE; }
    *wake += period; tick = *wake;
    return pdPASS;
}
void vTaskDelay(TickType_t period)
{ assert(active && scenario == DELAYED && period == 1 && !critical_depth); tick += period; }
unsigned uxTaskGetStackHighWaterMark(TaskHandle_t h) { (void)h; return 256; }
QueueHandle_t xQueueCreate(unsigned count, unsigned size)
{ assert(count == 16 && size == 1); return &tick; }
int xQueueReceive(QueueHandle_t q, void *out, TickType_t wait)
{ (void)q; (void)out; (void)wait; return 0; }
int xQueueSend(QueueHandle_t q, const void *in, TickType_t wait)
{ (void)q; (void)in; (void)wait; return !full_queue; }
int xTaskCreate(void (*fn)(void *), const char *name, unsigned stack, void *arg, unsigned priority, TaskHandle_t *h)
{
    (void)arg; (void)h;
    assert(!strcmp(name, created ? "rc-ui" : "rc-radio"));
    assert(fn == (created ? rc_ui_task : rc_radio_task));
    assert(stack == (created ? 768U : 512U) && priority == (created ? 1U : 3U));
    created++; return pdPASS;
}
void vTaskStartScheduler(void) { assert(created == 2); longjmp(done, 1); }
void Error_Handler(void) { abort(); }
void rc_ui_task(void *arg) { (void)arg; }
uint8_t bsp_spi_bus_init(void) { return 1; }
uint8_t bsp_nrf_init(void) { init_calls++; return init_fail || init_calls <= init_transient; }
void bsp_nrf_get_error(nrf_error_t *out)
{ memset(out, 0, sizeof(*out)); out->reg = NRF_REG_CONFIG; out->expected = 0x0E; out->actual = 0xFF; }
uint8_t bsp_nrf_write_reg(uint8_t reg, uint8_t value)
{
    assert(active && reg == NRF_REG_STATUS && value == NRF_FLAG_CLR_ALL && !critical_depth);
    clears++; return scenario == CLEAR_FAIL ? 0xFF : 0x0E;
}
uint8_t bsp_nrf_flush_tx(void)
{ assert(active && !critical_depth); flushes++; return scenario == FLUSH_FAIL ? 0xFF : 0x0E; }
uint8_t bsp_nrf_read_reg(uint8_t reg)
{
    assert(active && !critical_depth);
    assert(scenario != RADIO_FAILED);
    if (reg == NRF_REG_STATUS) {
        if (scenario == STATUS_FF) return 0xFF;
        if (scenario == SPI_GONE && round_index > 2 && round_index < 65) return 0xFF;
        if (scenario == AIR_GONE && round_index > 2 && round_index < 65) return 0x1E;
        if (scenario == RETURN_GONE && round_index > 2 && round_index < 65) return 0x2E;
        /* ACK is queued after the STATUS snapshot, but its RX_DR notification was cleared. */
        return round_index ? (scenario == LOST_RX_IRQ ? 0x2E : 0x6E) : 0x0E;
    }
    assert(reg == NRF_REG_FIFO_STATUS);
    if (scenario == FIFO_FAILED) return 0xFF;
    if ((scenario == RETURN_GONE || scenario == AIR_GONE || scenario == SPI_GONE) &&
        round_index > 2 && round_index < 65) return NRF_FIFO_RX_EMPTY;
    return !round_index || ack_used ? NRF_FIFO_RX_EMPTY : 0;
}
uint8_t bsp_nrf_read_ack_payload(uint8_t *data, uint8_t capacity)
{
    fl_telemetry_t t = {0};
    assert(!ack_used && capacity == FL_TELEMETRY_LEN);
    ack_used = 1; ack_reads++;
    t.flags = FL_IMU_OK | FL_GEOMETRY_OK;
    t.control_seq = shared.flight.command.seq;
    t.param_value = fl_param_default(FL_RATE_P);
    if (scenario == HELD || scenario == HOME || scenario == LOST_RX_IRQ) {
        t.flags |= FL_ARMED; t.state = FL_MANUAL;
    }
    if (scenario >= RETURN_GONE) { t.flags |= FL_ARMED; t.state = FL_MANUAL; t.imu_id = 0x68; }
    if ((scenario == IMU_STOP || scenario == TILT_STOP) && round_index == 3) {
        t.flags &= (uint8_t)~FL_ARMED; t.state = FL_FAULT;
        t.fault = scenario == IMU_STOP ? FL_IMU_FAULT : FL_TILT_FAULT;
        if (scenario == IMU_STOP) t.flags &= (uint8_t)~FL_IMU_OK;
    }
    if (scenario == ACK_BAD && round_index > 2 && round_index < 65) return 0;
    if (scenario == ACK_OLD && round_index > 2 && round_index < 65) t.control_seq = 2;
    if (scenario == BAD_ACK && round_index < 4) {
        if (round_index == 1) return 0;
        fl_encode_telemetry(data, &t);
        if (round_index == 2) return 31;
        data[0] = 0; return 32;
    }
    if (scenario == BAD_ACK) t.control_seq = 4; /* Only the first echo is new. */
    fl_encode_telemetry(data, &t);
    return FL_TELEMETRY_LEN;
}
uint8_t bsp_nrf_send(const uint8_t *data, uint8_t size)
{
    fl_control_t c;
    assert(active && !critical_depth && size == FL_CONTROL_LEN && fl_decode_control(&c, data, size));
    assert(c.seq == (uint8_t)(round_index + 1));
    if (scenario == LOST_RX_IRQ && c.flags != FL_ARM)
        fprintf(stderr, "R1 REPRO: t=%lu rx=%lu reads=%u reason=%u, valid ACK FIFO with RX_DR cleared\n",
                (unsigned long)tick, (unsigned long)shared.rx_count, ack_reads, shared.flight.stop_reason);
    if (scenario == HELD || scenario == LOST_RX_IRQ || (scenario == HOME && round_index < 3))
        assert(c.flags == FL_ARM);
    else if (scenario < RETURN_GONE) assert(c.flags == FL_KILL);
    attempts++;
    if (scenario == SEND_FAIL) return 0;
    sends++; return 1;
}
static void reset(unsigned which)
{
    memset(&shared, 0, sizeof(shared));
    tick = 100; scenario = which; rounds = 60;
    round_index = sends = attempts = clears = flushes = ack_used = ack_reads = 0;
    serial_size = active = init_fail = created = full_queue = manual_focus = 0;
    init_calls = init_transient = init_delay_ms = 0;
    adc_raw[3] = 2065;
    init_fail = which == RADIO_FAILED;
    assert(rc_runtime_init() == !init_fail);
    assert(strstr(serial, init_fail ? "RC NORMAL v3 RADIO=0" : "RC NORMAL v3 RADIO=1 channel=40"));
    assert(init_calls == (init_fail ? 3U : 1U) && init_delay_ms == (init_fail ? 100U : 0U));
    if (init_fail) assert(strstr(serial, "RADIO BOOT tries=3"));
}
static void run(unsigned which)
{
    reset(which);
    if (which == HELD || which == HOME || which == LOST_RX_IRQ || which >= RETURN_GONE) {
        shared.flight.session = shared.flight.seen_armed = 1;
        shared.flight.received = 1; shared.flight.telemetry_tick = tick;
        shared.flight.telemetry.flags = FL_IMU_OK | FL_GEOMETRY_OK | FL_ARMED;
        shared.flight.telemetry.state = FL_MANUAL;
        shared.flight.command.flags = FL_ARM;
        adc_raw[3] = 3500;
        rounds = which == HOME ? 12 : which >= RETURN_GONE ? 80 : 320;
        full_queue = 1;
    }
    active = 1;
    if (!setjmp(done)) rc_radio_task(NULL);
    active = 0;
    assert(!critical_depth && shared.tx_count == sends && rc_radio_stack_free_words == 256);
    if (which == NORMAL || which == DELAYED) {
        assert(sends == rounds && shared.rx_count == rounds - 1);
        assert(shared.link_percent == 100 && shared.link_has_result && shared.link_rate_ready);
        assert(shared.missed_periods == (which == DELAYED ? 1U : 0U));
    }
    if (which == STATUS_FF) assert(!sends && !ack_reads && !clears && !flushes && !shared.rx_count);
    if (which == RADIO_FAILED) {
        assert(!sends && !attempts && !ack_reads && !clears && !flushes && !shared.rx_count);
        assert(shared.battery_raw == 2000 && !shared.flight.session && shared.flight.command.flags == FL_KILL);
    }
    if (which == SEND_FAIL || which == CLEAR_FAIL || which == FLUSH_FAIL) {
        assert(!sends && !shared.rx_count && !shared.last_ack_tick && shared.link_percent == 0);
        if (which == CLEAR_FAIL) assert(!flushes && !attempts);
        if (which == FLUSH_FAIL) assert(!attempts);
    }
    if (which == BAD_ACK) assert(shared.rx_count == 1);
    if (which == HELD) assert(sends == 320 && shared.flight.session);
    if (which == LOST_RX_IRQ) assert(shared.rx_count == rounds - 1 && ack_reads == rounds - 1);
    if (which == FIFO_FAILED) assert(!ack_reads && !shared.rx_count);
    if (which == HOME) assert(!shared.flight.session && shared.flight.command.flags == FL_KILL);
    if (which >= RETURN_GONE) {
        const rc_stop_diag_t *d = &shared.stop_diag;
        assert(d->number == 1 && !shared.flight.session && d->received);
        assert(d->last.imu_id == 0x68);
        if (which == IMU_STOP || which == TILT_STOP) {
            assert(d->reason == RC_STOP_FC_FAULT);
            assert(d->fault == (which == IMU_STOP ? FL_IMU_FAULT : FL_TILT_FAULT));
            assert(d->last.fault == d->fault && !d->telemetry_age_ms);
        } else {
            assert(d->reason == RC_STOP_TELEMETRY && d->telemetry_age_ms == RC_FLIGHT_TELEMETRY_MS);
            assert(d->last.flags & FL_IMU_OK); /* Last known, never evidence about the outage. */
            assert(!d->last.fault);
            if (which == RETURN_GONE) assert(d->link.ack && !d->link.retry && !d->link.spi_bad && !d->link.reads);
            if (which == AIR_GONE) assert(!d->link.ack && d->link.retry && !d->link.spi_bad);
            if (which == SPI_GONE) assert(d->link.spi_bad && !d->link.ack);
            if (which == ACK_BAD) assert(d->link.ack && d->link.bad);
            if (which == ACK_OLD) assert(d->link.ack && d->link.old);
        }
        assert(shared.flight.telemetry_tick > d->tick); /* Later recovery must not overwrite the event. */
        serial_size = 0;
        rc_runtime_log_stop(d);
        assert(strstr(serial, "RC STOP") && strstr(serial, "RC LINK") && strstr(serial, "RC LAST"));
        assert(strstr(serial, "aircraft_during_outage=UNKNOWN"));
    }
}
int main(void)
{
    {
        const unsigned pins[] = {GPIO_PIN_8, GPIO_PIN_9, GPIO_PIN_10, GPIO_PIN_11, GPIO_PIN_13, GPIO_PIN_12};
        const uint8_t logical[] = {RC_KEY_HOLD, RC_KEY_HOME, RC_KEY_BACK, RC_KEY_OK, RC_KEY_K5, RC_KEY_K6};
        for (unsigned i = 0; i < 6; i++) { key_test_mask = pins[i]; assert(keys_raw() == logical[i]); }
        key_test_mask = 0; assert(keys_raw() == 0);
        puts("PASS: physical K1 HOLD, K2 emergency, K3 BACK, K4 OK, K5/K6 gears");
    }

    for (unsigned i = NORMAL; i <= ACK_OLD; i++) run(i);
    reset(NORMAL); init_fail = 1; serial_size = 0;
    assert(!rc_runtime_init() && strstr(serial, "RADIO=0") && strstr(serial, "RADIO INIT FAIL"));
    for (unsigned failures = 1; failures <= 2; failures++) {
        reset(NORMAL); init_calls = init_delay_ms = serial_size = 0; init_transient = failures;
        assert(rc_runtime_init() && radio_ready);
        assert(init_calls == failures + 1 && init_delay_ms == failures * 50);
        assert(strstr(serial, "RADIO FIRST FAIL reg=00 want=0E got=FF"));
        assert(shared.flight.command.flags == FL_KILL && !shared.flight.session && !sends);
    }
    reset(NORMAL);
    if (!setjmp(done)) rc_runtime_start();
    puts("PASS: actual RC task, 20ms cadence, no UART in radio task, FF never becomes ACK success, failed send not counted");
    puts("PASS: frozen exits distinguish lost ACK, invalid SPI, missing/rejected telemetry and reported IMU/tilt faults");
    puts("PASS: ACK validation, 6.4s held throttle, raw HOME stop despite full UI queue, init failure, task ownership");
    puts("PASS: boot retry recovers 1/2 transient failures, stops after three persistent failures, retains first error and never auto-arms");
    puts("PASS: queued ACKs with RX_DR cleared still received for 6.4s; failed FIFO reads never become telemetry");
    return 0;
}
