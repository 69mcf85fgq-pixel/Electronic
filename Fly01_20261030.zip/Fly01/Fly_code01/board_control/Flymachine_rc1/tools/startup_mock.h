#ifndef RC_STARTUP_MOCK_H
#define RC_STARTUP_MOCK_H
#define __MAIN_H
#include "preview/main.h"
typedef struct { unsigned unused; } ADC_HandleTypeDef;
typedef struct { unsigned unused; } UART_HandleTypeDef;
typedef struct {
    uint32_t OscillatorType, HSEState, HSEPredivValue, HSIState;
    struct { uint32_t PLLState, PLLSource, PLLMUL; } PLL;
} RCC_OscInitTypeDef;
typedef struct { uint32_t ClockType, SYSCLKSource, AHBCLKDivider, APB1CLKDivider, APB2CLKDivider; } RCC_ClkInitTypeDef;
typedef struct { uint32_t PeriphClockSelection, AdcClockSelection; } RCC_PeriphCLKInitTypeDef;
#define RCC_OSCILLATORTYPE_HSE 1
#define RCC_HSE_ON 1
#define RCC_HSE_PREDIV_DIV1 1
#define RCC_HSI_ON 1
#define RCC_PLL_ON 1
#define RCC_PLLSOURCE_HSE 1
#define RCC_PLL_MUL9 9
#define RCC_CLOCKTYPE_HCLK 1
#define RCC_CLOCKTYPE_SYSCLK 2
#define RCC_CLOCKTYPE_PCLK1 4
#define RCC_CLOCKTYPE_PCLK2 8
#define RCC_SYSCLKSOURCE_PLLCLK 1
#define RCC_SYSCLK_DIV1 1
#define RCC_HCLK_DIV2 2
#define RCC_HCLK_DIV1 1
#define FLASH_LATENCY_2 2
#define RCC_PERIPHCLK_ADC 1
#define RCC_ADCPCLK2_DIV6 6
void HAL_Init(void);
void MX_SPI1_Init(void);
int HAL_RCC_OscConfig(RCC_OscInitTypeDef *config);
int HAL_RCC_ClockConfig(RCC_ClkInitTypeDef *config, uint32_t latency);
int HAL_RCCEx_PeriphCLKConfig(RCC_PeriphCLKInitTypeDef *config);
int HAL_ADCEx_Calibration_Start(ADC_HandleTypeDef *adc);
int HAL_ADC_Start_DMA(ADC_HandleTypeDef *adc, uint32_t *buffer, uint32_t count);
void Error_Handler(void);
#endif
