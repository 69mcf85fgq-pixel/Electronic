#include "startup_mock.h"
#include <assert.h>
#include <setjmp.h>
#include <stdio.h>
#define main rc_firmware_main
#include "../Src/main.c"
#undef main

ADC_HandleTypeDef hadc1;
static unsigned fail_radio, radio_called, lcd_called, ui_called, scheduler_called, blink_loop;
static jmp_buf finished;
void HAL_Init(void) {}
void MX_GPIO_Init(void) {}
void MX_DMA_Init(void) {}
void MX_SPI1_Init(void) {}
void MX_ADC1_Init(void) {}
void MX_USART1_UART_Init(void) {}
int HAL_RCC_OscConfig(RCC_OscInitTypeDef *config) { (void)config; return HAL_OK; }
int HAL_RCC_ClockConfig(RCC_ClkInitTypeDef *config, uint32_t latency)
{ (void)config; (void)latency; return HAL_OK; }
int HAL_RCCEx_PeriphCLKConfig(RCC_PeriphCLKInitTypeDef *config) { (void)config; return HAL_OK; }
int HAL_ADCEx_Calibration_Start(ADC_HandleTypeDef *adc) { (void)adc; return HAL_OK; }
int HAL_ADC_Start_DMA(ADC_HandleTypeDef *adc, uint32_t *buffer, uint32_t count)
{ (void)adc; (void)buffer; assert(count == 5); return HAL_OK; }
void bsp_led_toggle(void) { blink_loop = 1; }
void HAL_Delay(uint32_t ms)
{ (void)ms; if (blink_loop) longjmp(finished, 1); }
uint8_t rc_runtime_init(void) { radio_called++; return !fail_radio; }
void bsp_lcd_init(void) { lcd_called++; }
void rc_ui_boot(void) { assert(lcd_called); ui_called++; }
void rc_runtime_start(void) { assert(radio_called && lcd_called && ui_called); scheduler_called++; longjmp(finished, 1); }
int main(void)
{
    for (fail_radio = 0; fail_radio <= 1; fail_radio++) {
        radio_called = lcd_called = ui_called = scheduler_called = blink_loop = 0;
        if (!setjmp(finished)) rc_firmware_main();
        assert(lcd_called == 1 && ui_called == 1 && scheduler_called == 1 && !blink_loop);
    }
    puts("PASS: actual main boots LCD, UI and scheduler even when radio initialization fails");
    return 0;
}
