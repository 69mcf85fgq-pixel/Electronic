#include "rc_control.h"
#include <assert.h>
#include <stdio.h>

static const int16_t center[4] = {0, 0, 0, 0};
static fl_telemetry_t good = {
    .flags = FL_IMU_OK | FL_GEOMETRY_OK, .state = FL_STOPPED,
    .param_value = 150
};

static void arm(rc_control_t *rc, uint32_t start)
{
    rc_control_focus(rc, 1);
    rc_control_receive(rc, &good, start);
    rc_control_step(rc, start, center, 0, 0);
    for (uint32_t now = start + 20; now <= start + 1020; now += 20) {
        rc_control_receive(rc, &good, now);
        rc_control_step(rc, now, center, RC_KEY_OK, now == start + 20 ? RC_KEY_OK : 0);
    }
    assert(rc->session && rc->command.flags == FL_ARM);
}

static void delayed_arm_confirmation(void)
{
    rc_control_t rc;
    const int16_t pushed[4] = {300, -400, 0, 700};
    fl_telemetry_t t = good;
    rc_control_init(&rc);
    arm(&rc, 0);
    for (uint32_t now = 1040; now < 1140; now += 20) {
        rc_control_receive(&rc, &t, now);
        rc_control_step(&rc, now, pushed, 0, RC_KEY_HOLD);
        assert(rc.session && !rc.seen_armed && rc.command.flags == FL_ARM);
        assert(rc.command.hover_seq == 0);
        for (unsigned i = 0; i < 4; i++) assert(rc.command.axes[i] == 0);
    }
    t.flags |= FL_ARMED; t.state = FL_MANUAL;
    for (uint32_t now = 1140; now < 4140; now += 20) {
        const int16_t *joy = now < 1500 ? pushed : center;
        rc_control_receive(&rc, &t, now);
        rc_control_step(&rc, now, joy, 0, 0);
        assert(rc.session && rc.seen_armed && !rc.latched);
        assert(rc.command.flags == FL_ARM && rc.command.axes[3] == joy[3]);
    }
}

static void arm_confirmation_timeout(void)
{
    rc_control_t rc;
    const int16_t pushed[4] = {300, -400, 0, 700};
    fl_telemetry_t t = good;
    rc_control_init(&rc);
    arm(&rc, 0);
    for (uint32_t now = 1040; now <= 1520; now += 20) {
        rc_control_receive(&rc, &t, now);
        rc_control_step(&rc, now, pushed, RC_KEY_OK, 0);
        for (unsigned i = 0; i < 4; i++) assert(rc.command.axes[i] == 0);
    }
    assert(!rc.session && rc.latched && rc.command.flags == FL_KILL);
    assert(rc.stop_reason == RC_STOP_ARM_TIMEOUT && !rc.stop_fault);
    /* A late armed report or a still-held OK key cannot restart a timed-out request. */
    t.flags |= FL_ARMED; t.state = FL_MANUAL;
    rc_control_receive(&rc, &t, 1540);
    rc_control_step(&rc, 1540, center, RC_KEY_OK, 0);
    assert(!rc.session && rc.command.flags == FL_KILL);
    for (uint32_t now = 1560; now <= 3000; now += 20) {
        rc_control_receive(&rc, &good, now);
        rc_control_step(&rc, now, center, RC_KEY_OK, 0);
        assert(!rc.session && rc.command.flags == FL_KILL);
    }
    arm(&rc, 3020);
    assert(rc.stop_reason == RC_STOP_NONE);
}

static void takeoff_direction_packets(void)
{
    rc_control_t rc;
    fl_telemetry_t t = good;
    int16_t joy[4] = {1000, -1000, 800, 0};
    uint8_t packet[FL_CONTROL_LEN];
    fl_control_t decoded;
    rc_control_init(&rc); arm(&rc, 0);
    t.flags |= FL_ARMED; t.state = FL_MANUAL;
    for (uint32_t now = 1040; now <= 1140; now += 20) {
        joy[3] = (int16_t)(now - 1040);
        rc_control_receive(&rc, &t, now);
        rc_control_step(&rc, now, joy, 0, 0);
        fl_encode_control(packet, &rc.command);
        assert(fl_decode_control(&decoded, packet, sizeof(packet)));
        assert(rc.session && rc.seen_armed && decoded.flags == FL_ARM);
        assert(decoded.axes[0] == joy[0] && decoded.axes[1] == joy[1]);
        assert(decoded.axes[2] == 0 && decoded.axes[3] == joy[3]);
        joy[0] = (int16_t)-joy[0]; joy[1] = (int16_t)-joy[1];
    }
    rc_control_step(&rc, 1160, joy, RC_KEY_HOME, 0);
    assert(rc.command.flags == FL_KILL);
    for (unsigned i = 0; i < 4; i++) assert(rc.command.axes[i] == 0);
    puts("Takeoff packets: left-stick direction forwarded at zero/low throttle after confirmed arm, HOME overrides");
}

static void retained_stop_reasons(void)
{
    rc_control_t rc;
    fl_telemetry_t t;
    for (uint8_t fault = FL_MAP_FAULT; fault <= FL_BARO_FAULT; fault++) {
        rc_control_init(&rc); arm(&rc, 0);
        t = good; t.state = FL_FAULT; t.fault = fault;
        rc_control_receive(&rc, &t, 1040);
        rc_control_step(&rc, 1040, center, 0, 0);
        assert(!rc.session && rc.stop_reason == RC_STOP_FC_FAULT && rc.stop_fault == fault);
        rc_control_receive(&rc, &good, 1060);
        rc_control_step(&rc, 1060, center, RC_KEY_HOME, RC_KEY_HOME);
        rc_control_focus(&rc, 0);
        rc_control_step(&rc, 2000, center, 0, 0);
        assert(rc.stop_reason == RC_STOP_FC_FAULT && rc.stop_fault == fault);
        arm(&rc, 2020);
        assert(rc.stop_reason == RC_STOP_NONE && !rc.stop_fault);
    }
    const uint8_t expected[] = {RC_STOP_TELEMETRY, RC_STOP_IMU,
                                RC_STOP_DISARMED, RC_STOP_HOME};
    for (unsigned i = 0; i < sizeof(expected); i++) {
        rc_control_init(&rc); arm(&rc, 0);
        t = good; t.state = FL_MANUAL; t.flags |= FL_ARMED;
        rc_control_receive(&rc, &t, 1040);
        rc_control_step(&rc, 1040, center, 0, 0);
        if (i == 0) rc_control_step(&rc, 2040, center, 0, 0);
        else if (i == 3) rc_control_step(&rc, 1060, center, RC_KEY_HOME, RC_KEY_HOME);
        else {
            if (i == 1) t.flags &= (uint8_t)~FL_IMU_OK;
            if (i == 2) { t.flags &= (uint8_t)~FL_ARMED; t.state = FL_STOPPED; }
            rc_control_receive(&rc, &t, 1060);
            rc_control_step(&rc, 1060, center, 0, 0);
        }
        assert(rc.stop_reason == expected[i] && !rc.stop_fault && !rc.session);
        assert(rc.command.flags == FL_KILL);
    }
    /* Preserve a fault cleared by a second ACK in the same FIFO drain. */
    rc_control_init(&rc); arm(&rc, 0);
    t = good; t.flags |= FL_ARMED; t.state = FL_MANUAL;
    rc_control_receive(&rc, &t, 1040);
    rc_control_step(&rc, 1040, center, 0, 0);
    t = good; t.state = FL_FAULT; t.fault = FL_TILT_FAULT;
    rc_control_receive(&rc, &t, 1060);
    rc_control_receive(&rc, &good, 1060);
    rc_control_step(&rc, 1060, center, 0, 0);
    assert(rc.stop_reason == RC_STOP_FC_FAULT && rc.stop_fault == FL_TILT_FAULT);

    /* A fully recovered armed report must not poison a later unrelated stop. */
    rc_control_init(&rc); arm(&rc, 0);
    rc_control_receive(&rc, &t, 1040);
    t = good; t.flags |= FL_ARMED; t.state = FL_MANUAL;
    rc_control_receive(&rc, &t, 1040);
    rc_control_step(&rc, 1040, center, 0, 0);
    assert(rc.session && !rc.pending_fault && !rc.stop_reason);
    rc_control_receive(&rc, &good, 1060);
    rc_control_step(&rc, 1060, center, 0, 0);
    assert(rc.stop_reason == RC_STOP_DISARMED && !rc.stop_fault);

    rc_control_init(&rc); arm(&rc, 0);
    t = good; t.flags |= FL_ARMED; t.state = FL_HOLD_EXIT; t.fault = FL_BARO_FAULT;
    rc_control_receive(&rc, &t, 1040);
    rc_control_step(&rc, 1040, center, 0, 0);
    assert(rc.session && !rc.stop_reason && !rc.pending_fault);
    t.flags &= (uint8_t)~FL_IMU_OK;
    rc_control_receive(&rc, &t, 1060);
    rc_control_step(&rc, 1060, center, 0, 0);
    assert(!rc.session && rc.stop_reason == RC_STOP_IMU && !rc.stop_fault);
    puts("Retained exit causes: explicit FC faults, telemetry timeout, IMU invalid, disarm, HOME, rearm reset and ACK bursts");
}

static void bounded_return_gap(void)
{
    rc_control_t rc;
    fl_telemetry_t t = good;
    const int16_t pushed[4] = {100, -200, 0, 600};
    t.flags |= FL_ARMED; t.state = FL_MANUAL;
    rc_control_init(&rc); arm(&rc, 0);
    rc_control_receive(&rc, &t, 1040);
    rc_control_step(&rc, 1040, pushed, 0, 0);
    for (uint32_t now = 1060; now < 2040; now += 20) {
        rc_control_step(&rc, now, pushed, 0, 0);
        assert(rc.session && rc.command.flags == FL_ARM && rc.command.axes[3] == 600);
        if (now >= 1240) assert(!rc_control_fresh(&rc, now) && !rc_control_ready(&rc, now));
    }
    rc_control_step(&rc, 2039, pushed, 0, 0);
    assert(rc.session && rc.command.flags == FL_ARM);
    rc_control_step(&rc, 2040, pushed, 0, 0);
    assert(!rc.session && rc.stop_reason == RC_STOP_TELEMETRY && rc.command.flags == FL_KILL);

    rc_control_init(&rc); arm(&rc, 0);
    rc_control_receive(&rc, &t, 1040);
    rc_control_step(&rc, 1040, pushed, 0, 0);
    rc_control_step(&rc, 1940, pushed, 0, 0);
    assert(rc.session);
    rc_control_receive(&rc, &t, 2020);
    rc_control_step(&rc, 2020, pushed, 0, 0);
    assert(rc.session && rc_control_fresh(&rc, 2020));
    rc_control_step(&rc, 2240, pushed, RC_KEY_HOME, RC_KEY_HOME);
    assert(!rc.session && rc.stop_reason == RC_STOP_HOME && rc.command.flags == FL_KILL);

    rc_control_init(&rc); arm(&rc, 0);
    rc_control_receive(&rc, &t, 1040);
    rc_control_step(&rc, 1040, pushed, 0, 0);
    t.state = FL_FAULT; t.fault = FL_TILT_FAULT; t.flags &= (uint8_t)~FL_ARMED;
    rc_control_receive(&rc, &t, 1280);
    rc_control_step(&rc, 1280, pushed, 0, 0);
    assert(!rc.session && rc.stop_reason == RC_STOP_FC_FAULT && rc.stop_fault == FL_TILT_FAULT);

    rc_control_init(&rc); arm(&rc, 0);
    rc_control_step(&rc, 1220, pushed, 0, 0);
    assert(!rc.session && rc.stop_reason == RC_STOP_TELEMETRY); /* No confirmed arm: still 200 ms. */
    rc_control_init(&rc);
    t = good; t.flags |= FL_ARMED; t.state = FL_MANUAL;
    rc_control_receive(&rc, &t, UINT32_MAX - 100U);
    rc.session = rc.seen_armed = 1;
    rc_control_step(&rc, 220, pushed, 0, 0);
    assert(rc.session);
    rc_control_step(&rc, 898, pushed, 0, 0);
    assert(rc.session);
    rc_control_step(&rc, 899, pushed, 0, 0);
    assert(!rc.session && rc.stop_reason == RC_STOP_TELEMETRY);
    puts("Return-link grace: UI/prearm 200 ms, confirmed flight bounded to 1000 ms, recovery, wraparound, HOME and faults immediate");
}

static void geometry_does_not_block_control(void)
{
    rc_control_t rc;
    fl_telemetry_t t = good;
    const int16_t pushed[4] = {100, -200, 0, 600};
    t.flags &= (uint8_t)~FL_GEOMETRY_OK;
    rc_control_init(&rc);
    rc_control_focus(&rc, 1);
    rc_control_receive(&rc, &t, 0);
    assert(rc_control_ready(&rc, 0));
    rc_control_step(&rc, 0, center, 0, 0);
    for (uint32_t now = 20; now <= 1020; now += 20) {
        rc_control_receive(&rc, &t, now);
        rc_control_step(&rc, now, center, RC_KEY_OK, 0);
    }
    assert(rc.session && rc.command.flags == FL_ARM);
    t.flags |= FL_ARMED; t.state = FL_MANUAL;
    rc_control_receive(&rc, &t, 1040);
    rc_control_step(&rc, 1040, pushed, 0, 0);
    assert(rc.session && rc.seen_armed && !rc.stop_reason && rc.command.axes[3] == 600);
    rc_control_step(&rc, 1060, pushed, RC_KEY_HOME, 0);
    assert(!rc.session && rc.command.flags == FL_KILL);
}

int main(void)
{
    rc_control_t rc;
    int16_t joy[4] = {450, -650, 800, 700};
    fl_telemetry_t t;
    uint8_t packet[FL_CONTROL_LEN];
    fl_control_t decoded;

    bounded_return_gap();
    geometry_does_not_block_control();
    delayed_arm_confirmation();
    takeoff_direction_packets();
    arm_confirmation_timeout();
    retained_stop_reasons();
    rc_control_init(&rc);
    assert(!rc.session && rc.command.gear == 0 && rc.command.flags == FL_KILL);
    arm(&rc, 0);
    t = good; t.flags |= FL_ARMED; t.state = FL_MANUAL;
    rc_control_receive(&rc, &t, 1040);
    rc_control_step(&rc, 1040, joy, 0, RC_KEY_K6 | RC_KEY_HOLD);
    assert(rc.command.axes[0] == 450 && rc.command.axes[1] == -650);
    assert(rc.command.axes[2] == 0 && rc.command.axes[3] == 700);
    assert(rc.command.gear == 1 && rc.command.hover_seq == 1);
    rc_control_step(&rc, 1060, joy, RC_KEY_HOLD | RC_KEY_K6, 0);
    assert(rc.command.gear == 1 && rc.command.hover_seq == 1);
    rc_control_focus(&rc, 0);
    rc_control_step(&rc, 1080, joy, 0, RC_KEY_BACK | RC_KEY_K6);
    assert(rc.session && rc.command.axes[3] == 700 && rc.command.gear == 2);
    rc_control_step(&rc, 1100, joy, 0, RC_KEY_K6);
    assert(rc.command.gear == 2);
    joy[3] = -500;
    rc_control_step(&rc, 1120, joy, 0, RC_KEY_K5);
    assert(rc.command.axes[3] == 0 && rc.command.gear == 1);
    rc_control_step(&rc, 1240, joy, RC_KEY_OK, 0);
    assert(rc.session && !rc_control_fresh(&rc, 1240));
    rc_control_step(&rc, 2040, joy, RC_KEY_OK, RC_KEY_HOLD);
    assert(!rc.session && rc.latched && rc.command.flags == FL_KILL);
    assert(rc.command.axes[0] == 0 && rc.command.hover_seq == 1);
    rc_control_focus(&rc, 1);
    for (uint32_t now = 2060; now < 2500; now += 20) {
        rc_control_receive(&rc, &good, now);
        rc_control_step(&rc, now, center, RC_KEY_OK, 0);
    }
    assert(!rc.session); /* A held key cannot rearm after reconnection. */
    arm(&rc, 2500);
    t = good; t.state = FL_FAULT; t.fault = FL_TILT_FAULT;
    rc_control_receive(&rc, &t, 3540);
    rc_control_step(&rc, 3540, center, RC_KEY_OK, 0);
    assert(!rc.session && rc.latched);
    for (uint32_t now = 3560; now < 4800; now += 20) {
        rc_control_receive(&rc, &good, now);
        rc_control_step(&rc, now, center, RC_KEY_OK, 0);
    }
    assert(!rc.session);
    arm(&rc, 4800);
    rc_control_step(&rc, 5840, center, RC_KEY_HOME, RC_KEY_HOLD | RC_KEY_K6);
    assert(!rc.session && rc.command.flags == FL_KILL);
    assert(rc.command.hover_seq == 1 && rc.command.gear == 0);

    rc_control_init(&rc);
    rc_control_focus(&rc, 1);
    for (uint32_t now = 0; now < 1500; now += 20) {
        rc_control_receive(&rc, &good, now);
        rc_control_step(&rc, now, center, RC_KEY_OK, 0);
    }
    assert(!rc.session); /* Opening manual while holding OK is not an arm gesture. */
    rc_control_step(&rc, 1500, center, 0, 0);
    joy[3] = -10;
    for (uint32_t now = 1520; now < 3000; now += 20) {
        rc_control_receive(&rc, &good, now);
        rc_control_step(&rc, now, joy, RC_KEY_OK, RC_KEY_OK);
    }
    assert(!rc.session); /* Negative throttle is zero output, but not centered. */
    t = good; t.flags &= (uint8_t)~FL_GEOMETRY_OK;
    rc_control_receive(&rc, &t, 3000);
    assert(rc_control_ready(&rc, 3000));
    t = good; t.flags &= (uint8_t)~FL_IMU_OK;
    rc_control_receive(&rc, &t, 3000);
    assert(!rc_control_ready(&rc, 3000));
    rc_control_receive(&rc, &good, 0xFFFFFFF0U);
    assert(rc_control_fresh(&rc, 20));
    assert(!rc_control_fresh(&rc, 300));

    rc_control_init(&rc);
    rc.command.seq = 25;
    t = good; t.control_seq = 19;
    assert(!rc_control_echo_recent(&rc, &t, 100));
    t.control_seq = 26;
    assert(!rc_control_echo_recent(&rc, &t, 100));
    t.control_seq = 23;
    assert(rc_control_echo_recent(&rc, &t, 100));
    rc_control_receive(&rc, &t, 100);
    assert(!rc_control_echo_recent(&rc, &t, 120));
    t.control_seq = 22;
    assert(!rc_control_echo_recent(&rc, &t, 120));
    t.control_seq = 24;
    assert(rc_control_echo_recent(&rc, &t, 120));
    rc.command.seq = 1; rc.telemetry.control_seq = 255;
    t.control_seq = 0;
    assert(rc_control_echo_recent(&rc, &t, 120));
    rc.command.seq = 201; rc.telemetry.control_seq = 5;
    t.control_seq = 200;
    assert(!rc_control_echo_recent(&rc, &t, 120));
    assert(rc_control_echo_recent(&rc, &t, 4000));

    rc_control_init(&rc);
    rc_control_receive(&rc, &good, 100);
    assert(rc_control_param(&rc, 100, FL_ANGLE_P, 450));
    assert(rc.param_pending && rc.command.param_rev != 0);
    assert(!rc_control_param(&rc, 100, FL_RATE_P, 200));
    t = good; t.param_rev = rc.command.param_rev; t.param_id = FL_ANGLE_P; t.param_value = 440;
    rc_control_receive(&rc, &t, 120);
    assert(rc.param_pending);
    t.param_value = 450;
    rc_control_receive(&rc, &t, 140);
    assert(!rc.param_pending && rc.params[FL_ANGLE_P] == 450);
    assert(!rc_control_param(&rc, 140, FL_ANGLE_P, 49));
    assert(!rc_control_param(&rc, 140, FL_RATE_D, 501));
    assert(!rc_control_param(&rc, 400, FL_RATE_P, 200));
    t = good; t.param_rev = 255;
    rc_control_receive(&rc, &t, 420);
    assert(rc_control_param(&rc, 420, FL_RATE_P, 200));
    assert(rc.command.param_rev == 1);
    fl_encode_control(packet, &rc.command);
    assert(fl_decode_control(&decoded, packet, sizeof(packet)));
    assert(decoded.param_value == 200 && decoded.param_rev == 1);

    rc_control_init(&rc);
    t = good; t.fault = FL_MAP_FAULT; t.flags &= (uint8_t)~FL_GEOMETRY_OK;
    rc_control_receive(&rc, &t, 100);
    assert(!rc_control_ready(&rc, 100));
    assert(rc_control_can_edit(&rc, 100)); /* Bench tuning does not require confirmed rotation. */
    assert(rc_control_param(&rc, 100, FL_HEIGHT_P, 105));
    t.flags |= FL_ARMED;
    rc_control_receive(&rc, &t, 120);
    assert(!rc_control_can_edit(&rc, 120));

    rc_control_init(&rc);
    arm(&rc, 100);
    joy[0] = 150; joy[1] = -200; joy[3] = 650;
    t = good; t.flags |= FL_ARMED; t.state = FL_HOLD;
    rc_control_receive(&rc, &t, 1140);
    rc_control_step(&rc, 1140, joy, 0, RC_KEY_K6);
    t.state = FL_HOLD_EXIT; t.fault = FL_BARO_FAULT;
    rc_control_receive(&rc, &t, 1160);
    rc_control_step(&rc, 1160, joy, 0, 0);
    assert(rc.session && rc.command.flags == FL_ARM && !rc.latched);
    assert(rc.command.axes[0] == 150 && rc.command.axes[1] == -200 && rc.command.axes[3] == 650);
    rc_control_focus(&rc, 0);
    rc_control_step(&rc, 1180, joy, 0, RC_KEY_BACK | RC_KEY_K5);
    assert(rc.session && rc.command.flags == FL_ARM && rc.command.gear == 0);
    assert(rc_control_ready(&rc, 1180));
    rc.telemetry.flags &= (uint8_t)~FL_IMU_OK;
    assert(!rc_control_ready(&rc, 1180));
    rc.telemetry.flags |= FL_IMU_OK;
    rc.telemetry.flags &= (uint8_t)~FL_GEOMETRY_OK;
    assert(rc_control_ready(&rc, 1180));
    rc.telemetry.flags |= FL_GEOMETRY_OK;
    assert(!rc_control_ready(&rc, 1360));
    t.state = FL_STOPPED; t.flags &= (uint8_t)~FL_ARMED;
    rc_control_receive(&rc, &t, 1200);
    rc_control_step(&rc, 1200, joy, 0, 0);
    assert(!rc.session && rc.latched && rc.command.flags == FL_KILL);
    arm(&rc, 1300);
    t = good; t.flags |= FL_ARMED; t.state = FL_HOLD_EXIT; t.fault = FL_TILT_FAULT;
    rc_control_receive(&rc, &t, 2340);
    rc_control_step(&rc, 2340, joy, 0, 0);
    assert(!rc.session && rc.latched && rc.command.flags == FL_KILL);
    puts("RC control checks passed: arming, loss/fault latch, focus, axes, keys, parameters, recent ACK echoes, baro takeover");
    return 0;
}
