#ifndef PREVIEW_MAIN_H
#define PREVIEW_MAIN_H
#include <stdint.h>
typedef struct { uint32_t ErrorCode; } SPI_HandleTypeDef;
typedef int HAL_StatusTypeDef;
#define HAL_OK 0
#define __get_PRIMASK() 0U
#define __disable_irq() ((void)0)
#define __set_PRIMASK(mask) ((void)(mask))
typedef enum { GPIO_PIN_RESET, GPIO_PIN_SET } GPIO_PinState;
#define GPIOB ((void *)2)
#define GPIOA ((void *)1)
#define GPIO_PIN_0 1U
#define GPIO_PIN_1 2U
#define GPIO_PIN_8 256U
#define GPIO_PIN_9 512U
#define GPIO_PIN_10 1024U
#define GPIO_PIN_11 2048U
#define GPIO_PIN_12 4096U
#define GPIO_PIN_13 8192U
#define GPIO_PIN_14 16384U
#define GPIO_PIN_15 32768U
#define LCD_CS_GPIO_Port GPIOB
#define LCD_DC_GPIO_Port GPIOB
#define LCD_RES_GPIO_Port GPIOA
#define LCD_CS_Pin GPIO_PIN_14
#define LCD_DC_Pin GPIO_PIN_15
#define LCD_RES_Pin GPIO_PIN_8
#define CSN_GPIO_Port GPIOB
#define CSN_Pin GPIO_PIN_0
#define CE_GPIO_Port GPIOB
#define CE_Pin GPIO_PIN_1
void HAL_GPIO_WritePin(void *port, uint16_t pin, GPIO_PinState value);
GPIO_PinState HAL_GPIO_ReadPin(void *port, uint16_t pin);
int HAL_SPI_Transmit(SPI_HandleTypeDef *spi, uint8_t *data, uint16_t size, uint32_t timeout);
int HAL_SPI_TransmitReceive(SPI_HandleTypeDef *spi, uint8_t *tx, uint8_t *rx, uint16_t size, uint32_t timeout);
uint32_t HAL_GetTick(void);
void HAL_Delay(uint32_t delay);
#endif
