"""Check rendered glyphs against an uncropped font, and decimal columns in real C output."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import re
import ast
import math
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from generate_hanzi import load_font, SOURCE

root = Path(__file__).resolve().parent
source = (root.parents[1] / "Src/rc_ui.c").read_text(encoding="utf-8")
tokens = {name: int(value, 16) for name, value in
          re.findall(r"^#define\s+(UI_\w+)\s+(0x[0-9A-Fa-f]+)", source, re.M)}

def rgb565(name):
    value = tokens[name]
    return ((value >> 11 & 31) * 255 // 31,
            (value >> 5 & 63) * 255 // 63, (value & 31) * 255 // 31)

soft, teal, amber, danger = (rgb565(name) for name in
                           ("UI_SOFT", "UI_TEAL", "UI_AMBER", "UI_DANGER"))
font = load_font()

def reference_glyph(char, ascii_glyph=False):
    # Render the complete upstream glyph on its documented baseline range.
    # Do not read the generated arrays to derive expected pixels.
    x0, y0, x1, y1 = font.getbbox(char, anchor="ls")
    top, bottom = ((-14, 5) if ascii_glyph else (-15, 3))
    assert top <= y0 <= y1 <= bottom, (char, "reference would clip vertically")
    left = min(x0, 0)
    width = max(8, math.ceil(font.getlength(char)), x1) - left if ascii_glyph else 16
    assert 0 <= x0-left <= x1-left <= width, (char, "reference would clip horizontally")
    canvas = Image.new("L", (width, bottom-top))
    ImageDraw.Draw(canvas).text((-left, -top), char, font=font, fill=255, anchor="ls")
    return canvas.resize((8 if ascii_glyph else 16, 16), Image.Resampling.LANCZOS)

# Verify every embedded glyph against the pinned upstream font, including ASCII bit order.
bsp = root.parents[1] / "BSP"
ascii_source = (bsp / "lcdfont.h").read_text(encoding="utf-8")
ascii_rows = re.findall(r"\{((?:0x[0-9A-F]{2}(?:,\s*)?){16})\}", ascii_source)
assert len(ascii_rows) == 95, "ASCII interface must contain U+0020..U+007E"
for code, row in zip(range(32, 127), ascii_rows):
    values = [int(v, 16) for v in re.findall(r"0x[0-9A-F]{2}", row)]
    actual = [bool(values[y] & (1 << x)) for y in range(16) for x in range(8)]
    expected = [v >= 100 for v in reference_glyph(chr(code), True).get_flattened_data()]
    assert actual == expected, f"ASCII glyph/LSB-left mismatch: U+{code:04X}"
words = [ast.literal_eval(v).encode("latin1").decode("utf-8") for v in
         re.findall(r'^#define UI_TXT_\w+ (".*")$', (bsp/"ui_text.h").read_text(encoding="ascii"), re.M)]
expected_codes = sorted(set(ord(c) for c in re.findall(r"[\u4e00-\u9fff]", "".join(words))))
entries = re.findall(r"\{0x([0-9A-F]{4}), \{([^}]+)\}\}", (bsp/"hanzi_font.h").read_text(encoding="ascii"))
assert [int(c, 16) for c, _ in entries] == expected_codes, "Chinese set differs from current UI strings"
for code, row in entries:
    values = [int(v, 16) for v in re.findall(r"0x[0-9A-F]{4}", row)]
    assert len(values) == 16
    actual = [bool(values[y] & (1 << (15-x))) for y in range(16) for x in range(16)]
    expected = [v >= 100 for v in reference_glyph(chr(int(code, 16))).get_flattened_data()]
    assert actual == expected, f"Chinese glyph mismatch: U+{code}"
assert SOURCE["threshold"] == 100
print(f"Pinned OFL font checks passed: 95 ASCII LSB-left, {len(entries)} Chinese glyphs; no clipping")
for name, word in (("manual_stop_tilt", "倾角超限"), ("home_stop_tilt", "倾角超限"),
                   ("stop_map", "电机映射未确认"), ("stop_return_timeout", "遥测回传超时"),
                   ("stop_arm_timeout", "解锁未确认")):
    screen = Image.open(root / (name + ".ppm"))
    for index, char in enumerate(word):
        reference = reference_glyph(char)
        expected = [value >= 100 for value in reference.get_flattened_data()]
        pixels = screen.crop((108 + index * 16, 222, 124 + index * 16, 238))
        actual = [pixel == danger for pixel in pixels.get_flattened_data()]
        assert actual == expected, f"Missing or clipped exit reason glyph: {name}/{char}"
print("Exit notice pixel checks passed: retained Chinese cause, longest label, aircraft vs return-link timeouts")

for name, word, x, y, color in (
    ("manual_return_grace", "回传延迟", 12, 66, amber),
    ("home_return_grace", "飞行继续", 12, 222, soft),
):
    screen = Image.open(root / (name + ".ppm"))
    for index, char in enumerate(word):
        reference = reference_glyph(char)
        expected = [value >= 100 for value in reference.get_flattened_data()]
        pixels = screen.crop((x + index * 16, y, x + (index + 1) * 16, y + 16))
        actual = [pixel == color for pixel in pixels.get_flattened_data()]
        assert actual == expected, f"Missing return-link grace warning: {name}/{char}"
print("Return-link grace stays visible as a warning; home screen retains the emergency-stop reminder")

def luminance(rgb):
    channels = [v / 255 for v in rgb]
    linear = [v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in channels]
    return sum(v * w for v, w in zip(linear, (.2126, .7152, .0722)))

for name in ("UI_SOFT", "UI_TEAL", "UI_GOOD", "UI_DANGER", "UI_AMBER", "UI_WHITE"):
    for bg in ("UI_BG", "UI_PANEL"):
        contrast = (luminance(rgb565(name)) + .05) / (luminance(rgb565(bg)) + .05)
        assert contrast >= 4.5, f"Unreadable foreground: {name}/{bg} contrast {contrast:.2f}"

status = Image.open(root / "status_height.ppm")
assert status.getpixel((156, 118)) == teal and status.getpixel((259, 118)) == rgb565("UI_EDGE")
manual = Image.open(root / "manual_armed.ppm")
assert manual.getpixel((220, 184)) == teal and manual.getpixel((263, 184)) == rgb565("UI_EDGE")
assert Image.open(root / "home.ppm").size == (280, 240)
print("Glass theme: readable text and warnings, rounded body, header highlight, truthful ACK/throttle bars")
