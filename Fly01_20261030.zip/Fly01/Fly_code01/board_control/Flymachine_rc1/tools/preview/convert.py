"""Convert the actual host C renderer's PPM outputs to inspectable PNGs."""
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parent
for source in root.glob("*.ppm"):
    image = Image.open(source)
    image.save(source.with_suffix(".png"))
    image.resize((840, 720), Image.Resampling.NEAREST).save(
        source.with_name(source.stem + "_3x.png")
    )
print("Converted C LCD renders to PNG at native 280x240 and 3x magnification")
