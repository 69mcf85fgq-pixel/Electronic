/* Runs the actual rc_ui.c, BSP LCD pixels/fonts, and NRF transactions on the host. */
#include "rc_runtime.h"
#include "bsp_lcd.h"
#include "bsp_nrf.h"
#include "bsp_spi_bus.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

SPI_HandleTypeDef hspi1;
static uint16_t frame[LCD_H][LCD_W];
static uint8_t lcd_selected, nrf_selected, dc, lcd_command, param[4], param_count;
static uint8_t nrf_command, nrf_first, registers[32], payload_width = FL_TELEMETRY_LEN, payload_index;
static uint8_t addresses[2][5];
static uint16_t x0, x1, y0, y1, pixel_x, pixel_y;
static uint32_t tick = 10000, locks, chunk_pixels, maximum_chunk;
static uint32_t pixel_bytes;
static uint8_t locked, runtime, pixel_high, half_pixel;
static rc_snapshot_t sample;

void bsp_spi_bus_lock(void)
{
    assert(!locked && !lcd_selected && !nrf_selected);
    locked = 1; chunk_pixels = 0; locks++;
}
void bsp_spi_bus_unlock(void)
{
    assert(locked && !lcd_selected && !nrf_selected && !half_pixel);
    assert(chunk_pixels <= 560);
    if (chunk_pixels > maximum_chunk) maximum_chunk = chunk_pixels;
    locked = 0;
}
uint8_t bsp_spi_bus_init(void) { return 1; }
void HAL_GPIO_WritePin(void *port, uint16_t pin, GPIO_PinState value)
{
    if (port != GPIOB) return;
    if (pin == LCD_DC_Pin) dc = value;
    if (pin == LCD_CS_Pin) {
        if (!value) { assert(!nrf_selected && (!runtime || locked)); lcd_selected = 1; }
        else lcd_selected = 0;
    }
    if (pin == CSN_Pin) {
        if (!value) { assert(!lcd_selected && locked); nrf_selected = 1; nrf_first = 1; payload_index = 0; }
        else nrf_selected = 0;
    }
    if (pin == CE_Pin && value) {
        assert(!locked && !nrf_selected && !lcd_selected);
        registers[NRF_REG_FIFO_STATUS] |= NRF_FIFO_TX_EMPTY;
        registers[NRF_REG_STATUS] |= NRF_FLAG_TX_DS;
    }
}
GPIO_PinState HAL_GPIO_ReadPin(void *port, uint16_t pin)
{ (void)port; (void)pin; return GPIO_PIN_RESET; }
uint32_t HAL_GetTick(void) { return tick; }
void HAL_Delay(uint32_t delay) { tick += delay; }

static uint8_t nrf_byte(uint8_t byte)
{
    if (nrf_first) {
        nrf_first = 0; nrf_command = byte;
        if (byte == NRF_CMD_FLUSH_TX) registers[NRF_REG_FIFO_STATUS] |= NRF_FIFO_TX_EMPTY;
        if (byte == NRF_CMD_FLUSH_RX) registers[NRF_REG_FIFO_STATUS] |= NRF_FIFO_RX_EMPTY;
        return registers[NRF_REG_STATUS];
    }
    if (nrf_command == NRF_CMD_R_RX_PL_WID) return payload_width;
    if (nrf_command == NRF_CMD_R_RX_PAYLOAD) return payload_index++;
    uint8_t reg = nrf_command & 31;
    if ((nrf_command & 0xE0) == NRF_CMD_W_REGISTER) {
        if (reg == NRF_REG_RX_ADDR_P0 || reg == NRF_REG_TX_ADDR) {
            assert(payload_index < 5); addresses[reg == NRF_REG_TX_ADDR][payload_index++] = byte;
        } else registers[reg] = reg == NRF_REG_STATUS ? registers[reg] & ~byte : byte;
    }
    if ((nrf_command & 0xE0) == NRF_CMD_R_REGISTER) {
        if (reg == NRF_REG_RX_ADDR_P0 || reg == NRF_REG_TX_ADDR) {
            assert(payload_index < 5); return addresses[reg == NRF_REG_TX_ADDR][payload_index++];
        }
        return registers[reg];
    }
    return 0;
}

int HAL_SPI_TransmitReceive(SPI_HandleTypeDef *spi, uint8_t *tx, uint8_t *rx, uint16_t size, uint32_t timeout)
{
    (void)spi; (void)timeout;
    assert(nrf_selected && locked && !lcd_selected);
    for (uint16_t i = 0; i < size; i++) rx[i] = nrf_byte(tx[i]);
    return 0;
}

int HAL_SPI_Transmit(SPI_HandleTypeDef *spi, uint8_t *data, uint16_t size, uint32_t timeout)
{
    (void)spi; (void)timeout;
    if (nrf_selected) {
        assert(locked && !lcd_selected);
        for (uint16_t i = 0; i < size; i++) nrf_byte(data[i]);
        return 0;
    }
    assert(lcd_selected && (!runtime || locked));
    if (!dc) {
        assert(size == 1);
        lcd_command = data[0]; param_count = 0;
        if (lcd_command == 0x2C) { pixel_x = x0; pixel_y = y0; half_pixel = 0; }
    } else if (lcd_command == 0x2A || lcd_command == 0x2B) {
        for (uint16_t i = 0; i < size; i++) {
            assert(param_count < 4);
            param[param_count++] = data[i];
        }
        if (param_count == 4) {
            uint16_t start = (uint16_t)(param[0] * 256U + param[1]);
            uint16_t end = (uint16_t)(param[2] * 256U + param[3]);
            if (lcd_command == 0x2A) { x0 = start - LCD_XOFF; x1 = end - LCD_XOFF; }
            else { y0 = start - LCD_YOFF; y1 = end - LCD_YOFF; }
            assert(x0 <= x1 && x1 < LCD_W && y0 <= y1 && y1 < LCD_H);
        }
    } else if (lcd_command == 0x2C) {
        chunk_pixels += size;
        pixel_bytes += size;
        for (uint16_t i = 0; i < size; i++) {
            if (!half_pixel) { pixel_high = data[i]; half_pixel = 1; }
            else {
                assert(pixel_y <= y1 && pixel_y < LCD_H && pixel_x < LCD_W);
                frame[pixel_y][pixel_x] = (uint16_t)(pixel_high * 256U + data[i]);
                half_pixel = 0;
                if (++pixel_x > x1) { pixel_x = x0; pixel_y++; }
            }
        }
    }
    return 0;
}

void rc_runtime_snapshot(rc_snapshot_t *out) { *out = sample; }
void rc_runtime_focus(uint8_t manual) { (void)manual; }
extern void rc_ui_preview(const rc_snapshot_t *snapshot, uint8_t screen, uint8_t pid);
extern void rc_ui_preview_update(const rc_snapshot_t *snapshot, uint8_t screen, uint8_t pid);

static void write_frame(const char *directory, const char *name)
{
    char path[512];
    snprintf(path, sizeof(path), "%s/%s.ppm", directory, name);
    FILE *file = fopen(path, "wb");
    assert(file);
    fprintf(file, "P6\n%d %d\n255\n", LCD_W, LCD_H);
    for (uint16_t y = 0; y < LCD_H; y++) for (uint16_t x = 0; x < LCD_W; x++) {
        uint16_t p = frame[y][x];
        uint8_t rgb[3] = {(uint8_t)(((p >> 11) & 31) * 255 / 31),
                          (uint8_t)(((p >> 5) & 63) * 255 / 63), (uint8_t)((p & 31) * 255 / 31)};
        fwrite(rgb, 1, sizeof(rgb), file);
    }
    fclose(file);
    printf("Rendered %s\n", name);
}

static void render(const char *directory, const char *name, uint8_t screen, uint8_t pid)
{
    rc_ui_preview(&sample, screen, pid);
    assert(!locked && !lcd_selected && !nrf_selected);
    write_frame(directory, name);
}

static void unchanged_frames(uint8_t screen, uint8_t pid)
{
    uint16_t before[LCD_H][LCD_W];
    uint32_t bytes;
    rc_ui_preview(&sample, screen, pid);
    rc_ui_preview_update(&sample, screen, pid);
    memcpy(before, frame, sizeof(before));
    bytes = pixel_bytes;
    for (uint8_t i = 0; i < 20; i++) {
        tick += 20;
        sample.flight.telemetry_tick = sample.last_ack_tick = tick;
        rc_ui_preview_update(&sample, screen, pid);
    }
    printf("Unchanged screen %u: %lu pixel bytes in 20 frames\n", screen,
           (unsigned long)(pixel_bytes - bytes));
    assert(memcmp(before, frame, sizeof(before)) == 0);
    assert(pixel_bytes == bytes);
}

static void compare_cold_render(uint8_t screen, uint8_t pid)
{
    uint16_t expected[LCD_H][LCD_W];
    memcpy(expected, frame, sizeof(expected));
    /* A page entry must replace arbitrary prior LCD contents, including all corner gutters. */
    memset(frame, 0xCD, sizeof(frame));
    rc_ui_preview(&sample, screen, pid);
    assert(memcmp(expected, frame, sizeof(expected)) == 0);
}

static void joystick_extremes(void)
{
    rc_snapshot_t saved = sample;
    static const int16_t positions[][2] = {
        {0, -1000}, {0, 0}, {0, 1000}, {1000, 1000}, {-1000, -1000}, {0, 0}
    };
    memset(sample.joy, 0, sizeof(sample.joy));
    rc_ui_preview(&sample, 1, 0);
    for (unsigned p = 0; p < sizeof(positions) / sizeof(positions[0]); p++) {
        for (unsigned stick = 0; stick < 2; stick++) {
            sample.joy[stick * 2] = positions[p][0];
            sample.joy[stick * 2 + 1] = positions[p][1];
        }
        for (unsigned update = 0; update < 40; update++) rc_ui_preview_update(&sample, 1, 0);
        compare_cold_render(1, 0);
    }
    sample = saved;
    puts("Both joystick cursors restore crosshairs exactly after full-scale corners and return to center");
}

static void retained_stop_notice(const char *directory)
{
    rc_snapshot_t saved = sample;
    const int16_t center[4] = {0};
    uint16_t before[18][LCD_W], notice[18][LCD_W];
    fl_telemetry_t t = {.flags = FL_IMU_OK | FL_GEOMETRY_OK | FL_ARMED,
        .state = FL_MANUAL, .param_value = 150};
    rc_control_init(&sample.flight);
    rc_control_receive(&sample.flight, &t, tick);
    sample.flight.session = sample.flight.seen_armed = 1;
    rc_ui_preview(&sample, 1, 0);
    memcpy(before, &frame[222], sizeof(before));
    t.flags &= (uint8_t)~FL_ARMED; t.state = FL_FAULT; t.fault = FL_TILT_FAULT;
    rc_control_receive(&sample.flight, &t, tick);
    rc_control_step(&sample.flight, tick, center, 0, 0);
    assert(!sample.flight.session && sample.flight.command.flags == FL_KILL);
    t.state = FL_STOPPED; t.fault = FL_NO_FAULT;
    rc_control_receive(&sample.flight, &t, tick);
    rc_ui_preview_update(&sample, 1, 0);
    assert(memcmp(before, &frame[222], sizeof(before)) != 0);
    memcpy(notice, &frame[222], sizeof(notice));
    write_frame(directory, "manual_stop_tilt");
    tick += 220;
    rc_control_step(&sample.flight, tick, center, RC_KEY_HOME, 0);
    rc_ui_preview(&sample, 0, 0);
    assert(memcmp(notice, &frame[222], sizeof(notice)) == 0);
    write_frame(directory, "home_stop_tilt");
    rc_ui_preview(&sample, 4, 0);
    assert(memcmp(notice, &frame[222], sizeof(notice)) == 0);
    uint32_t bytes = pixel_bytes;
    rc_ui_preview_update(&sample, 4, 0);
    assert(pixel_bytes == bytes);
    uint16_t status[16][LCD_W];
    rc_ui_preview(&sample, 1, 0);
    memcpy(status, &frame[66], sizeof(status));
    rc_control_receive(&sample.flight, &t, tick);
    sample.flight.holding = 1; sample.flight.hold_tick = tick;
    rc_ui_preview_update(&sample, 1, 0);
    assert(memcmp(status, &frame[66], sizeof(status)) != 0);
    assert(memcmp(notice, &frame[222], sizeof(notice)) == 0);
    sample.flight.holding = 0;
    static const char *const names[] = {"stop_map", "stop_imu", "stop_air_radio",
                                       "stop_tilt", "stop_timing", "stop_baro"};
    for (uint8_t fault = FL_MAP_FAULT; fault <= FL_BARO_FAULT; fault++) {
        sample.flight.stop_fault = fault;
        render(directory, names[fault - 1], 1, 0);
    }
    for (uint8_t reason = RC_STOP_TELEMETRY; reason <= RC_STOP_HOME; reason++) {
        sample.flight.stop_reason = reason;
        rc_ui_preview_update(&sample, 1, 0);
        if (reason == RC_STOP_TELEMETRY) write_frame(directory, "stop_return_timeout");
        if (reason == RC_STOP_ARM_TIMEOUT) write_frame(directory, "stop_arm_timeout");
    }
    sample.flight.stop_reason = RC_STOP_NONE;
    sample.flight.session = 1;
    rc_ui_preview_update(&sample, 1, 0);
    assert(memcmp(before, &frame[222], sizeof(before)) == 0);
    sample = saved;
    puts("Stop reason survives cleared aircraft fault, stale telemetry, HOME and page changes without repainting");
}

static void panel_bounds(void)
{
    bsp_lcd_fill(LCD_BLACK);
    bsp_lcd_panel(20, 30, 64, 40, LCD_WHITE, LCD_BLUE);
    assert(frame[30][20] == LCD_BLACK && frame[50][40] == LCD_WHITE);
    assert(frame[30][32] != LCD_WHITE && frame[30][32] != LCD_BLACK);
    for (unsigned y = 0; y < LCD_H; y++) for (unsigned x = 0; x < LCD_W; x++)
        if (x < 20 || x >= 84 || y < 30 || y >= 70) assert(frame[y][x] == LCD_BLACK);
    uint32_t bytes = pixel_bytes;
    bsp_lcd_panel(LCD_W, 0, 100, 100, LCD_WHITE, LCD_BLUE);
    bsp_lcd_panel(0, LCD_H, 100, 100, LCD_WHITE, LCD_BLUE);
    bsp_lcd_panel(0, 0, 0, 20, LCD_WHITE, LCD_BLUE);
    bsp_lcd_panel(0, 0, 20, 0, LCD_WHITE, LCD_BLUE);
    assert(pixel_bytes == bytes);
    bsp_lcd_panel(270, 230, UINT16_MAX, UINT16_MAX, LCD_WHITE, LCD_BLUE);
    assert(frame[239][279] == LCD_WHITE && frame[229][279] == LCD_BLACK);
    assert(!locked && !lcd_selected);
    puts("Rounded panels preserve corner pixels, clip oversized/offscreen bounds, release SPI every row");
}

int main(int argc, char **argv)
{
    uint8_t packet[FL_CONTROL_LEN] = {0}, payload[FL_TELEMETRY_LEN];
    const char *directory = argc > 1 ? argv[1] : "tools/preview";
    bsp_lcd_init();
    runtime = 1;
    panel_bounds();
    assert(bsp_nrf_init() == 0);
    assert(registers[NRF_REG_RF_CH] == NRF_RADIO_CHANNEL);
    assert(registers[NRF_REG_FEATURE] == 6 && registers[NRF_REG_DYNPD] == 1);
    assert(bsp_nrf_send(packet, sizeof(packet)));
    bsp_nrf_flush_tx();
    assert(bsp_nrf_read_ack_payload(payload, sizeof(payload)) == sizeof(payload));
    payload_width = 33;
    assert(bsp_nrf_read_ack_payload(payload, sizeof(payload)) == 0);
    assert(!locked && !nrf_selected);

    rc_control_init(&sample.flight);
    sample.battery_raw = 3460;
    sample.last_ack_tick = tick;
    sample.link_percent = 98; sample.link_has_result = sample.link_rate_ready = 1;
    sample.tx_count = 530; sample.rx_count = 519;
    fl_telemetry_t telemetry = {.flags = FL_IMU_OK | FL_BARO_OK | FL_BARO_READY | FL_HEIGHT_READY,
        .state = FL_STOPPED, .fault = FL_MAP_FAULT, .param_value = 150,
        .roll_ddeg = 25, .pitch_ddeg = -18, .imu_id = 0x68, .baro_id = 0x5C,
        .pressure_dhpa = 10132, .temperature_dC = 246, .height_cm = 123};
    rc_control_receive(&sample.flight, &telemetry, tick);
    render(directory, "manual_geometry_locked", 1, 0);
    telemetry.flags |= FL_GEOMETRY_OK;
    telemetry.state = FL_STOPPED; telemetry.fault = 0;
    rc_control_receive(&sample.flight, &telemetry, tick);
    render(directory, "manual_disarmed", 1, 0);
    telemetry.flags |= FL_ARMED; telemetry.state = FL_MANUAL;
    rc_control_receive(&sample.flight, &telemetry, tick);
    sample.flight.session = 1; sample.flight.command.gear = 1;
    sample.joy[0] = 450; sample.joy[1] = -250; sample.joy[3] = 620;
    render(directory, "manual_armed", 1, 0);
    telemetry.state = FL_HOLD;
    rc_control_receive(&sample.flight, &telemetry, tick);
    render(directory, "manual_hold", 1, 0);
    telemetry.state = FL_HOLD_EXIT;
    rc_control_receive(&sample.flight, &telemetry, tick);
    render(directory, "manual_hold_exit", 1, 0);
    telemetry.fault = FL_BARO_FAULT;
    rc_control_receive(&sample.flight, &telemetry, tick);
    render(directory, "manual_baro_takeover", 1, 0);
    sample.flight.telemetry_tick = tick - 220;
    sample.flight.seen_armed = 1;
    render(directory, "manual_return_grace", 1, 0);
    render(directory, "home_return_grace", 0, 0);
    sample.flight.session = 0; sample.flight.latched = 1;
    render(directory, "manual_link_loss", 1, 0);
    sample.joy[0] = sample.joy[1] = sample.joy[3] = 0;
    telemetry.state = FL_STOPPED; telemetry.flags &= (uint8_t)~FL_ARMED; telemetry.fault = FL_NO_FAULT;
    rc_control_receive(&sample.flight, &telemetry, tick);
    render(directory, "preflight", 3, 0);
    render(directory, "settings", 4, 0);
    telemetry.flags |= FL_HEIGHT_READY; telemetry.height_cm = 123;
    rc_control_receive(&sample.flight, &telemetry, tick);
    render(directory, "status_height", 2, 0);
    render(directory, "home", 0, 0);
    unchanged_frames(1, 0);
    unchanged_frames(2, 0);
    unchanged_frames(3, 0);
    unchanged_frames(4, 0);
    unchanged_frames(0, 0);
    {
        extern void rc_ui_preview_select(const rc_snapshot_t *, uint8_t, uint8_t);
        uint16_t expected[LCD_H][LCD_W];
        rc_ui_preview(&sample, 0, 0);
        rc_ui_preview_select(&sample, 0, 3);
        memcpy(expected, frame, sizeof(expected));
        rc_ui_preview(&sample, 0, 3);
        assert(memcmp(expected, frame, sizeof(expected)) == 0);
        write_frame(directory, "home_selected");
    }
    sample.flight.telemetry.height_cm = -1;
    rc_ui_preview(&sample, 2, 0);
    sample.flight.telemetry.height_cm = 12345;
    rc_ui_preview_update(&sample, 2, 0);
    compare_cold_render(2, 0);
    sample.flight.telemetry.height_cm = 123;

    joystick_extremes();
    retained_stop_notice(directory);
    printf("BSP checks passed: %lu complete bus transactions, max LCD chunk %lu pixel bytes\n",
           (unsigned long)locks, (unsigned long)maximum_chunk);
    return 0;
}
