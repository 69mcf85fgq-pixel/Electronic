#ifndef RC_RUNTIME_MOCK_H
#define RC_RUNTIME_MOCK_H
#include <stdint.h>
#include <stddef.h>
#include <assert.h>
typedef uint32_t TickType_t;
typedef void *QueueHandle_t;
typedef void *TaskHandle_t;
typedef struct { unsigned unused; } UART_HandleTypeDef;
extern UART_HandleTypeDef huart1;
extern unsigned critical_depth;
#define taskENTER_CRITICAL() (++critical_depth)
#define taskEXIT_CRITICAL() (--critical_depth)
#define configASSERT(x) assert(x)
#define pdPASS 1
#define pdFALSE 0
#define pdMS_TO_TICKS(x) (x)
#define taskSCHEDULER_NOT_STARTED 0
#define GPIOB 1U
#define GPIO_PIN_RESET 0U
#define GPIO_PIN_8 (1U << 8)
#define GPIO_PIN_9 (1U << 9)
#define GPIO_PIN_10 (1U << 10)
#define GPIO_PIN_11 (1U << 11)
#define GPIO_PIN_12 (1U << 12)
#define GPIO_PIN_13 (1U << 13)
uint32_t HAL_GetTick(void);
unsigned HAL_GPIO_ReadPin(unsigned port, unsigned pin);
int HAL_UART_Transmit(UART_HandleTypeDef *, uint8_t *, uint16_t, uint32_t);
void Error_Handler(void);
int xTaskGetSchedulerState(void);
TickType_t xTaskGetTickCount(void);
int xTaskDelayUntil(TickType_t *, TickType_t);
void vTaskDelay(TickType_t);
unsigned uxTaskGetStackHighWaterMark(TaskHandle_t);
QueueHandle_t xQueueCreate(unsigned, unsigned);
int xQueueReceive(QueueHandle_t, void *, TickType_t);
int xQueueSend(QueueHandle_t, const void *, TickType_t);
int xTaskCreate(void (*)(void *), const char *, unsigned, void *, unsigned, TaskHandle_t *);
void vTaskStartScheduler(void);
#endif
