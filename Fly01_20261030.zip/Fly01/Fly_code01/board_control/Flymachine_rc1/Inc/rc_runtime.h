#ifndef RC_RUNTIME_H
#define RC_RUNTIME_H
#include "rc_control.h"

typedef struct {
    /* Window starts after the last accepted telemetry, not at boot. */
    uint32_t ack, retry, spi_bad, reads, bad, old, max_gap_ms;
} rc_link_diag_t;

typedef struct {
    /* Frozen on session exit; UINT32_MAX ages mean unknown. */
    uint32_t number, tick, telemetry_age_ms, ack_age_ms;
    rc_link_diag_t link;
    fl_telemetry_t last;
    uint8_t reason, fault, received, status, fifo;
} rc_stop_diag_t;

typedef struct {
    rc_control_t flight;
    int16_t joy[4];
    uint16_t battery_raw;
    uint32_t last_ack_tick, tx_count, rx_count, missed_periods, ui_event_overruns;
    uint8_t buttons, link_percent, link_has_result, link_rate_ready;
    rc_stop_diag_t stop_diag;
} rc_snapshot_t;

uint8_t rc_runtime_init(void);
void rc_runtime_start(void);
void rc_runtime_snapshot(rc_snapshot_t *out);
uint8_t rc_runtime_buttons(void);
void rc_runtime_focus(uint8_t manual);
uint8_t rc_runtime_param(uint8_t id, uint16_t value);
void rc_radio_task(void *argument);
void rc_runtime_log_stop(const rc_stop_diag_t *diag);
#endif
