#ifndef RC_UI_H
#define RC_UI_H
void rc_ui_boot(void);
void rc_ui_task(void *argument);
#endif
