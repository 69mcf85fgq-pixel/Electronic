#ifndef RC_CONTROL_H
#define RC_CONTROL_H
#include "flight_link.h"

#define RC_KEY_OK    0x01U
#define RC_KEY_BACK  0x02U
#define RC_KEY_HOME  0x04U
#define RC_KEY_HOLD    0x08U
#define RC_KEY_K5    0x10U
#define RC_KEY_K6    0x20U
#define RC_TELEMETRY_MS 200U
#define RC_FLIGHT_TELEMETRY_MS 1000U
#define RC_ARM_HOLD_MS 1000U

enum { RC_STOP_NONE, RC_STOP_FC_FAULT, RC_STOP_TELEMETRY, RC_STOP_IMU,
       RC_STOP_MAP, RC_STOP_DISARMED, RC_STOP_ARM_TIMEOUT, RC_STOP_HOME };

typedef struct {
    fl_control_t command;
    fl_telemetry_t telemetry;
    uint16_t params[FL_PARAM_COUNT];
    uint32_t telemetry_tick, hold_tick, arm_tick;
    uint8_t received, manual_focus, session, latched, seen_armed;
    uint8_t ok_released, holding, param_pending, param_known;
    uint8_t stop_reason, stop_fault, pending_fault;
} rc_control_t;

void rc_control_init(rc_control_t *rc);
void rc_control_focus(rc_control_t *rc, uint8_t manual);
uint8_t rc_control_fresh(const rc_control_t *rc, uint32_t now);
uint8_t rc_control_echo_recent(const rc_control_t *rc, const fl_telemetry_t *telemetry, uint32_t now);
uint8_t rc_control_ready(const rc_control_t *rc, uint32_t now);
uint8_t rc_control_can_edit(const rc_control_t *rc, uint32_t now);
void rc_control_receive(rc_control_t *rc, const fl_telemetry_t *telemetry, uint32_t now);
void rc_control_step(rc_control_t *rc, uint32_t now, const int16_t joy[4],
                     uint8_t held, uint8_t pressed);
uint8_t rc_control_param(rc_control_t *rc, uint32_t now, uint8_t id, uint16_t value);
#endif
