#include "rc_runtime.h"
#include "rc_ui.h"
#include "main.h"
#include "bsp_nrf.h"
#include "bsp_spi_bus.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "usart.h"
#include <stdio.h>
#include <string.h>

extern volatile uint16_t adc_raw[5];
static rc_snapshot_t shared;
static QueueHandle_t key_queue;
static uint8_t manual_focus, radio_ready;
/* Inspect these in the debugger after sustained full-screen activity. */
volatile uint16_t rc_radio_stack_free_words, rc_ui_stack_free_words;

static int16_t joystick_value(uint16_t raw, uint16_t center)
{
    int32_t value = (int32_t)raw - center;
    if (value > -120 && value < 120) return 0;
    value = value * 1000 / 2048;
    if (value > 1000) value = 1000;
    if (value < -1000) value = -1000;
    return (int16_t)value;
}

static uint8_t keys_raw(void)
{
    /* K1=PB8 HOLD, K2=PB9 immediate stop, K3=PB10 BACK, K4=PB11 OK. */
    uint8_t keys = 0;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8) == GPIO_PIN_RESET) keys |= RC_KEY_HOLD;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9) == GPIO_PIN_RESET) keys |= RC_KEY_HOME;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == GPIO_PIN_RESET) keys |= RC_KEY_BACK;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == GPIO_PIN_RESET) keys |= RC_KEY_OK;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_13) == GPIO_PIN_RESET) keys |= RC_KEY_K5;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12) == GPIO_PIN_RESET) keys |= RC_KEY_K6;
    return keys;
}

static uint8_t keys_debounce(uint8_t raw)
{
    static uint8_t stable, previous, counts[6];
    for (uint8_t i = 0; i < 6; i++) {
        uint8_t bit = (uint8_t)(1U << i);
        if ((raw ^ previous) & bit) counts[i] = 0;
        else if (counts[i] < 2) counts[i]++;
        if (counts[i] >= 2) stable = (stable & (uint8_t)~bit) | (raw & bit);
    }
    previous = raw;
    return stable;
}

uint8_t rc_runtime_init(void)
{
    char line[128];
    uint8_t ready, radio_attempts;
    nrf_error_t first_error = {0};
    int length;
    rc_control_init(&shared.flight);
    shared.battery_raw = adc_raw[4];
    /* Failed startup must not require an MCU reset after one transient SPI fault. */
    for (radio_attempts = 1; ; radio_attempts++) {
        ready = bsp_nrf_init() == 0;
        if (ready) break;
        if (radio_attempts == 1) bsp_nrf_get_error(&first_error);
        if (radio_attempts == 3) break;
        HAL_Delay(50);
    }
    radio_ready = ready;
    length = snprintf(line, sizeof(line),
        "\r\nRC NORMAL v3 RADIO=%u channel=%u freq_mhz=%u\r\n",
        ready, (unsigned)NRF_RADIO_CHANNEL, (unsigned)(2400U + NRF_RADIO_CHANNEL));
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 40);
    length = snprintf(line, sizeof(line), "RADIO BOOT tries=%u ready=%u\r\n", radio_attempts, ready);
    if (length > 0 && length < (int)sizeof(line))
        HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 40);
    if (radio_attempts > 1) {
        length = snprintf(line, sizeof(line),
            "RADIO FIRST FAIL reg=%02X want=%02X got=%02X HAL=%u SPI=%08lX\r\n",
            first_error.reg, first_error.expected, first_error.actual, first_error.hal,
            (unsigned long)first_error.spi_error);
        if (length > 0 && length < (int)sizeof(line))
            HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 40);
    }
    if (!ready) {
        nrf_error_t error;
        bsp_nrf_get_error(&error);
        length = snprintf(line, sizeof(line),
            "RADIO INIT FAIL reg=%02X want=%02X got=%02X HAL=%u SPI=%08lX\r\n",
            error.reg, error.expected, error.actual, error.hal, (unsigned long)error.spi_error);
        if (length > 0 && length < (int)sizeof(line))
            HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)length, 40);
    }
    return ready;
}

void rc_runtime_snapshot(rc_snapshot_t *out)
{
    if (xTaskGetSchedulerState() == taskSCHEDULER_NOT_STARTED) { *out = shared; return; }
    taskENTER_CRITICAL();
    *out = shared;
    taskEXIT_CRITICAL();
}

uint8_t rc_runtime_buttons(void)
{
    uint8_t keys = 0;
    xQueueReceive(key_queue, &keys, 0);
    return keys;
}

void rc_runtime_focus(uint8_t manual)
{
    if (xTaskGetSchedulerState() == taskSCHEDULER_NOT_STARTED) { manual_focus = manual; return; }
    taskENTER_CRITICAL();
    manual_focus = manual;
    taskEXIT_CRITICAL();
}

uint8_t rc_runtime_param(uint8_t id, uint16_t value)
{
    uint8_t accepted;
    taskENTER_CRITICAL();
    accepted = rc_control_param(&shared.flight, HAL_GetTick(), id, value);
    taskEXIT_CRITICAL();
    return accepted;
}

void rc_runtime_log_stop(const rc_stop_diag_t *d)
{
    char line[224];
    int n;
    if (!d || !d->number) return;
    n = snprintf(line, sizeof(line),
        "RC STOP n=%lu t=%lu reason=%u fault=%u telem_ms=%lu ack_ms=%lu gap_ms=%lu\r\n",
        (unsigned long)d->number, (unsigned long)d->tick, d->reason, d->fault,
        (unsigned long)d->telemetry_age_ms, (unsigned long)d->ack_age_ms,
        (unsigned long)d->link.max_gap_ms);
    if (n > 0 && n < (int)sizeof(line)) HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)n, 40);
    n = snprintf(line, sizeof(line),
        "RC LINK ack=%lu rt=%lu spi_bad=%lu read=%lu bad=%lu old=%lu S=%02X FIFO=%02X\r\n",
        (unsigned long)d->link.ack, (unsigned long)d->link.retry, (unsigned long)d->link.spi_bad,
        (unsigned long)d->link.reads, (unsigned long)d->link.bad, (unsigned long)d->link.old,
        d->status, d->fifo);
    if (n > 0 && n < (int)sizeof(line)) HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)n, 40);
    n = snprintf(line, sizeof(line),
        "RC LAST valid=%u state=%u fault=%u flags=%02X imu=%u ID=%02X R=%d P=%d seq=%u M=%u,%u,%u,%u\r\n",
        d->received, d->last.state, d->last.fault, d->last.flags, !!(d->last.flags & FL_IMU_OK),
        d->last.imu_id, d->last.roll_ddeg, d->last.pitch_ddeg, d->last.control_seq,
        d->last.motors[0], d->last.motors[1], d->last.motors[2], d->last.motors[3]);
    if (n > 0 && n < (int)sizeof(line)) HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)n, 40);
    static const uint8_t note[] = "RC NOTE counters_since_last_valid_telemetry; age=4294967295 means unknown; aircraft_during_outage=UNKNOWN\r\n";
    HAL_UART_Transmit(&huart1, (uint8_t *)note, sizeof(note) - 1U, 40);
}

void rc_radio_task(void *argument)
{
    const uint16_t centers[4] = {2045, 2047, 2048, 2065};
    TickType_t wake = xTaskGetTickCount();
    uint8_t previous_keys = 0, link_results = 0, link_success = 0;
    uint32_t window_tick = HAL_GetTick();
    uint32_t previous_tick = window_tick;
    rc_link_diag_t gap = {0};
    uint8_t pending = 0;
    (void)argument;

    for (;;) {
        uint32_t now = HAL_GetTick();
        uint8_t raw = keys_raw();
        uint8_t held = keys_debounce(raw);
        uint8_t pressed = held & (uint8_t)~previous_keys;
        uint8_t status, status_valid, fifo = 0xFF, was_session, accepted_now = 0;
        int16_t joy[4];
        uint8_t packet[FL_CONTROL_LEN];
        fl_control_t command;
        status = radio_ready ? bsp_nrf_read_reg(NRF_REG_STATUS) : 0xFF;
        status_valid = status != 0xFF;
        if (radio_ready && !status_valid) gap.spi_bad++;
        previous_keys = held;
        for (uint8_t i = 0; i < 4; i++) joy[i] = joystick_value(adc_raw[i], centers[i]);

        if (status_valid) {
            /* RX_DR can be cleared after a late arrival; FIFO contents are authoritative. */
            for (uint8_t i = 0; i < 3; i++) {
                fifo = bsp_nrf_read_reg(NRF_REG_FIFO_STATUS);
                if (fifo == 0xFF) { gap.spi_bad++; break; }
                if (fifo & NRF_FIFO_RX_EMPTY) break;
                uint8_t payload[FL_TELEMETRY_LEN];
                fl_telemetry_t telemetry;
                uint8_t size = bsp_nrf_read_ack_payload(payload, sizeof(payload));
                gap.reads++;
                if (fl_decode_telemetry(&telemetry, payload, size)) {
                    taskENTER_CRITICAL();
                    if (shared.tx_count && rc_control_echo_recent(&shared.flight, &telemetry, now)) {
                        rc_control_receive(&shared.flight, &telemetry, now);
                        shared.rx_count++;
                        memset(&gap, 0, sizeof(gap));
                        accepted_now = 1;
                    } else gap.old++;
                    taskEXIT_CRITICAL();
                } else gap.bad++;
            }
        }

        taskENTER_CRITICAL();
        if (now - previous_tick > gap.max_gap_ms) gap.max_gap_ms = now - previous_tick;
        if (now - previous_tick > 25U) shared.missed_periods++;
        previous_tick = now;
        for (uint8_t i = 0; i < 4; i++) shared.joy[i] = joy[i];
        shared.buttons = held;
        shared.battery_raw = (uint16_t)(((uint32_t)shared.battery_raw * 15U + adc_raw[4]) / 16U);
        rc_control_focus(&shared.flight, manual_focus);
        /* HOME bypasses debounce, even when UI rendering or event delivery is delayed. */
        was_session = shared.flight.session;
        rc_control_step(&shared.flight, now, joy, held | (raw & RC_KEY_HOME), pressed);
        command = shared.flight.command;
        if (pending && status_valid && (status & (NRF_FLAG_TX_DS | NRF_FLAG_MAX_RT))) {
            link_results++;
            shared.link_has_result = 1;
            if (!accepted_now && (status & NRF_FLAG_MAX_RT)) gap.retry++;
            if ((status & NRF_FLAG_TX_DS) && !(status & NRF_FLAG_MAX_RT)) {
                link_success++; shared.last_ack_tick = now;
                if (!accepted_now) gap.ack++;
            }
        }
        if (was_session && !shared.flight.session) {
            rc_stop_diag_t *d = &shared.stop_diag;
            d->number++; d->tick = now;
            d->telemetry_age_ms = shared.flight.received ? now - shared.flight.telemetry_tick : UINT32_MAX;
            d->ack_age_ms = shared.last_ack_tick ? now - shared.last_ack_tick : UINT32_MAX;
            d->link = gap; d->last = shared.flight.telemetry;
            d->reason = shared.flight.stop_reason; d->fault = shared.flight.stop_fault;
            d->received = shared.flight.received; d->status = status; d->fifo = fifo;
        }
        if (now - window_tick >= 1000U) {
            shared.link_percent = link_results ? (uint8_t)(100U * link_success / link_results) : 0;
            shared.link_rate_ready = 1;
            link_results = link_success = 0;
            window_tick = now;
        }
        taskEXIT_CRITICAL();

        if (pressed && xQueueSend(key_queue, &pressed, 0) != pdPASS) {
            taskENTER_CRITICAL();
            shared.ui_event_overruns++;
            taskEXIT_CRITICAL();
        }
        fl_encode_control(packet, &command);
        pending = 0;
        if (status_valid) {
            if (bsp_nrf_write_reg(NRF_REG_STATUS, NRF_FLAG_CLR_ALL) == 0xFF ||
                bsp_nrf_flush_tx() == 0xFF) gap.spi_bad++;
            else {
                pending = bsp_nrf_send(packet, sizeof(packet));
                if (!pending) gap.spi_bad++;
            }
        }
        if (pending) {
            taskENTER_CRITICAL();
            shared.tx_count++;
            taskEXIT_CRITICAL();
        }
        rc_radio_stack_free_words = (uint16_t)uxTaskGetStackHighWaterMark(NULL);
        if (xTaskDelayUntil(&wake, pdMS_TO_TICKS(20)) == pdFALSE) {
            /* Do not emit a burst of catch-up packets after a stopped-only flash save. */
            wake = xTaskGetTickCount();
            vTaskDelay(pdMS_TO_TICKS(1));
        }
    }
}

void rc_runtime_start(void)
{
    /* Kernel allocation masks interrupts before scheduler startup: boot delays are complete. */
    key_queue = xQueueCreate(16, sizeof(uint8_t));
    configASSERT(key_queue != NULL && bsp_spi_bus_init());
    configASSERT(xTaskCreate(rc_radio_task, "rc-radio", 512, NULL, 3, NULL) == pdPASS);
    configASSERT(xTaskCreate(rc_ui_task, "rc-ui", 768, NULL, 1, NULL) == pdPASS);
    vTaskStartScheduler();
    Error_Handler();
}

void rc_assert_failed(void) { Error_Handler(); }
void vApplicationMallocFailedHook(void) { Error_Handler(); }
void vApplicationStackOverflowHook(TaskHandle_t task, char *name)
{ (void)task; (void)name; Error_Handler(); }
