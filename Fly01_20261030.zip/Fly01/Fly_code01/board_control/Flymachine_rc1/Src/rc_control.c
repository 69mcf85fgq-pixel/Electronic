#include "rc_control.h"
#include <string.h>

void rc_control_init(rc_control_t *rc)
{
    memset(rc, 0, sizeof(*rc));
    rc->command.flags = FL_KILL;
    for (uint8_t i = 0; i < FL_PARAM_COUNT; i++) rc->params[i] = fl_param_default(i);
    rc->command.param_value = rc->params[FL_RATE_P];
}

static void stop(rc_control_t *rc, uint8_t reason)
{
    if (rc->session) {
        rc->stop_reason = reason;
        rc->stop_fault = reason == RC_STOP_FC_FAULT ?
                         (rc->pending_fault ? rc->pending_fault : rc->telemetry.fault) : 0;
    }
    rc->pending_fault = 0;
    rc->session = rc->holding = rc->ok_released = rc->seen_armed = 0;
    rc->latched = 1;
    rc->command.flags = FL_KILL;
    rc->command.gear = 0;
    memset(rc->command.axes, 0, sizeof(rc->command.axes));
}

void rc_control_focus(rc_control_t *rc, uint8_t manual)
{
    if (manual != rc->manual_focus) rc->holding = rc->ok_released = 0;
    rc->manual_focus = manual;
}
uint8_t rc_control_fresh(const rc_control_t *rc, uint32_t now)
{ return rc->received && now - rc->telemetry_tick < RC_TELEMETRY_MS; }
uint8_t rc_control_echo_recent(const rc_control_t *rc, const fl_telemetry_t *telemetry, uint32_t now)
{
    uint8_t age = (uint8_t)(rc->command.seq - telemetry->control_seq);
    uint8_t advance = (uint8_t)(telemetry->control_seq - rc->telemetry.control_seq);
    if (age > 5U) return 0;
    if (!rc->received) return 1;
    if (!advance) return 0;
    /* After a long outage, an 8-bit sequence may have advanced by more than half a wrap. */
    return !rc_control_fresh(rc, now) || advance < 128U;
}
static uint8_t telemetry_ready(const rc_control_t *rc, uint32_t now, uint32_t timeout)
{
    uint8_t baro_takeover = rc->session && (rc->telemetry.flags & FL_ARMED) &&
                            rc->telemetry.state == FL_HOLD_EXIT && rc->telemetry.fault == FL_BARO_FAULT;
    return rc->received && now - rc->telemetry_tick < timeout &&
           (rc->telemetry.flags & FL_IMU_OK) &&
           (rc->telemetry.fault == FL_NO_FAULT || baro_takeover) && rc->telemetry.state != FL_FAULT;
}
uint8_t rc_control_ready(const rc_control_t *rc, uint32_t now)
{ return telemetry_ready(rc, now, RC_TELEMETRY_MS); }
uint8_t rc_control_can_edit(const rc_control_t *rc, uint32_t now)
{
    return !rc->session && rc_control_fresh(rc, now) &&
           (rc->telemetry.fault == FL_NO_FAULT || rc->telemetry.fault == FL_MAP_FAULT) &&
           rc->telemetry.state == FL_STOPPED &&
           !(rc->telemetry.flags & FL_ARMED);
}
void rc_control_receive(rc_control_t *rc, const fl_telemetry_t *telemetry, uint32_t now)
{
    /* An ACK FIFO can contain the fault followed by an already-cleared stopped report. */
    if (rc->session && !rc->pending_fault && telemetry->fault &&
        !(telemetry->fault == FL_BARO_FAULT && telemetry->state == FL_HOLD_EXIT &&
          (telemetry->flags & FL_ARMED))) rc->pending_fault = telemetry->fault;
    rc->telemetry = *telemetry;
    rc->telemetry_tick = now;
    rc->received = 1;
    if (telemetry->param_id < FL_PARAM_COUNT && fl_param_valid(telemetry->param_id, telemetry->param_value)) {
        rc->params[telemetry->param_id] = telemetry->param_value;
        rc->param_known |= (uint8_t)(1U << telemetry->param_id);
    }
    if (rc->param_pending && telemetry->param_rev == rc->command.param_rev &&
        telemetry->param_id == rc->command.param_id && telemetry->param_value == rc->command.param_value)
        rc->param_pending = 0;
}
void rc_control_step(rc_control_t *rc, uint32_t now, const int16_t joy[4],
                     uint8_t held, uint8_t pressed)
{
    rc->command.seq++;
    if (!rc_control_fresh(rc, now)) rc->param_known = 0;
    if (held & RC_KEY_HOME) { stop(rc, RC_STOP_HOME); return; }

    if (rc->session) {
        /* Display freshness is stricter than the bounded in-flight return-link gap. */
        uint32_t timeout = rc->seen_armed ? RC_FLIGHT_TELEMETRY_MS : RC_TELEMETRY_MS;
        uint8_t reason = RC_STOP_NONE;
        if (!telemetry_ready(rc, now, timeout) ||
            (rc->seen_armed && !(rc->telemetry.flags & FL_ARMED)) ||
            (!rc->seen_armed && now - rc->arm_tick >= 500U && !(rc->telemetry.flags & FL_ARMED))) {
            if (!rc->received || now - rc->telemetry_tick >= timeout) reason = RC_STOP_TELEMETRY;
            else if (rc->pending_fault || rc->telemetry.state == FL_FAULT ||
                     (rc->telemetry.fault && !(rc->telemetry.fault == FL_BARO_FAULT &&
                       rc->telemetry.state == FL_HOLD_EXIT && (rc->telemetry.flags & FL_ARMED))))
                reason = RC_STOP_FC_FAULT;
            else if (!(rc->telemetry.flags & FL_IMU_OK)) reason = RC_STOP_IMU;
            else reason = rc->seen_armed ? RC_STOP_DISARMED : RC_STOP_ARM_TIMEOUT;
            stop(rc, reason);
            return;
        }
        rc->pending_fault = 0;
        if (rc->telemetry.flags & FL_ARMED) rc->seen_armed = 1;
    }

    if (!rc->session) {
        rc->command.flags = FL_KILL;
        memset(rc->command.axes, 0, sizeof(rc->command.axes));
        if (!(held & RC_KEY_OK)) {
            rc->holding = 0;
            rc->ok_released = 1;
        } else if (rc->manual_focus && rc->ok_released && joy[3] == 0 &&
                   rc_control_ready(rc, now) && rc->telemetry.state == FL_STOPPED &&
                   !(rc->telemetry.flags & FL_ARMED) && !rc->param_pending) {
            if (!rc->holding) { rc->holding = 1; rc->hold_tick = now; }
            if (now - rc->hold_tick >= RC_ARM_HOLD_MS) {
                rc->session = 1;
                rc->latched = rc->holding = rc->ok_released = 0;
                rc->seen_armed = 0;
                rc->arm_tick = now;
                rc->command.gear = 0;
                rc->stop_reason = rc->stop_fault = rc->pending_fault = 0;
            }
        } else {
            /* An interrupted gesture requires release before another attempt. */
            rc->holding = rc->ok_released = 0;
        }
    }

    if (rc->session || rc->manual_focus) {
        if ((pressed & RC_KEY_K5) && rc->command.gear) rc->command.gear--;
        if ((pressed & RC_KEY_K6) && rc->command.gear < 2) rc->command.gear++;
    }
    if (rc->session) {
        rc->command.flags = FL_ARM;
        if (rc->seen_armed) {
            rc->command.axes[0] = joy[0];
            rc->command.axes[1] = joy[1];
            rc->command.axes[2] = 0;
            rc->command.axes[3] = joy[3] > 0 ? joy[3] : 0;
            if (pressed & RC_KEY_HOLD) rc->command.hover_seq++;
        } else {
            /* Keep the arm request at zero throttle until the aircraft confirms it. */
            memset(rc->command.axes, 0, sizeof(rc->command.axes));
        }
    }
}
uint8_t rc_control_param(rc_control_t *rc, uint32_t now, uint8_t id, uint16_t value)
{
    if (!rc_control_can_edit(rc, now) || rc->param_pending || !fl_param_valid(id, value)) return 0;
    uint8_t revision = (uint8_t)(rc->telemetry.param_rev + 1U);
    if (!revision) revision = 1;
    rc->command.param_rev = revision;
    rc->command.param_id = id;
    rc->command.param_value = value;
    rc->param_pending = 1;
    return 1;
}
