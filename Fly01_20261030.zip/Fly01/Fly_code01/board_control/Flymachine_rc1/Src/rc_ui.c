#include "rc_ui.h"
#include "rc_runtime.h"
#include "bsp_lcd.h"
#include "ui_text.h"
#include <stdio.h>
#include <string.h>
#ifndef RC_UI_PREVIEW
#include "FreeRTOS.h"
#include "task.h"
#endif

#define UI_ITEM_COUNT 4
#define UI_SCREEN_MANUAL 1
#define UI_SCREEN_STATUS 2
#define UI_SCREEN_PREFLIGHT 3
#define UI_SCREEN_SETTINGS 4
#define UI_CANVAS        0x0042
#define UI_BG            0x0884
#define UI_PANEL         0x1147
#define UI_EDGE          0x32AC
#define UI_TEAL          0x6FFA
#define UI_AMBER         0xFDEE
#define UI_SOFT          0xB639
#define UI_WHITE         0xF7DF
#define UI_GOOD          0x8FB5
#define UI_DANGER        0xFCB2


static const char *const ui_items[UI_ITEM_COUNT] = {
    UI_TXT_MENU_MANUAL, UI_TXT_MENU_STATUS, UI_TXT_MENU_PREFLIGHT, UI_TXT_MENU_SETTINGS
};
static rc_snapshot_t ui_data;
#define battery_filtered ui_data.battery_raw
#define last_ack_tick ui_data.last_ack_tick
#define link_percent ui_data.link_percent
#define link_has_result ui_data.link_has_result
#define link_rate_ready ui_data.link_rate_ready
#define telemetry_imu_valid (ui_data.flight.telemetry.flags & FL_IMU_OK)
#define telemetry_roll ui_data.flight.telemetry.roll_ddeg
#define telemetry_pitch ui_data.flight.telemetry.pitch_ddeg
static int16_t display_joy[4];
static int16_t old_cursor_x[2] = {-1, -1};
static int16_t old_cursor_y[2] = {-1, -1};
typedef struct {
    char text[64];
    uint16_t foreground, background;
    uint8_t valid;
} ui_field_t;
static ui_field_t fields[24];
static uint8_t battery_painted, battery_known, battery_level;
static uint8_t rate_bar_painted, rate_bar_level;
static uint8_t throttle_bar_painted, throttle_bar_level;

/* Flat interiors keep cached glyph replacement exact; highlights live only on rims. */
static void ui_glass(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t fill)
{
    bsp_lcd_panel(x, y, w, h, fill, UI_EDGE);
}

static void ui_bar(uint16_t x, uint16_t y, uint16_t width, uint8_t level,
                    uint16_t color, uint8_t *painted, uint8_t *previous)
{
    if (level > 100) level = 100;
    if (*painted && level == *previous) return;
    uint16_t filled = width * level / 100U;
    bsp_lcd_fill_rect(x, y, filled, 3, color);
    bsp_lcd_fill_rect(x + filled, y, width - filled, 3, UI_EDGE);
    *painted = 1; *previous = level;
}

/* The LCD already owns the background for each glyph: overwrite, never erase first. */
static uint8_t ui_field(uint8_t id, uint16_t x, uint16_t y, uint16_t width,
                        const char *text, uint16_t foreground, uint16_t background)
{
    ui_field_t *field = &fields[id];
    char padded[100];
    unsigned length = strlen(text), pixels = 0;
    const uint8_t *p = (const uint8_t *)text;
    if (field->valid && field->foreground == foreground && field->background == background &&
        strcmp(field->text, text) == 0) return 0;
    if (length >= sizeof(field->text)) return 0;
    memcpy(field->text, text, length + 1);
    field->foreground = foreground; field->background = background; field->valid = 1;
    memcpy(padded, text, length);
    while (*p) {
        if ((*p & 0xF0) == 0xE0 && p[1] && p[2]) { p += 3; pixels += 16; }
        else { p++; pixels += 8; }
    }
    while (pixels + 8 <= width && length + 1 < sizeof(padded)) {
        padded[length++] = ' '; pixels += 8;
    }
    padded[length] = 0;
    bsp_lcd_text(x, y, padded, foreground, background);
    return 1;
}

static const char *ui_fault_text(uint8_t fault)
{
    static const char *const reasons[] = {
        UI_TXT_FC_ERROR_NONE, UI_TXT_FC_ERROR_MAP, UI_TXT_FC_ERROR_IMU,
        UI_TXT_FC_ERROR_RADIO, UI_TXT_FC_ERROR_TILT, UI_TXT_FC_ERROR_TIMING,
        UI_TXT_FC_ERROR_BARO
    };
    return reasons[fault <= FL_BARO_FAULT ? fault : 0];
}

static const char *ui_stop_text(uint8_t reason, uint8_t fault)
{
    static const char *const reasons[] = {
        "", "", UI_TXT_RC_STOP_TELEMETRY, UI_TXT_RC_STOP_IMU, UI_TXT_RC_STOP_MAP,
        UI_TXT_RC_STOP_DISARMED, UI_TXT_RC_STOP_ARM_TIMEOUT, UI_TXT_RC_STOP_HOME
    };
    if (reason == RC_STOP_FC_FAULT) return ui_fault_text(fault);
    return reasons[reason <= RC_STOP_HOME ? reason : 0];
}

static const char *footer_text = "";
static uint16_t footer_color;

static void ui_refresh_footer(void)
{
    char line[64];
    const char *text = footer_text;
    uint16_t color = footer_color;
    if (!ui_data.flight.session && ui_data.flight.stop_reason) {
        snprintf(line, sizeof(line), UI_TXT_LAST_EXIT,
                 ui_stop_text(ui_data.flight.stop_reason, ui_data.flight.stop_fault));
        text = line;
        color = ui_data.flight.stop_reason == RC_STOP_HOME ? UI_AMBER : UI_DANGER;
    }
    ui_field(22, 12, 222, 256, text, color, UI_BG);
}

static void ui_footer(const char *text, uint16_t color)
{
    footer_text = text; footer_color = color;
    ui_refresh_footer();
}

static const char *ui_fc_state(uint32_t now)
{
    if (!rc_control_fresh(&ui_data.flight, now)) return UI_TXT_STATUS_NO_TELEMETRY;
    static const char *const states[] = {
        UI_TXT_FC_STOPPED, UI_TXT_FC_MANUAL, UI_TXT_FC_HOLD, UI_TXT_FC_HOLD_EXIT, UI_TXT_FC_FAULT
    };
    return ui_data.flight.telemetry.state <= FL_FAULT ?
           states[ui_data.flight.telemetry.state] : UI_TXT_FC_FAULT;
}

static uint16_t battery_mv(void)
{
    /* 2S battery, Rtop=100k, Rbottom=62k, Vref assumed 3.3 V. */
    return (uint16_t)((uint32_t)battery_filtered * 3300U * 162U / (4095U * 62U));
}

static void ui_battery(void)
{
    char line[14];
    uint16_t mv = battery_mv();
    uint8_t level = 0;

    if (mv > 6600) level = mv >= 8400 ? 100 : (uint8_t)((mv - 6600) / 18);
    uint8_t known = mv >= 5500 && mv <= 9000;
    if (!known)
    {
        ui_field(23, 168, 10, 80, UI_TXT_BAT_UNKNOWN, UI_SOFT, UI_PANEL);
        if (!battery_painted || battery_known)
            bsp_lcd_fill_rect(251, 12, 25, 12, UI_PANEL);
    }
    else
    {
        snprintf(line, sizeof(line), UI_TXT_BAT_FORMAT, mv / 1000, (mv % 1000) / 10);
        ui_field(23, 168, 10, 80, line, level < 20 ? UI_AMBER : UI_WHITE, UI_PANEL);
        if (!battery_painted || !battery_known) {
            bsp_lcd_fill_rect(251, 12, 22, 12, UI_WHITE);
            bsp_lcd_fill_rect(274, 15, 2, 6, UI_WHITE);
        }
        if (!battery_painted || !battery_known || battery_level != level) {
            uint16_t filled = 18 * level / 100;
            bsp_lcd_fill_rect(253, 14, filled, 8, level < 20 ? UI_AMBER : UI_GOOD);
            bsp_lcd_fill_rect(253 + filled, 14, 18 - filled, 8, UI_PANEL);
        }
    }
    battery_painted = 1; battery_known = known; battery_level = level;
}

static void ui_frame(const char *title, const char *footer)
{
    memset(fields, 0, sizeof(fields));
    battery_painted = 0;
    rate_bar_painted = throttle_bar_painted = 0;
    /* Paint the canvas gutters/corners, then each panel once (no full-screen erase). */
    bsp_lcd_fill_rect(0, 0, LCD_W, 8, UI_CANVAS);
    bsp_lcd_fill_rect(0, 28, LCD_W, 18, UI_CANVAS);
    bsp_lcd_fill_rect(0, 208, LCD_W, 12, UI_CANVAS);
    bsp_lcd_fill_rect(0, 36, 14, 184, UI_CANVAS);
    bsp_lcd_fill_rect(266, 36, 14, 184, UI_CANVAS);
    ui_glass(0, 0, LCD_W, 36, UI_PANEL);
    ui_glass(6, 38, 268, 178, UI_BG);
    bsp_lcd_text(12, 10, title, UI_WHITE, UI_PANEL);
    bsp_lcd_fill_rect(0, 220, LCD_W, 20, UI_BG);
    bsp_lcd_fill_rect(12, 218, 256, 1, UI_EDGE);
    ui_footer(footer, UI_SOFT);
    ui_battery();
}

static uint8_t link_recent(uint32_t now)
{
    return last_ack_tick && now - last_ack_tick < 700;
}

static void ui_home_status(uint32_t now)
{
    uint8_t ack = link_recent(now);
    const char *line = ack ? (rc_control_fresh(&ui_data.flight, now) ? UI_TXT_HOME_ACK : UI_TXT_HOME_STALE) :
                       link_has_result ? UI_TXT_HOME_NO_ACK : UI_TXT_HOME_WAIT;
    if (ui_field(0, 40, 54, 224, line, ack ? UI_GOOD : UI_SOFT, UI_BG))
        bsp_lcd_fill_rect(24, 58, 8, 8, ack ? UI_GOOD : UI_AMBER);
    ui_footer(
                 (ui_data.flight.session && ui_data.flight.seen_armed) ||
                 (rc_control_fresh(&ui_data.flight, now) && (ui_data.flight.telemetry.flags & FL_ARMED)) ?
                 UI_TXT_FC_RUNNING_FOOTER : UI_TXT_HOME_FOOTER, UI_SOFT);
}

static void ui_status_values(uint32_t now)
{
    char line[14];
    ui_field(0, 156, 55, 112,
                 link_recent(now) ? UI_TXT_VALUE_ACK :
                 link_has_result ? UI_TXT_VALUE_NO_ACK : UI_TXT_VALUE_WAIT,
                 link_recent(now) ? UI_GOOD : UI_AMBER, UI_BG);

    if (link_rate_ready) snprintf(line, sizeof(line), "%u%%", link_percent);
    else snprintf(line, sizeof(line), "--%%");
    ui_field(1, 156, 95, 112, line, UI_TEAL, UI_BG);
    ui_bar(156, 118, 104, link_rate_ready ? link_percent : 0, UI_TEAL,
           &rate_bar_painted, &rate_bar_level);

    if (rc_control_fresh(&ui_data.flight, now) && (ui_data.flight.telemetry.flags & FL_HEIGHT_READY)) {
        int32_t height = ui_data.flight.telemetry.height_cm;
        uint16_t magnitude = (uint16_t)(height < 0 ? -height : height);
        snprintf(line, sizeof(line), "%c%u.%02um", height < 0 ? '-' : '+', magnitude / 100, magnitude % 100);
    } else snprintf(line, sizeof(line), "--.--m");
    ui_field(2, 156, 135, 112, line, UI_TEAL, UI_BG);

    if (!rc_control_fresh(&ui_data.flight, now))
        ui_field(3, 156, 175, 112, UI_TXT_STATUS_NO_TELEMETRY, UI_SOFT, UI_BG);
    else if (!telemetry_imu_valid)
        ui_field(3, 156, 175, 112, UI_TXT_STATUS_IMU_ERROR, UI_AMBER, UI_BG);
    else
    {
        snprintf(line, sizeof(line), "R%+d P%+d", telemetry_roll / 10, telemetry_pitch / 10);
        ui_field(3, 156, 175, 112, line, UI_TEAL, UI_BG);
    }
}

static void ui_preflight_values(uint32_t now, const int16_t joystick[4])
{
    uint8_t centered = 1;
    uint16_t mv = battery_mv();
    for (uint8_t i = 0; i < 4; i++) if (joystick[i]) centered = 0;

    ui_field(0, 156, 55, 112, centered ? UI_TXT_VALUE_CENTERED : UI_TXT_VALUE_MOVE_STICK,
                 centered ? UI_GOOD : UI_AMBER, UI_BG);

    const char *battery_state = mv < 5500 || mv > 9000 ? UI_TXT_VALUE_NOT_DETECTED :
                                mv < 7000 ? UI_TXT_VALUE_LOW : UI_TXT_VALUE_DETECTED;
    ui_field(1, 156, 95, 112, battery_state, mv >= 7000 && mv <= 9000 ? UI_GOOD : UI_AMBER, UI_BG);

    ui_field(2, 156, 135, 112,
                 link_recent(now) ? UI_TXT_VALUE_ACK :
                 link_has_result ? UI_TXT_VALUE_NO_ACK : UI_TXT_VALUE_WAIT,
                 link_recent(now) ? UI_GOOD : UI_AMBER, UI_BG);

    ui_field(3, 156, 175, 112,
                 rc_control_fresh(&ui_data.flight, now) && !(ui_data.flight.telemetry.flags & FL_GEOMETRY_OK) ?
                 UI_TXT_FC_GEOMETRY : ui_fc_state(now),
                 rc_control_ready(&ui_data.flight, now) ? UI_GOOD : UI_AMBER, UI_BG);
}

static void ui_splash(void)
{
    bsp_lcd_fill(UI_CANVAS);
    ui_glass(26, 48, 228, 136, UI_BG);
    bsp_lcd_str(96, 74, "AUST RC", UI_WHITE, UI_BG);
    bsp_lcd_fill_rect(94, 104, 92, 2, UI_TEAL);
    bsp_lcd_text(108, 126, UI_TXT_SPLASH_SUBTITLE, UI_SOFT, UI_BG);
    HAL_Delay(300);
}

static void ui_draw_manual(void)
{
    ui_frame(UI_TXT_MENU_MANUAL, UI_TXT_MANUAL_FOOTER);
    bsp_lcd_text(28, 88, UI_TXT_STICK_LEFT, UI_AMBER, UI_BG);
    bsp_lcd_text(166, 88, UI_TXT_STICK_RIGHT, UI_TEAL, UI_BG);
    for (uint8_t stick = 0; stick < 2; stick++)
    {
        uint16_t x = stick ? 156 : 12;
        uint16_t center = stick ? 212 : 68;
        ui_glass(x, 108, 112, 72, UI_PANEL);
        /* Include y=176, the lower edge restored beneath a full-down cursor. */
        bsp_lcd_fill_rect(center, 112, 1, 65, UI_EDGE);
        bsp_lcd_fill_rect(x + 4, 144, 104, 1, UI_EDGE);
        old_cursor_x[stick] = old_cursor_y[stick] = -1;
    }
    for (uint8_t i = 0; i < 4; i++) display_joy[i] = 0;
}

static int16_t ui_smooth(int16_t current, int16_t target)
{
    int16_t delta = target - current;
    if (!delta) return current;
    return current + (delta / 3 ? delta / 3 : (delta > 0 ? 1 : -1));
}

static void ui_manual_update(const int16_t joy[4])
{
    char line[28];
    for (uint8_t i = 0; i < 4; i++) display_joy[i] = ui_smooth(display_joy[i], joy[i]);
    for (uint8_t stick = 0; stick < 2; stick++)
    {
        int16_t center = stick ? 212 : 68;
        int16_t x = stick ? 156 : 12;
        int16_t next_x = center + display_joy[stick * 2] * 42 / 1000;
        int16_t next_y = 144 - display_joy[stick * 2 + 1] * 28 / 1000;
        uint16_t color = stick ? UI_TEAL : UI_AMBER;
        if (next_x != old_cursor_x[stick] || next_y != old_cursor_y[stick])
        {
            if (old_cursor_x[stick] >= 0) {
                bsp_lcd_fill_rect(old_cursor_x[stick] - 4, old_cursor_y[stick] - 4, 9, 9, UI_PANEL);
                if (old_cursor_x[stick] >= center - 4 && old_cursor_x[stick] <= center + 4)
                    bsp_lcd_fill_rect(center, old_cursor_y[stick] - 4, 1, 9, UI_EDGE);
                if (old_cursor_y[stick] >= 140 && old_cursor_y[stick] <= 148)
                    bsp_lcd_fill_rect(old_cursor_x[stick] - 4, 144, 9, 1, UI_EDGE);
            }
            old_cursor_x[stick] = next_x; old_cursor_y[stick] = next_y;
            bsp_lcd_fill_rect(next_x - 4, next_y - 4, 9, 9, color);
            bsp_lcd_fill_rect(next_x - 1, next_y - 1, 3, 3, UI_WHITE);
        }
        if (stick)
            snprintf(line, sizeof(line), UI_TXT_THROTTLE_VALUE_FORMAT, joy[3] > 0 ? joy[3] / 10 : 0);
        else if (rc_control_fresh(&ui_data.flight, HAL_GetTick()) &&
                 (ui_data.flight.telemetry.flags & FL_HEIGHT_READY)) {
            int32_t h = ui_data.flight.telemetry.height_cm;
            uint16_t mag = (uint16_t)(h < 0 ? -h : h);
            snprintf(line, sizeof(line), UI_TXT_HEIGHT_VALUE, h < 0 ? '-' : '+', mag / 100, mag % 100);
        } else snprintf(line, sizeof(line), UI_TXT_HEIGHT_UNKNOWN);
        ui_field(3 + stick, x + 2, 194, 112, line, color, UI_BG);
    }
    ui_bar(160, 184, 104, joy[3] > 0 ? (uint8_t)(joy[3] / 10) : 0,
           UI_TEAL, &throttle_bar_painted, &throttle_bar_level);
}

static void ui_manual_state(uint32_t now)
{
    char line[48];
    const rc_control_t *rc = &ui_data.flight;
    uint8_t fresh = rc_control_fresh(rc, now);
    uint8_t baro_warning = fresh &&
        (rc->telemetry.flags & (FL_IMU_OK | FL_GEOMETRY_OK | FL_ARMED)) == (FL_IMU_OK | FL_GEOMETRY_OK | FL_ARMED) &&
        rc->telemetry.fault == FL_BARO_FAULT && rc->telemetry.state == FL_HOLD_EXIT;
    ui_field(0, 12, 44, 168, ui_fc_state(now),
             fresh && rc->telemetry.state != FL_FAULT ? UI_WHITE : UI_AMBER, UI_BG);
    snprintf(line, sizeof(line), UI_TXT_FC_GEAR, rc->command.gear + 1);
    ui_field(1, 192, 44, 72, line, UI_TEAL, UI_BG);

    if (!rc->session && rc->stop_reason && !rc->holding && !ui_data.joy[3])
        snprintf(line, sizeof(line), UI_TXT_LAST_EXIT, ui_stop_text(rc->stop_reason, rc->stop_fault));
    else if (!fresh) snprintf(line, sizeof(line), "%s", rc->session && rc->seen_armed ?
                             UI_TXT_FC_TELEMETRY_DELAY : UI_TXT_STATUS_NO_TELEMETRY);
    else if (!(rc->telemetry.flags & FL_GEOMETRY_OK)) snprintf(line, sizeof(line), UI_TXT_FC_GEOMETRY);
    else if (!(rc->telemetry.flags & FL_IMU_OK)) snprintf(line, sizeof(line), UI_TXT_FC_IMU_ERROR);
    else if (baro_warning) snprintf(line, sizeof(line), UI_TXT_FC_BARO_TAKEOVER);
    else if (rc->telemetry.fault) snprintf(line, sizeof(line), "%s", ui_fault_text(rc->telemetry.fault));
    else if (rc->telemetry.flags & FL_ARMED) snprintf(line, sizeof(line), UI_TXT_FC_ARMED);
    else if (rc->session) snprintf(line, sizeof(line), UI_TXT_FC_ARM_REQUEST);
    else if (rc->holding) {
        uint32_t percent = (now - rc->hold_tick) / 10U;
        if (percent > 100) percent = 100;
        snprintf(line, sizeof(line), UI_TXT_FC_ARM_HOLD, (unsigned)percent);
    }
    else if (ui_data.joy[3]) snprintf(line, sizeof(line), UI_TXT_FC_CENTER_THROTTLE);
    else if (rc->latched) snprintf(line, sizeof(line), UI_TXT_FC_LATCHED);
    else snprintf(line, sizeof(line), UI_TXT_FC_ARM_READY);
    ui_field(2, 12, 66, 256, line, baro_warning || (!rc->session && rc->stop_reason != RC_STOP_NONE &&
                 rc->stop_reason != RC_STOP_HOME) ? UI_DANGER :
                 rc->session && fresh && !rc->telemetry.fault ? UI_GOOD : UI_AMBER, UI_BG);
}

static void ui_menu_row(uint8_t item, uint8_t selected)
{
    uint16_t y = 80 + item * 31;
    uint16_t bg = item == selected ? UI_PANEL : UI_BG;
    char index[4];
    bsp_lcd_fill_rect(16, y, 248, 27, UI_BG);
    ui_glass(16, y, 248, 27, bg);
    if (item == selected) bsp_lcd_fill_rect(20, y + 6, 3, 15, UI_TEAL);
    bsp_lcd_text(30, y + 5, ui_items[item], item == selected ? UI_WHITE : UI_SOFT, bg);
    snprintf(index, sizeof(index), "%02u", item + 1);
    bsp_lcd_str(234, y + 5, index, item == selected ? UI_TEAL : UI_SOFT, bg);
}

static void ui_draw_home(uint8_t selected)
{
    ui_frame(UI_TXT_HOME_TITLE, UI_TXT_HOME_FOOTER);
    ui_home_status(HAL_GetTick());
    for (uint8_t i = 0; i < UI_ITEM_COUNT; i++) ui_menu_row(i, selected);
}

static void ui_draw_page(uint8_t page)
{
    if (page == 0) ui_draw_manual();
    else if (page == 1 || page == 2) {
        uint8_t check = page == 2;
        ui_frame(check ? UI_TXT_MENU_PREFLIGHT : UI_TXT_MENU_STATUS, UI_TXT_PREFLIGHT_FOOTER);
        const char *labels[4] = {
            check ? UI_TXT_PREFLIGHT_STICK : UI_TXT_STATUS_LINK,
            check ? UI_TXT_PREFLIGHT_BAT : UI_TXT_STATUS_RATE,
            check ? UI_TXT_STATUS_LINK : UI_TXT_STATUS_HEIGHT,
            check ? UI_TXT_PREFLIGHT_FC : UI_TXT_STATUS_ATTITUDE
        };
        for (uint8_t i = 0; i < 4; i++) {
            bsp_lcd_text(20, 55 + i * 40, labels[i], UI_SOFT, UI_BG);
            if (i < 3) bsp_lcd_fill_rect(20, 84 + i * 40, 240, 1, UI_EDGE);
        }
    } else {
        ui_frame(UI_TXT_MENU_SETTINGS, UI_TXT_SETTINGS_FOOTER);
        bsp_lcd_text(20, 58, UI_TXT_SETTINGS_KEYS, UI_WHITE, UI_BG);
        bsp_lcd_text(20, 90, UI_TXT_SETTINGS_STOP, UI_AMBER, UI_BG);
        bsp_lcd_fill_rect(20, 120, 240, 1, UI_EDGE);
        bsp_lcd_text(20, 138, UI_TXT_SETTINGS_RC_BAT, UI_SOFT, UI_BG);
        bsp_lcd_text(20, 178, UI_TXT_SETTINGS_AIR_BAT, UI_SOFT, UI_BG);
    }
}

void rc_ui_boot(void)
{
    rc_runtime_snapshot(&ui_data);
    ui_splash();
    ui_draw_home(0);
}

#ifndef RC_UI_PREVIEW
extern volatile uint16_t rc_ui_stack_free_words;

void rc_ui_task(void *argument)
{
    uint8_t screen = 0, selected = 0;
    int8_t stick_previous = 0;
    uint32_t battery_tick = 0, status_tick = 0;
    TickType_t wake = xTaskGetTickCount();
    (void)argument;
    for (;;) {
        rc_runtime_snapshot(&ui_data);
        uint32_t now = HAL_GetTick();
        uint8_t pressed = 0, event, redraw = 0;
        while ((event = rc_runtime_buttons()) != 0) pressed |= event;
        int8_t direction = ui_data.joy[3] > 600 ? 1 : ui_data.joy[3] < -600 ? -1 : 0;
        if ((pressed & RC_KEY_HOME) || (ui_data.buttons & RC_KEY_HOME)) {
            redraw = screen != 0 || (pressed & RC_KEY_HOME);
            screen = 0; stick_previous = direction;
        } else if (screen && (pressed & RC_KEY_BACK)) {
            screen = 0; redraw = 1; stick_previous = direction;
        } else if (!screen) {
            if (!direction) stick_previous = 0;
            else if (direction != stick_previous) {
                uint8_t old = selected;
                stick_previous = direction;
                if (direction > 0 && selected) selected--;
                if (direction < 0 && selected < UI_ITEM_COUNT - 1) selected++;
                if (old != selected) { ui_menu_row(old, selected); ui_menu_row(selected, selected); }
            }
            if (pressed & RC_KEY_OK) { screen = selected + 1; redraw = 1; stick_previous = direction; }
        }
        rc_runtime_focus(screen == UI_SCREEN_MANUAL);
        if (redraw) {
            if (screen) ui_draw_page(screen - 1);
            else ui_draw_home(selected);
        }
        if (screen == UI_SCREEN_MANUAL) { ui_manual_update(ui_data.joy); ui_manual_state(now); }
        if (now - status_tick >= 100U || redraw) {
            status_tick = now;
            if (!screen) ui_home_status(now);
            else if (screen == UI_SCREEN_STATUS) ui_status_values(now);
            else if (screen == UI_SCREEN_PREFLIGHT) ui_preflight_values(now, ui_data.joy);
        }
        if (now - battery_tick >= 1000U) { battery_tick = now; ui_battery(); }
        ui_refresh_footer();
        rc_ui_stack_free_words = (uint16_t)uxTaskGetStackHighWaterMark(NULL);
        if (xTaskDelayUntil(&wake, pdMS_TO_TICKS(20)) == pdFALSE) {
            wake = xTaskGetTickCount(); vTaskDelay(pdMS_TO_TICKS(1));
        }
    }
}
#else
void rc_ui_preview(const rc_snapshot_t *snapshot, uint8_t screen, uint8_t selected)
{
    ui_data = *snapshot;
    if (!screen) ui_draw_home(selected % UI_ITEM_COUNT);
    else ui_draw_page(screen - 1);
    if (screen == UI_SCREEN_MANUAL) {
        for (uint8_t i = 0; i < 32; i++) ui_manual_update(ui_data.joy);
        ui_manual_state(HAL_GetTick());
    }
    if (screen == UI_SCREEN_STATUS) ui_status_values(HAL_GetTick());
    if (screen == UI_SCREEN_PREFLIGHT) ui_preflight_values(HAL_GetTick(), ui_data.joy);
    ui_refresh_footer();
}
void rc_ui_preview_update(const rc_snapshot_t *snapshot, uint8_t screen, uint8_t selected)
{
    (void)selected; ui_data = *snapshot;
    if (screen == UI_SCREEN_MANUAL) { ui_manual_update(ui_data.joy); ui_manual_state(HAL_GetTick()); }
    else if (screen == UI_SCREEN_STATUS) ui_status_values(HAL_GetTick());
    else if (screen == UI_SCREEN_PREFLIGHT) ui_preflight_values(HAL_GetTick(), ui_data.joy);
    else if (!screen) ui_home_status(HAL_GetTick());
    ui_battery(); ui_refresh_footer();
}
void rc_ui_preview_select(const rc_snapshot_t *snapshot, uint8_t from, uint8_t to)
{
    ui_data = *snapshot; ui_menu_row(from, to); ui_menu_row(to, to);
}
#endif
