# Fly01 · STM32 空心杯四轴与遥控器

STM32F411RCT6 飞控 + STM32F103C8T6 遥控器的个人学习项目，公开软硬件、构建方法、测试和排查过程，欢迎指出设计与实现中的问题。

**发布快照：2026-10-30。** 这是当前最终整理版、实验性预发布；旧硬件有本人试飞反馈，当前导出的升压/双 LDO PCB 尚未完成实机验收。没有水平定点能力。项目大部分固件由 AI 协助实现，硬件设计、焊接、实验反馈和系统集成由项目作者完成。构建及主机测试不能代替真实飞行验证。

**硬件待核对：** 本次飞机板DRC返回空错误列表；遥控板仍有1项Import Changes网表同步提示。逐引脚导出网表比较差异为0，不代表已经消除该提示。详见[硬件快照检查](validation/hardware_snapshot.json)。当前设计不标为直接可投产版本。

![Fly01 PCB设计快照](docs/images/PCB1.png)

## 能做什么

- 8520 有刷空心杯四电机，1S 电池；20 kHz PWM；手动姿态稳定与气压相对定高。
- MPU6050 姿态估计、角度/角速度串级反馈、逐轴抗积分饱和和有界电机分配。
- Si24R1 / G01-S 无线控制、ACK 遥测、序号与新鲜度检查、失联停机。
- F103 上的轻量玻璃风格 LCD：手动飞行、状态、起飞检查、操作说明四项菜单。
- FreeRTOS 任务分工；主机替身测试、真实 C 绘图渲染检查。未使用 LVGL，保留 C8 容量约束。

![遥控界面，主机渲染](docs/images/RC_home.png)

## 先看这些

| 目的 | 入口 |
|---|---|
| 复现工程/烧录 | [构建与检查](docs/build-and-check.md) |
| 接线、旋向、按键、供电 | [硬件与操作](docs/hardware-and-operation.md) |
| 理解任务、协议与控制 | [软件结构](docs/software.md) |
| 了解问题、版本与验证范围 | [迭代及已知限制](docs/history-and-limitations.md) |
| 学习本项目的软件 | [学习路线](docs/learning-roadmap.md) |
| 提交可定位的问题 | [贡献与反馈](CONTRIBUTING.md) |

## 文件组织

```text
Fly_code01/board1/Flymachine_code1/          # 飞机正常工程
Fly_code01/board_control/Flymachine_rc1/    # 遥控正常工程
firmware/                                 # 本次构建HEX
hardware/Fly01_20261030_final.epro          # 完整嘉立创EDA项目
hardware/FC/                              # 飞机原理图PDF、PCB、BOM、网表、Gerber
hardware/RC/                              # 遥控原理图PDF、PCB、BOM、网表、Gerber
validation/                               # 本次构建与主机检查记录
licenses/                                 # 随附第三方许可
SHA256SUMS.txt                             # 文件校验清单
```

用嘉立创EDA专业版导入完整 `.epro` 可查看两块板及全部原理图页。Gerber 是设计归档，不代表本次已通过全部 ERC/DRC 或打板验收；请先复查。导出日期不等于制造日期。BOM保留原导出值与封装，以实际供应商规格为准。

## 操作摘要

K1 定高切换；**K2 全局强制停机并回主页**；K3 返回；K4 确认，在手动页满足条件后释放再长按约1秒请求解锁；K5/K6 降档/升档。左杆控制俯仰/横滚，右杆正方向给油门。先拆桨核对实际按键、旋向和补偿方向，首次连接不直接带桨解锁。

## 当前限制

带桨负载曾出现 F3 接收超时，未取得能唯一定位物理根因的示波器/射频证据。更换信道、独立供电和软件重试不构成彻底排除依据；见排查记录。无位置/速度观测，水平姿态不等于不漂移。保留历史机体零点 R=-2°/P=+2°、M3 相对集体量+1%补偿，其他机体应重新标定，不直接套用。

当前 FC 有200ms控制失联、IMU有效性、控制周期和KILL保护；**没有启用倾角超限自动停机与映射未确认联锁**。不提供电池低压自动保护、自动返航或加密认证。详细进入定高/退出接管条件见文档。

## 来源与许可

自有新增软件、文档及设计内容按 [MIT](LICENSE) 发布，第三方文件、字体及生成代码的许可分别见 [归属说明](THIRD_PARTY_NOTICES.md)，不覆盖上游权利。参考 Crazyflie、PX4 的控制思路；工程不是 Betaflight 固件，也不是它们的硬件目标。

发布资料组织参考了 [Crazyflie README](https://github.com/bitcraze/crazyflie-firmware/blob/master/README.md) 与 [Betaflight README](https://github.com/betaflight/betaflight/blob/master/README.md) 的构建、文档、贡献和许可入口，未照搬其代码或项目品牌。
