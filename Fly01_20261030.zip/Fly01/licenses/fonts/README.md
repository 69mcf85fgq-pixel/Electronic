# Fly01 UI Bitmap 字库来源与重建

本次公开 RC 正常固件已替换两套原字模：ASCII 与中文均来自 **Noto Sans CJK SC Regular 2.004**，不再内嵌厂商 ASCII 数组或 Windows SimHei 字模。修改后的字模称为 **Fly01 UI Bitmap**，按 SIL Open Font License 1.1 分发；此许可只覆盖字体数据，不改变固件其他组件的许可。

## 上游与许可证

- 仓库：https://github.com/notofonts/noto-cjk
- 固定提交：`f8d157532fbfaeda587e826d4cd5b21a49186f7c`
- 字体：[固定提交官方下载](https://raw.githubusercontent.com/notofonts/noto-cjk/f8d157532fbfaeda587e826d4cd5b21a49186f7c/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf)
- 字体 SHA256：`2c76254f6fc379fddfce0a7e84fb5385bb135d3e399294f6eeb6680d0365b74b`
- 上游 Git blob SHA1：`dc15562470b4f842321894787a0d066879ccff8b`（已用本次下载内容验证）
- 版权：Copyright 2014-2021 Adobe (http://www.adobe.com/)。来自实际 OTF name table。
- 原文许可：[OFL-NotoSansCJK.txt](OFL-NotoSansCJK.txt)，与上游 `Sans/LICENSE` 逐字节一致；SHA256 `6a73f9541c2de74158c0e7cf6b0a58ef774f5a780bf191f2d7ec9cc53efe2bf2`。
- 归属：[COPYRIGHT.txt](COPYRIGHT.txt)。再分发固件时一起保留这两份材料，不将字体改称为作者原创或把字体数据套用项目其他许可。

## 布局和重建

从仓库根执行：

```powershell
python Fly_code01/board_control/Flymachine_rc1/tools/generate_hanzi.py
& ./Fly_code01/board_control/Flymachine_rc1/tools/run_checks.ps1 -Compiler D:/MinGWDownload/bin/gcc.exe
```

依赖 Python、Pillow；本轮为 Python 3.14、Pillow 12.2.0、FreeType 2.14.3。字体缺失时由生成器/验证器从上述固定URL下载到 `assets/fonts/cache/` 并检查SHA256；已有缓存也重新验哈希。公开包不必包含完整16.4MB字体；缓存不作为发布素材。首次重建和像素验证需联网，或者预先放入哈希匹配的OTF缓存。`assets/fonts/source.json` 保存固定来源和布局参数。

- 仅从现有 `BSP/ui_text.h` 读取78条最终UI字符串，生成其中121个不同中文字符；**不写回ui_text.h、不恢复PID页面或旧字符串清单**。
- ASCII覆盖U+0020至U+007E共95字，保留 `ascii_1608[][16]`，8×16、每字节一行、bit0在左。
- 中文保留 `hanzi_glyph_t`、`hanzi_font[]`、`HANZI_FONT_COUNT`，每字16行、MSB在左。
- Noto按16px绘制；为了容纳完整笔画与下伸部，ASCII统一基线范围[-14,5)、中文[-15,3)，完整画布以Lanczos缩放至16行。ASCII先按至少8px及实际advance/bbox容纳，再缩放为8列；中文16列。
- 二值化阈值仍为100。生成器会拒绝超出画布的bbox；验证器从同一固定字体独立栅格化，检查所有ASCII/中文字模和原有C渲染页面的固定位置。没有通过移动提示位置、跳过字形或降低对比度断言来放行。
- 新检查曾在旧ASCII字模U+0021上失败；替换后全部字模和完整RC检查通过。连续两次生成字体头逐字节相同；ui_text.h前后SHA256相同。

## 本轮实际构建与验证（2026-10-30）

仅构建发布副本正常目标 `Flymachine_rc1`，ARMCC **V5.06 update 6 build 750**。调用 Keil 的 `-b <工程> -j0 -o<日志>` 后，读取新日志中的完成行确认结果，没有把启动进程返回当作构建通过。

- `tools/run_checks.ps1` 完整退出0：真实启动、控制/按键、任务/20ms周期、无线失败/ACK、停机原因、SPI互斥/分段、实际LCD渲染、全部字模、像素及两端协议一致性检查通过。
- Keil日志：`Fly_code01/board_control/Flymachine_rc1/MDK-ARM/build_font_release.log`，正常目标 **0 Error(s), 0 Warning(s)**，耗时8秒。
- Program Size：Code=25728，RO-data=7028，RW-data=180，ZI-data=14716字节。
- **本次字体变更后的新RC HEX**：`Fly_code01/board_control/Flymachine_rc1/MDK-ARM/Flymachine_rc1/Flymachine_rc1.hex`
- **HEX SHA256**：`e8878976293279ab26e7fdcf284dfee55ce1cf3fe87d4c0939be98c01053de7e`，文件92690字节。
- 24张本轮实际C渲染的280×240原尺寸PNG复制到 `docs/images/RC_*.png`；主页、操作说明和定高页已目视检查。它们是软件渲染预览，不是实物屏幕照片；故障示例画面不证明对应故障触发器在FC中实现。
- 控制、按键、协议、LCD驱动和UI布局代码保持不变；未操作硬件、未烧录，未以字库替换证明无线实机或新PCB验证完成。原始FC/RC工程及原最终HEX保留在私有原位置。

建议README使用：`docs/images/RC_home.png`、`RC_settings.png`、`RC_manual_hold.png`、`RC_status_height.png`、`RC_stop_return_timeout.png`。这些既有文件名已更新为本轮Noto字体效果。

交付前内容复核：原始FC/RC完整文件树摘要均与本轮修改前一致；发布RC的35份受保护Src/Inc/BSP文件（包括ui_text.h、LCD驱动、控制/按键/协议）SHA256均未变。公开树未检出两套旧字体的完整数组副本，字体定义只位于替换后的两个头文件。完整OTF下载缓存与本轮79份主机测试/临时预览产物已清理，保留24张README用PNG及新Keil正常固件/构建记录。首次重建会重新下载并校验固定OTF。