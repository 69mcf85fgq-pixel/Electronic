# 构建、烧录与验证

日期：2026-10-30。两端均以现存Keil工程为构建入口，勿用CubeMX直接覆盖手工集成的FreeRTOS、BSP与任务。

## 工具

- Keil µVision + ARMCC 5.06 update6 build750；FC DFP 3.1.1，RC DFP 2.4.1。工程使用ARMCC5，不是ARMClang/GCC ARM工程。
- FC：STM32F411RCTx，Flash256KiB@0x08000000，SRAM128KiB；HSE25MHz→96MHz。
- RC：STM32F103C8，Flash64KiB、RAM20KiB；工程代码区62KiB，HSE8MHz→72MHz。
- 主机检查：PowerShell、GCC（Windows MinGW，脚本提供 `-Compiler`）、Python3、Pillow；不是目标MCU执行的测试。

## Keil

打开 `Fly_code01/board1/Flymachine_code1/MDK-ARM/Flymachine_code1.uvprojx` 或对应 `board_control/Flymachine_rc1/MDK-ARM/Flymachine_rc1.uvprojx`，构建正常目标。调试选ST-Link并选择实际探针；公开配置已移除个人探针唯一编号。Flash地址0x08000000，FC烧录算法应为256KB器件。

命令示例（将Keil路径替换成自己的）：

```powershell
& 'E:\Keil\UV4\UV4.exe' -b '.\Fly_code01\board1\Flymachine_code1\MDK-ARM\Flymachine_code1.uvprojx' -j0 -o '.\FC_build.txt'
```

µVision命令可能在构建完成前返回；应检查日志末尾的0错误/0警告及生成文件，不能只看命令退出。

## 主机检查

保持两端目录相对布局，协议一致性检查需要定位兄弟工程。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Fly_code01\board1\Flymachine_code1\tools\run_host_tests.ps1 -Compiler 'D:\MinGWDownload\bin\gcc.exe'
powershell -NoProfile -ExecutionPolicy Bypass -File .\Fly_code01\board_control\Flymachine_rc1\tools\run_checks.ps1 -Compiler 'D:\MinGWDownload\bin\gcc.exe'
```

检查会在tests/out、tools和preview生成临时exe/图像；这些不进入源码提交。FC基准控制/运行时测试显式关闭M3机体补偿，并另跑开启补偿的专项测试，不能声称所有情景均覆盖默认补偿物理效果。RC使用实际C绘图代码渲染屏幕，图片不是实物照片。测试不模拟电机、机架、空气动力和射频环境。

公开整理版的中文/ASCII字模使用开源字体重建，来源、重建步骤及许可见字体工具和licenses/fonts。它与私人保留的原字模最终版在字形素材上有差异；控制、协议、按键未因此改变。原始旧HEX没有混入本目录。

## 上板验证顺序

1. 电机供电断开、拆桨，查短路与稳压电压，确认SWD、串口115200、IMU及无线初始化。
2. 两端都烧录同一发布包；核对按键及通信故障显示。手动倾斜核对估计轴符号。
3. 拆桨、低输出确认四路PWM、旋向，右侧下倾应增加右侧支撑，抬头应增加后侧支撑。
4. 拆桨验证K2、关闭遥控器后的FC失联停机、退出定高手动接管。
5. 再做受控短时带桨测试，留完整串口和电源/链路证据。新PCB和参数不得直接以主机通过当作已飞验收。
