---
created: 2026-10-30
type: 学习与实验清单
学习状态: 待完成
---
# Fly01软件学习重点与验收

关联：F411飞控与F103遥控器 · 2026-10-30_Fly01收尾与迭代复盘 · Fly01简历与面试材料

目标是能解释和复现本项目的软件链路。大部分固件由 AI 协助完成，因此“工程有功能”和“我能独立实现”分别记录。以下全部是待学习/待执行项，本次未启动编译、运行测试或操作硬件；不勾选已完成。

源码根目录：

- FC：[F411 飞控](../Fly_code01/board1/Flymachine_code1)。
- RC：[F103 遥控器](../Fly_code01/board_control/Flymachine_rc1)。
- 具体版本、参数和故障历史见收尾记录；下表的文件链接指向真实源码。

## 先打通一条链路

ADC/DMA → 摇杆归一化与死区 → RC 会话/按键 → 18字节控制帧 → SPI无线 → FC 解码/序号过滤 → 最新命令队列 → IMU/定高/姿态控制 → 混控 → TIM3 PWM → 32字节遥测与ACK payload → RC 新鲜度检查 → UI。

建议按 P0 的 1～5 → P1 的 6～8 → P2 的 9～11 学习。首次从一份真实日志开始，不要求先读完整 HAL/FreeRTOS 内核。

| 顺序 | 实际文件/函数 | 需要解释的重点 | 可执行实验或推演 | 验收证据 |
|---|---|---|---|---|
| P0-1 输入与 C 数据类型 | RC [Src/main.c](../Fly_code01/board_control/Flymachine_rc1/Src/main.c)、[Src/adc.c](../Fly_code01/board_control/Flymachine_rc1/Src/adc.c)；HAL_ADC_Start_DMA；[Src/rc_runtime.c](../Fly_code01/board_control/Flymachine_rc1/Src/rc_runtime.c)：joystick_value、keys_raw、keys_debounce | 5路DMA循环采样；volatile不是多值一致快照；有符号减法、死区严格边界与限幅 | 手算 raw=center、center±119、center±120及端点的归一化结果；逐项对照6个引脚。后续拆桨/电机断电读取居中ADC和joy | 留下至少7组输入/输出表，解释±120边界；记录实际居中值，不能仅以T=0判断摇杆正常 |
| P0-2 协议与字节序 | FC [BSP/flight_link.h](../Fly_code01/board1/Flymachine_code1/BSP/flight_link.h)、[BSP/flight_link.c](../Fly_code01/board1/Flymachine_code1/BSP/flight_link.c)；RC [BSP/flight_link.c](../Fly_code01/board_control/Flymachine_rc1/BSP/flight_link.c)：fl_encode_control、fl_decode_control、fl_decode_telemetry | 长度/版本/范围检查；put16/get16小端；int16_t负值；param raw比例；seq回绕；hover_seq事件序号 | 手工编码负方向量、ARM、档位和hover_seq；推演254→255→0、重复包、旧包、错误长度。比较两端协议源码 | 画出18字节逐字段表及32字节遥测表，负值可还原；解释为什么重复包不刷新有效控制年龄 |
| P0-3 RC 状态机与按键 | RC [Src/rc_control.c](../Fly_code01/board_control/Flymachine_rc1/Src/rc_control.c)：rc_control_step、rc_control_receive、rc_control_echo_recent；[Inc/rc_control.h](../Fly_code01/board_control/Flymachine_rc1/Inc/rc_control.h) | K4需释放后长按、零油门及新鲜遥测；确认解锁前axes保持0；K1事件；K2优先；K3只返回 | 纸上推演停机→按住OK→确认ARM→飞行→K2；再推演无新遥测、故障和回绕。拆桨时实际核对六键 | 画出会话状态与flags/axes变化表；明确200ms显示新鲜度、1000ms飞行回传超时与FC200ms的不同 |
| P0-4 FC 保护与输出边界 | FC [BSP/flight_control.c](../Fly_code01/board1/Flymachine_code1/BSP/flight_control.c)：fc_step、stop、reset_pid；[BSP/flight_app.c](../Fly_code01/board1/Flymachine_code1/BSP/flight_app.c)：control_task、flight_emergency_stop；[BSP/flight_config.h](../Fly_code01/board1/Flymachine_code1/BSP/flight_config.h) | KILL、未ARM、FL_FAULT锁存、IMU有效期、dt范围、F1/F4枚举与当前未启用触发逻辑的区分；故障停机清I和输出 | 阅读现有test_flight/test_runtime，再推演有效包年龄200/201ms、dt=0/4/13ms、NaN、失效IMU、KILL。不要在实飞中注入故障 | 逐项给出分支和状态预期；200ms本身不触发“>200”判断，201ms触发；解释检查顺序和实际调度延迟 |
| P0-5 故障日志 | FC [BSP/flight_app.c](../Fly_code01/board1/Flymachine_code1/BSP/flight_app.c)：radio_snapshot、save_control_diag、log_task；RC [Src/rc_runtime.c](../Fly_code01/board_control/Flymachine_rc1/Src/rc_runtime.c)：rc_runtime_log_stop | 故障前输出、最后有效帧年龄、IMU年龄、ACK计数与真实接收；低频快照会漏峰值 | 用reviews/prop_load_link_20261022/analysis.md中13271～13431ms时间线复原GAP/LATE/STOP/BACK | 用“观察→触发条件→候选原因→区分实验”写一页；不把F3直接写成供电、振动或PID根因 |
| P1-6 IMU 驱动与坐标 | FC [BSP/bsp_mpu6050.c](../Fly_code01/board1/Flymachine_code1/BSP/bsp_mpu6050.c)：bsp_mpu6050_init、read_sample、bsp_mpu6050_update；[BSP/flight_app.c](../Fly_code01/board1/Flymachine_code1/BSP/flight_app.c)：control_task | I2C原始字节、量程与偏置；FRD=(X,-Y,-Z)；陀螺预测与重力校正；估计后减LEVEL一次 | 画出传感器轴到机体轴；手算R原始-1°减零点-2°得+1°。后续拆桨且电机断电，左右倾/抬头读角度及命令 | 给出六方向符号对照；解释加速度不等于重力、静态零点不等于动态标定，主机方向测试不等于带桨稳定 |
| P1-7 双环、混控与抗饱和 | FC [BSP/flight_control.c](../Fly_code01/board1/Flymachine_code1/BSP/flight_control.c)：rate_feedback、allocate、mix_outputs、fc_step；[tests/test_flight.c](../Fly_code01/board1/Flymachine_code1/tests/test_flight.c)、[tests/test_m3_trim.c](../Fly_code01/board1/Flymachine_code1/tests/test_m3_trim.c) | 角度→角速度目标→P/I/D；D对测量；差动预算；试积分→分配→拒绝有害增量→同周期重分配 | 手算零误差水平输出及正横滚扰动；举一个正饱和且继续正积分的例子，再反向；算collective=0.4时M3 trim=0.004 | 说明Q/U、sat/blk及PWM命令局限；解释M3补偿耦合三轴和量化影响；不把“占空比相同”当推力相同 |
| P1-8 气压定高与接管 | FC [BSP/bsp_spa06.c](../Fly_code01/board1/Flymachine_code1/BSP/bsp_spa06.c)：bsp_spa06_read；[BSP/flight_control.c](../Fly_code01/board1/Flymachine_code1/BSP/flight_control.c)：fc_pressure、fc_step；知识点 气压定高与无扰接管 | Pa→相对m→cm；参考气压、32个准备样本、32ms轮询、300ms新鲜度；锁HT/base/cap；高度P/I与速度阻尼；退出等待接管 | 先复核既有十厘米台架记录。未来拆桨且切断电机供电，定高后水平缓慢上下移动约10～30cm，记录FC ALT H/HT/V/base/C/cap/age | HT保持、H方向合理、C随误差反向修正且有界；另画气压过期→HOLD_EXIT→油门变化>150接管路径。台架结果不能填写实飞精度 |
| P2-9 周期任务与共享数据 | FC [BSP/flight_app.c](../Fly_code01/board1/Flymachine_code1/BSP/flight_app.c)：control_task、radio_task、log_task、flight_app_start；RC [Src/rc_runtime.c](../Fly_code01/board_control/Flymachine_rc1/Src/rc_runtime.c)：rc_radio_task、rc_runtime_start | FC优先级4/3/1，RC3/1；vTaskDelayUntil；单槽覆盖队列取最新值；短临界区；IWDG仅控制任务喂；漏周期处理 | 手画4/10/20ms调度与数据年龄；找出I2C等待算入dt的位置、每条queue写者/读者；阅读栈高水位采集 | 写任务表与共享数据表，解释为什么日志低优先级、为什么latest-value命令不排队执行历史。静态栈配置不等于实测峰值安全 |
| P2-10 SPI 与 UI 实时性 | RC [BSP/bsp_spi_bus.c](../Fly_code01/board_control/Flymachine_rc1/BSP/bsp_spi_bus.c)：bsp_spi_bus_lock/unlock；[BSP/bsp_lcd.c](../Fly_code01/board_control/Flymachine_rc1/BSP/bsp_lcd.c)；[BSP/bsp_nrf.c](../Fly_code01/board_control/Flymachine_rc1/BSP/bsp_nrf.c)；[Src/rc_ui.c](../Fly_code01/board_control/Flymachine_rc1/Src/rc_ui.c)：ui_field、rc_ui_task | LCD和无线共用SPI互斥；优先级继承；屏幕局部更新；UI队列满不阻断K2控制通路 | 静态跟踪一段LCD与无线事务锁范围；阅读rc_daily报告满队列K2实验与20帧像素结果；将来单独测持续切页时发送间隔/漏周期 | 能解释互斥解决并发正确性但不能自动保证无线截止期；主机图像不能记作实机LCD照片 |
| P2-11 读懂既有测试 | FC [tests/test_runtime.c](../Fly_code01/board1/Flymachine_code1/tests/test_runtime.c)、[tests/test_nrf_failure.c](../Fly_code01/board1/Flymachine_code1/tests/test_nrf_failure.c)、[tests/test_mpu.c](../Fly_code01/board1/Flymachine_code1/tests/test_mpu.c)；[tools/run_host_tests.ps1](../Fly_code01/board1/Flymachine_code1/tools/run_host_tests.ps1)；RC [tools/test_rc_runtime.c](../Fly_code01/board_control/Flymachine_rc1/tools/test_rc_runtime.c) | 纯控制、实际任务替身、驱动故障注入、字节一致性与板测范围；断言是否真能检出缺陷 | 建议在隔离副本在隔离副本复现一个旧实现失败/修复通过案例，优先选抗饱和重分配mutation记录 | 能说出输入、预期、失败原因和未覆盖范围；编译通过、主机测试、台架、实飞四层证据分别记录 |

第9项归入P2是深入调度分析；第8项前已经需要理解基本任务/队列，可先略读第9项的数据流。

## 每一项完成后留下什么

在 实验记录模板 或 调试记录模板 中记录：日期、板号、两端固件标识/文件hash、输入和环境、原始日志、预期、实际、结论及限制。状态分为“看过”“能独立讲清”“能复现”“能独立修改并验证”，只勾本次实际达到的一层。

- [ ] 用自己的话连续讲清一次ADC→PWM→遥测，能定位以上函数。
- [ ] 独立解释一次F3的触发与根因证据差别。
- [ ] 独立解释坐标变换、LEVEL零点、M3补偿分别作用在哪里。
- [ ] 独立推演一次饱和积分拒绝及定高手动接管。
- [ ] 留下一份本人执行的可复现实验记录，再调整简历中的软件能力表述。

当前没有新增“已掌握”结论。
